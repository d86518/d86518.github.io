#!/usr/bin/env python
# coding: utf-8

# In[1]:

import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn import metrics
from sklearn.metrics import accuracy_score , confusion_matrix
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.utils import class_weight
from xgboost import XGBClassifier
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn import tree
from sklearn import preprocessing
from tensorflow.keras import optimizers
from tensorflow.keras.wrappers.scikit_learn import KerasClassifier
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout

# In[2]:
##############
###red-wine###
##############
red = pd.read_csv('winequality-red.csv')
red_y = pd.DataFrame(red['quality'])

red_x = red
del red_x['quality']

#quality分群
conditions = [
    red_y['quality'] > 6,
    red_y['quality'] == 6,
    red_y['quality'] == 5,
    red_y['quality'] < 5
]
choices = ['excellent','good','medium','bad']

red_y['rating'] = np.select(conditions, choices, default = 'no rating')
del red_y['quality']

# In[3]:
scaler=StandardScaler()
scaler.fit(red_x)
red_xx=pd.DataFrame( scaler.transform(red_x) )  #standard normalization

#principal component analysis
pca_r = PCA(n_components=11) #11個主成分
pca_r.fit_transform(red_xx)

eigen_value = pd.DataFrame(np.round(pca_r.explained_variance_), columns=['eigen value']) #變異量,越大越好
print('eigen value:\n',eigen_value)

red_var = np.round(pca_r.explained_variance_ratio_,4)*100 #11個主成分各自解釋了多少%變異
red_var = pd.DataFrame(red_var)
red_var.columns = ['explained var']
print("\n explained variances(%):\n",red_var)

red_cumvar = np.cumsum(red_var) #11個主成分累計解釋變異
red_cumvar.columns = ['cumulative var']
print("\n cumulative explained variances(%):\n",red_cumvar)

plt.plot(red_cumvar)
plt.xlabel('components')
plt.ylabel('cumulative explained variance')
#需要7個主成分就能解釋90%的變異

# In[4]:
#choose components
pca_red = PCA(n_components=7)

#函數新座標
new_x = pd.DataFrame(pca_red.fit_transform(red_x), columns=['pc1','pc2','pc3','pc4','pc5','pc6','pc7'])
print('new x:\n',new_x)

eigen_vector = pd.DataFrame(pca_red.components_.T, columns=['pc1','pc2','pc3','pc4','pc5','pc6','pc7'], index=list(red_xx.columns)) #vector的權重，vector為資料投影後有最大變異量的投影軸
print('\neigen vector:\n',eigen_vector) 

# reb = pca_red.inverse_transform(pca_red.fit_transform(red_x))
# reb #轉回無雜訊之原始值,重新建構原始值,reb與x誤差越小越好

# In[6]:
#### PCA ####
## CART
#調參
tree_param_grid = { 'min_samples_split': list((20,30,40)),
                   'min_samples_leaf':list((10,20,30)),'max_depth':list((4,6,8))}
grid = GridSearchCV(DecisionTreeClassifier(random_state=516),param_grid=tree_param_grid, cv=3)
grid.fit(new_x, red_y)
grid.cv_results_, grid.best_params_, grid.best_score_
print(grid.best_params_)

# In[7]:
#建立分類器
DT=DecisionTreeClassifier(max_depth=grid.best_params_['max_depth'], 
                          min_samples_leaf=grid.best_params_['min_samples_leaf'],
                          min_samples_split=grid.best_params_['min_samples_split'])
#max_depth=4, min_samples_leaf=20, min_samples_split=20
DT.fit(new_x,red_y)
tree.plot_tree(DT)
print(tree.export_text(DT))

pred_DT = DT.predict(new_x)
conf_DT = pd.crosstab(red_y.values.flatten(),pred_DT,rownames=['real'],colnames=['pred'])
conf_DT.shape
print('\nConfusion Matrix:\n',conf_DT)
print('\nAccuracy= ', metrics.accuracy_score(red_y, pred_DT))
DT_p=metrics.accuracy_score(red_y, pred_DT)

conf_DT.columns.to_list()
conf_DT.index.to_list()
conf_DT['bad']= [0,0,0,0]
cols=conf_DT.columns
cols=sorted(cols)
conf_DT=conf_DT[cols]
conf_DT.loc['bad']['excellent']

#pca in classification
perf_DT = pd.DataFrame()
perf_DT['bad'] = [conf_DT.loc['bad']['bad']/ conf_DT.loc['bad'].sum()]  
perf_DT['excellent'] = [conf_DT.loc['excellent']['excellent']/ conf_DT.loc['excellent'].sum()]
perf_DT['good'] = [conf_DT.loc['good']['good']/ conf_DT.loc['good'].sum()]
perf_DT['medium'] = [conf_DT.loc['medium']['medium']/ conf_DT.loc['medium'].sum()]
print("\n Performance in accuracy by using PCA+CART\n")
print(perf_DT)
print("\n")

# In[23]:
#### PCA ####
#RF調參
rf_param_grid = { 'min_samples_split': list((20,30,40)),
                   'min_samples_leaf':list((10,20,30)),
                   'n_estimators':list((80,120,150)),'max_depth':list((4,6,8))}
grid = GridSearchCV(RandomForestClassifier(random_state=516),param_grid=rf_param_grid, cv=3)
grid.fit(new_x, red_y)
grid.cv_results_, grid.best_params_, grid.best_score_
print(grid.best_params_)

# In[24]:
RF=RandomForestClassifier(max_depth=grid.best_params_['max_depth'], 
                          min_samples_leaf=grid.best_params_['min_samples_leaf'], 
                          min_samples_split=grid.best_params_['min_samples_split'],
                          n_estimators=grid.best_params_['n_estimators'],random_state=516)

RF.fit(new_x,red_y)
pred_RF = RF.predict(new_x)
conf_RF = pd.crosstab(red_y.values.flatten(),pred_RF,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix:\n',conf_RF)
print('\nAccuracy= ', metrics.accuracy_score(red_y, pred_RF))
RF_p=metrics.accuracy_score(red_y, pred_RF)
    
conf_RF.columns.to_list()
conf_RF.index.to_list()
conf_RF['bad']= [0,0,0,0]
cols=conf_RF.columns
cols=sorted(cols)
conf_RF=conf_RF[cols]
conf_RF.loc['bad']['excellent']

#pca in classification
perf_RF = pd.DataFrame()
perf_RF['bad'] = [conf_RF.loc['bad']['bad']/ conf_RF.loc['bad'].sum()]  
perf_RF['excellent'] = [conf_RF.loc['excellent']['excellent']/ conf_RF.loc['excellent'].sum()]
perf_RF['good'] = [conf_RF.loc['good']['good']/ conf_RF.loc['good'].sum()]
perf_RF['medium'] = [conf_RF.loc['medium']['medium']/ conf_RF.loc['medium'].sum()]
print("\n Performance in accuracy by using PCA+RF\n")
print(perf_RF)
print("\n")

# In[25]:
#XGB調參
xgb_param_grid = { 'min_samples_split': list((20,30,40)),'n_estimators':list((80,120,150)),
                   'max_depth':list((4,6,8)),'learning_rate':[0.01,0.05,0.1]}
grid = GridSearchCV(XGBClassifier(random_state=516, objective="multi:softprob"),
                    param_grid=xgb_param_grid, cv=3)
#grid.fit(new_x, red_y)
red_yy = red_y.replace('excellent',3).replace('good',2).replace('medium',1).replace('bad',0).astype(int) 
grid.fit(new_x, red_yy)
grid.cv_results_, grid.best_params_, grid.best_score_
print(grid.best_params_)

# In[23]:
#建立分類器
XGB=XGBClassifier(max_depth=grid.best_params_['max_depth'], 
                  min_samples_split=grid.best_params_['min_samples_split'], 
                  n_estimators=grid.best_params_['n_estimators'], 
                  learning_rate=grid.best_params_['learning_rate'], random_state=516,objective="multi:softprob")
#XGB.fit(new_x,red_y) #old
XGB.fit(new_x,red_yy)
pred_XGB = XGB.predict(new_x)
pred_XGB = pd.Series(pred_XGB).replace(3,'excellent').replace(2,'good').replace(1,'medium').replace(0,'bad').astype("category") #新增
conf_XGB = pd.crosstab(red_y.values.flatten(),pred_XGB,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix:\n',conf_XGB)
print('\nAccuracy= ', metrics.accuracy_score(red_y, pred_XGB))
XGB_p=metrics.accuracy_score(red_y, pred_XGB)

#pca in classification
perf_XGB = pd.DataFrame()
perf_XGB['bad'] = [conf_XGB.loc['bad']['bad']/ conf_XGB.loc['bad'].sum()]  
perf_XGB['excellent'] = [conf_XGB.loc['excellent']['excellent']/ conf_XGB.loc['excellent'].sum()]
perf_XGB['good'] = [conf_XGB.loc['good']['good']/ conf_XGB.loc['good'].sum()]
perf_XGB['medium'] = [conf_XGB.loc['medium']['medium']/ conf_XGB.loc['medium'].sum()]
print("\n Performance in accuracy by using PCA+XGB\n")
print(perf_XGB)
print("\n")

# In[17]:
#### PCA ####
## SVM調參
parameters = {'kernel':['rbf'], 'C':[10,50,100], 
              'gamma':[ 10**-2, 10**-1, 1,10,100]}
grid = GridSearchCV(SVC(random_state=516),param_grid=parameters, cv=3)

grid.fit(new_x,red_y)
grid.cv_results_, grid.best_params_, grid.best_score_
print(grid.best_params_)

# In[18]:
#建立分類器
svc = SVC(kernel='rbf',C=grid.best_params_['C'],gamma=grid.best_params_['gamma'],random_state=516)
svc.fit(new_x,red_y)
pred_SVC = svc.predict(new_x)
conf_SVC = pd.crosstab(red_y.values.flatten(),pred_SVC,rownames=['real'],colnames=['pred'])

print('\nConfusion Matrix:\n',conf_SVC)
print('\nAccuracy= ', metrics.accuracy_score(red_y, pred_SVC))
SVC_p=metrics.accuracy_score(red_y, pred_SVC)

#pca in classification
perf_SVC = pd.DataFrame()
perf_SVC['bad'] = [conf_SVC.loc['bad']['bad']/ conf_SVC.loc['bad'].sum()]  
perf_SVC['excellent'] = [conf_SVC.loc['excellent']['excellent']/ conf_SVC.loc['excellent'].sum()]
perf_SVC['good'] = [conf_SVC.loc['good']['good']/ conf_SVC.loc['good'].sum()]
perf_SVC['medium'] = [conf_SVC.loc['medium']['medium']/ conf_SVC.loc['medium'].sum()]
print("\n Performance in accuracy by using PCA+SVC\n")
print(perf_SVC)
print("\n")

#%%
# DNN建立模型
X_scaler = preprocessing.MinMaxScaler()
#X_scaler.fit_transform(new_x) #why??
new_xx = np.array(new_x)
#encoded class values as integers
dum_y = pd.get_dummies(red_y,drop_first=False) #why??

weights = class_weight.compute_class_weight('balanced', classes=np.unique(red_y), y=red_y.values.reshape(-1))
cls_weights = {i : weights[i] for i in range(4)}
es = EarlyStopping(monitor='loss', mode='min', patience = 20, verbose=1)

def DNN(first_hidden_neuron,n_dropout,n_hidden,n_neurons,
                learning_rate, activation, kernel_initializer,n_epochs,
                n_batch_size,select_optimizer):#
    
    model = Sequential()
    model.add(Dense(first_hidden_neuron,input_dim=len(new_xx[0]),activation=activation,kernel_initializer=kernel_initializer))
    for layer in range(n_hidden):
        model.add(Dense(n_neurons,activation=activation,kernel_initializer=kernel_initializer))
        model.add(Dropout(n_dropout))
        
    model.add(Dense(4,activation='softmax'))
    
    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='categorical_crossentropy',optimizer=optimizer, metrics=['accuracy'])
    
    model.fit(new_xx,dum_y, epochs=n_epochs, batch_size=n_batch_size, callbacks=[es], class_weight = cls_weights)
    return model

keras=KerasClassifier(DNN)

#%%
#DNN調參
params_DNN = {
        "n_dropout":[0.15,0.25,0.35],
        "n_hidden":[1,2,3],
        'first_hidden_neuron':[4,8,16],
        "n_neurons":[4,8,16],
        "learning_rate":[0.01,0.005,0.001],
        "activation":['relu','softplus','sigmoid'],
        "n_epochs":[200],
        "n_batch_size":[32, 64, 128],
        "kernel_initializer": ['glorot_uniform', 'lecun_normal'],
        "select_optimizer":[optimizers.Adam,optimizers.SGD,optimizers.RMSprop]
        }
# Randomized Search
RS_cv=RandomizedSearchCV(keras,params_DNN,n_iter=10,cv=3,random_state=516)
RS_cv.fit(new_xx,dum_y)
print(RS_cv.best_params_)

#%%
DNN = DNN(first_hidden_neuron=8,n_dropout=0.15,n_hidden=2,n_neurons=16,kernel_initializer='he_uniform',
          learning_rate=0.01,activation='softplus',n_batch_size=64,n_epochs=300,
          select_optimizer=optimizers.Adam) #手動調整分類器

#建立分類器
DNN = RS_cv.best_estimator_
DNN.fit(new_xx,dum_y)
pred_DNN= pd.Series(DNN.predict(new_xx))
for i in range(0,4): pred_DNN[pred_DNN==i] = np.unique(red_y)[i]

#%%
# replace numerical outputs with class labels
conf_DNN = pd.crosstab(red_y.values.flatten(),pred_DNN,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix:\n',conf_DNN)
print('\nAccuracy= ', metrics.accuracy_score(np.argmax(dum_y.to_numpy(), axis=-1), pred_DNN))
DNN_p=metrics.accuracy_score(np.argmax(dum_y.to_numpy(), axis=1), pred_DNN)

#pca in classification
perf_DNN = pd.DataFrame()
perf_DNN['bad'] = [conf_DNN.loc['bad']['bad']/ conf_DNN.loc['bad'].sum()]  
perf_DNN['excellent'] = [conf_DNN.loc['excellent']['excellent']/ conf_DNN.loc['excellent'].sum()]
perf_DNN['good'] = [conf_DNN.loc['good']['good']/ conf_DNN.loc['good'].sum()]
perf_DNN['medium'] = [conf_DNN.loc['medium']['medium']/ conf_DNN.loc['medium'].sum()]
print("\n Performance in accuracy by using PCA+SVC\n")
print(perf_DNN)
print("\n")

#%%
## 統整
#pca
perf_c = pd.DataFrame()
perf_c["DT"] = perf_DT.iloc[0]
perf_c["RF"] = perf_RF.iloc[0]
perf_c["XGB"] = perf_XGB.iloc[0]
perf_c["SVC"] = perf_SVC.iloc[0]
perf_c["DNN"] = perf_DNN.iloc[0]
#perf_c.index = ["bad","excellent","good","medium"] 
print("\n Performance of PCA\n")
print(round(perf_c,4))


