# -*- coding: utf-8 -*-
"""
Created on Mon Sep  6 11:03:14 2021

@author: a0978
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats
from scipy.stats import skew, kurtosis
from scipy.stats import normaltest
from scipy.stats import ttest_1samp
from scipy.stats import shapiro
from scipy.stats import f_oneway

#%%
iris=pd.read_csv('iris.csv')
iris.info()
iris.describe()
iris.columns
iris.head(5)

print(iris.iloc[1, 0:4]) # print the second row
print(iris.iloc[0:4, 1]) # print the second column

plt.plot(iris.iloc[:,0],iris.iloc[:,1], 'o', label='o')
plt.legend()
plt.xlabel('Sepal.length')
plt.ylabel('Sepal.width')
plt.title('Scatter Chart')
np.corrcoef(iris.iloc[:,0], iris.iloc[:,1])

plt.plot(iris.iloc[:,2],iris.iloc[:,3], 'x', label='x')
plt.legend()
plt.xlabel('Petal.length')
plt.ylabel('Petal.width')
plt.title('Scatter Chart')
np.corrcoef(iris.iloc[:,2], iris.iloc[:,3])

df_iris=iris.drop(['Species'],axis=1)
print(df_iris.corr())

x = df_iris.iloc[:, :-1]  # features
y = df_iris.iloc[:, -1]   # target
y=pd.DataFrame(y)

from scipy.stats import pearsonr
correlation, p_value = pearsonr(df_iris.iloc[:, 0], df_iris.iloc[:, 3])
print('Pearson correlation:', correlation)
print('P-value:', p_value)

correlation, p_value = pearsonr(x.iloc[:, 1], y)
print('Pearson correlation:', correlation)
print('P-value:', p_value)

correlation, p_value = pearsonr(x.iloc[:, 2], y)
print('Pearson correlation:', correlation)
print('P-value:', p_value)

#%%
df_iris=iris.drop(['Species'],axis=1)
df_iris.mean()
df_iris.std()
print(skew(df_iris)) #skewness
print(kurtosis(df_iris)) #kurtosis
print(normaltest(df_iris))

#MDS
from sklearn.manifold import MDS
import seaborn as sns

# MDS (2d)
mds = MDS(n_components=2, random_state=42)
iris_2d = mds.fit_transform(df_iris)
iris_mds = pd.DataFrame(iris_2d, columns=['MDS1', 'MDS2'])
iris_mds['species'] = iris['Species']

# plot
plt.figure(figsize=(8, 6))
sns.scatterplot(data=iris_mds, x='MDS1', y='MDS2', hue='species', palette='Set1')
plt.title('Iris MDS Plot')
plt.xlabel('MDS Dimension 1')
plt.ylabel('MDS Dimension 2')
plt.grid(True)
plt.legend()
plt.show()

#%%
#Grouping data
df_set=iris[iris['Species']=='setosa']
df_ver=iris[iris['Species']=='versicolor']
df_vir=iris[iris['Species']=='virginica']

stats.levene(df_set['Sepal.Length'], df_vir['Sepal.Length']) #Equal-Variance test
stats.ttest_ind(df_set['Sepal.Length'],df_vir['Sepal.Length'],equal_var=False)

stats.levene(df_ver['Sepal.Width'], df_vir['Sepal.Width']) #Equal-Variance test
stats.ttest_ind(df_ver['Sepal.Width'],df_vir['Sepal.Width'],equal_var=True)

#%%
#ANOVA
import seaborn as sns
sns.set(style="whitegrid")
sns.boxplot(x = "Species", y = "Sepal.Length", data = iris, width=0.2, palette="Set3")
sns.swarmplot(x = "Species", y = "Sepal.Width", data = iris, color = "red")

stats.levene(df_set['Petal.Length'], df_ver['Petal.Length'], df_vir['Petal.Length'])
stats.f_oneway(df_set['Petal.Width'], df_ver['Petal.Width'], df_vir['Petal.Width'])

#from statsmodels.stats.multicomp import pairwise_tukeyhsd
from statsmodels.stats.multicomp import MultiComparison
mc = MultiComparison(iris['Sepal.Width'], iris['Species'])
tkresult = mc.tukeyhsd()
print(tkresult)

#%%
#height, weight, waist, gender
gender = pd.read_csv('gender_size.csv')
df_male = gender[gender['Gender']=='male']
df_female = gender[gender['Gender']=='female']

shapiro(df_male['Height'])
ttest_1samp(df_male['Height'], 174)
ttest_1samp(df_male['Height'], 174, alternative="greater")

shapiro(df_female['Weight'])
ttest_1samp(df_female['Weight'], 54)
ttest_1samp(df_female['Weight'], 54, alternative="less")

shapiro(gender['Waist'])
ttest_1samp(gender['Waist'], 28)

#%%
# Chi-square test
#Support for Bush, Perot, Clinton between male and female in the US election
from scipy.stats import chi2_contingency
observed = [
    [315, 152,337],
    [346,126, 571],
]

chi2, p, dof, expected = stats.chi2_contingency(observed)
print('chi-square:', chi2)
print('p-value:', p)
print('degree of freedom:', dof)
print('expected value table:', expected)
if p >= 0.05:
    print('H0 is accepted (gender does not affect support for president candidates)')
else:
    print('H0 is rejected (gender does affect support for president candidates)')


import statsmodels.stats.proportion
##test for getting equal support between the males and the females
statsmodels.stats.proportion.proportions_chisquare(315, 315+346, value = 0.5)
statsmodels.stats.proportion.proportions_chisquare(152, 152+126, value = 0.5)
statsmodels.stats.proportion.proportions_chisquare(337, 337+571, value = 0.5)

##test for Bush (alternative: getting more support from the males)
statsmodels.stats.proportion.proportions_ztest([315,346], [315+346,315+346], alternative='two-sided')

##test for Perot (alternative: getting unequal support between the males and the females)
statsmodels.stats.proportion.proportions_ztest([152,126], [152+126,152+126], alternative='larger')

##test for Clinton (alternative: getting more support from the females)
statsmodels.stats.proportion.proportions_ztest([337,571], [337+571,337+571], alternative='smaller')

