#!/usr/bin/env python
# coding: utf-8

# In[1]:
import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
import seaborn as sns
import time, random
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_absolute_error
from sklearn.preprocessing import MinMaxScaler
from bayes_opt import BayesianOptimization
from pandas import DataFrame,concat
from sklearn import metrics
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR
import statsmodels.api as sm
from sklearn.linear_model import LinearRegression
from pyearth import Earth

import skopt
from skopt.space import Real, Categorical, Integer 
from sklearn.metrics import explained_variance_score, mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import  RandomizedSearchCV, train_test_split,TimeSeriesSplit,GridSearchCV
from sklearn.preprocessing import LabelBinarizer
from tensorflow.keras import optimizers
from tensorflow.keras.wrappers.scikit_learn import KerasRegressor
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout

# In[2]:
### 載入Marine Data ###
data=pd.read_csv('container.csv',delimiter=",")
data = pd.DataFrame(data)
#del data['Date']
print('The shape of our features is:', data.shape)
print(data.isnull().any())
# 印出data所有欄位名稱
print(data.columns)
data= data.drop(['HSI'],axis=1)

# In[5]:
# split data into train and test(時間序列資料)
x_train, y_train = data.iloc[0:132,2:], data.iloc[0:132,1 ]
x_test, y_test = data.iloc[132:153,2: ], data.iloc[132:153,1]
print(x_train.shape, y_train.shape, x_test.shape, y_test.shape)

#%% MLR模型
MLR = sm.OLS(y_train,x_train).fit()
print(MLR.summary())
lm = LinearRegression()
lm.fit(x_train, y_train)

#%% MLR 績效 (training)
MLR_train = lm.predict(x_train)

MLR_tr_RMSE=np.sqrt(metrics.mean_squared_error(y_train, MLR_train))
print('training RMSE:',MLR_tr_RMSE)

MLR_tr_MAE=metrics.mean_absolute_error(y_train,MLR_train)
print('training MAE:',MLR_tr_MAE)

MLR_tr_MAPE=metrics.mean_absolute_percentage_error(y_train,MLR_train)
print('training MAPE:',MLR_tr_MAPE)

#MLR 績效 (testing)
MLR_test = lm.predict(x_test)

MLR_ts_RMSE=np.sqrt(metrics.mean_squared_error(y_test, MLR_test))
print('testing RMSE:',MLR_ts_RMSE)

MLR_ts_MAE=metrics.mean_absolute_error(y_test,MLR_test)
print('testing MAE:',MLR_ts_MAE)

MLR_ts_MAPE=metrics.mean_absolute_percentage_error(y_test,MLR_test)
print('testing MAPE:',MLR_ts_MAPE)

# In[6]:
# MARS調參 (Panalty 為GCV的懲罰值)
tree_param_grid = {'max_degree': list((2,3,4)),'penalty':list((5,10,15))}
grid = GridSearchCV(Earth(feature_importance_type='gcv'),param_grid=tree_param_grid, cv=3)
grid.fit(x_train,y_train)
grid.cv_results_, grid.best_params_, grid.best_score_
print(grid.best_params_)#MARS最佳參數

# In[7]:
# 建立MARS模型及變數重要性展示
MARS_marine = grid.best_estimator_
MARS_marine.fit(x_train,y_train)
print(MARS_marine.summary_feature_importances(sort_by='gcv'))

#%% 
#MARS使用全變數績效 (training)
MARS_train = MARS_marine.predict(x_train)

MARS_tr_RMSE=np.sqrt(metrics.mean_squared_error(y_train, MARS_train))
print('training RMSE:',MARS_tr_RMSE)

MARS_tr_MAE=metrics.mean_absolute_error(y_train,MARS_train)
print('training MAE:',MARS_tr_MAE)

MARS_tr_MAPE=metrics.mean_absolute_percentage_error(y_train,MARS_train)
print('training MAPE:',MARS_tr_MAPE)
 
#MARS使用全變數績效 (testing)
MARS_test = MARS_marine.predict(x_test)

MARS_ts_RMSE=np.sqrt(metrics.mean_squared_error(y_test, MARS_test))
print('testing RMSE:',MARS_ts_RMSE)

MARS_ts_MAE=metrics.mean_absolute_error(y_test,MARS_test)
print('testing MAE:',MARS_ts_MAE)

MARS_ts_MAPE=metrics.mean_absolute_percentage_error(y_test,MARS_test)
print('testing MAPE:',MARS_ts_MAPE)


#%%將重要的變數使用SVR、DNN模型預測
df=data[['Container', 'GCTI','SCFI','CCFI','Retail value_CN', 'Retail sales index_US']]
x_train, y_train = df.iloc[0:132,1:], df.iloc[0:132,0 ]
x_test, y_test = df.iloc[132:153,1: ], df.iloc[132:153,0]
print(x_train.shape, y_train.shape, x_test.shape, y_test.shape)

#%%將x變數標準化
X_scaler = MinMaxScaler()
X_train=X_scaler.fit_transform(x_train)
X_test=X_scaler.transform(x_test)

#%%SVR調參
parameters = {'kernel':['rbf','sigmoid','poly'], 'C':[10,30,50], 
              'gamma':[5,10,15], 'epsilon':[0.05,0.1,0.15],'degree':[1,2,3]}

svr= SVR()
grid = GridSearchCV(svr, param_grid=parameters,cv=3)
grid.fit(X_train,y_train)
grid.cv_results_, grid.best_params_, grid.best_score_

#%%建立SVR模型
print(grid.best_params_)
svr = SVR(kernel=grid.best_params_['kernel'],C=grid.best_params_['C'],epsilon=grid.best_params_['epsilon']
          ,gamma=grid.best_params_['gamma'],degree=grid.best_params_['degree'])
svr.fit(X_train,y_train)

#%%SVR模型績效
SVR_train = svr.predict(X_train)

SVR_tr_RMSE=np.sqrt(metrics.mean_squared_error(y_train, SVR_train))
print('training RMSE:',SVR_tr_RMSE)

SVR_tr_MAE=metrics.mean_absolute_error(y_train,SVR_train)
print('training MAE:',SVR_tr_MAE)

SVR_tr_MAPE=metrics.mean_absolute_percentage_error(y_train,SVR_train)
print('training MAPE:',SVR_tr_MAPE)

SVR_test = svr.predict(X_test)

SVR_ts_RMSE=np.sqrt(metrics.mean_squared_error(y_test, SVR_test))
print('testing RMSE:',SVR_ts_RMSE)

SVR_ts_MAE=metrics.mean_absolute_error(y_test,SVR_test)
print('testing MAE:',SVR_ts_MAE)

SVR_ts_MAPE=metrics.mean_absolute_percentage_error(y_test,SVR_test)
print('testing MAPE:',SVR_ts_MAPE)

#%%DNN Bulid the model
es = EarlyStopping(monitor='val_loss', mode='min', patience = 20, verbose=1)
def build_model(first_hidden_neuron, n_dropout, n_hidden, n_neurons,
                learning_rate, activation, kernel_initializer,
                n_epochs, n_batch_size, select_optimizer):
    model = Sequential()
    model.add(Dense(first_hidden_neuron, input_dim=len(X_train[0]), activation=activation, kernel_initializer=kernel_initializer))
    for layer in range(n_hidden):
        model.add(Dense(n_neurons, activation=activation, kernel_initializer=kernel_initializer))
        model.add(Dropout(n_dropout))
        
    model.add(Dense(1, activation='linear'))
    
    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='mean_squared_error', optimizer=optimizer)
    
    model.fit(X_train, y_train, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2, callbacks=[es])
    return model

keras = KerasRegressor(build_model)  

#%% Randomized Search
# Parameters sets
params_DNN = {
        "n_dropout":[0.1,0.15,0.2],
        "n_hidden":[2,3,4],
        'first_hidden_neuron':[15,30],
        "n_neurons":[30,60,90],
        "learning_rate":[0.05,0.15,0.25],
        "activation":['relu', 'softplus','elu'],
        "n_epochs":[100,200],
        "n_batch_size":[6,8,10],
        "select_optimizer":[optimizers.Adam,optimizers.Adagrad,optimizers.RMSprop],
        "kernel_initializer": ['glorot_uniform', 'he_normal', 'lecun_normal']
        }
# Randomized Search
RS_cv=RandomizedSearchCV(keras,params_DNN,n_iter=10,cv=3,random_state=516)
RS_cv.fit(X_train,y_train)
print(RS_cv.best_params_)

# Best model
DNN=RS_cv.best_estimator_

#%%
# Prediction
DNN_train = DNN.predict(X_train)

# DNN Result
DNN_tr_RMSE=np.sqrt(metrics.mean_squared_error(y_train,np.nan_to_num(DNN_train).flatten()))
print('training RMSE:',DNN_tr_RMSE)

DNN_tr_MAE=metrics.mean_absolute_error(y_train,np.nan_to_num(DNN_train).flatten())
print('training MAE:',DNN_tr_MAE)

DNN_tr_MAPE=metrics.mean_absolute_percentage_error(y_train,np.nan_to_num(DNN_train).flatten())
print('training MAPE:',DNN_tr_MAPE)

DNN_test = DNN.predict(X_test)

DNN_ts_RMSE=np.sqrt(metrics.mean_squared_error(y_test,np.nan_to_num(DNN_test).flatten()))
print('testing RMSE:',DNN_ts_RMSE)

DNN_ts_MAE=metrics.mean_absolute_error(y_test,np.nan_to_num(DNN_test).flatten())
print('testing MAE:',DNN_ts_MAE)

DNN_ts_MAPE=metrics.mean_absolute_percentage_error(y_test,np.nan_to_num(DNN_test).flatten())
print('testing MAPE:',DNN_ts_MAPE)

#%%
# 航運各模型績效
#training
perf_tr = pd.DataFrame()
perf_tr["MLR"] = [MLR_tr_RMSE,MLR_tr_MAE,MLR_tr_MAPE]
perf_tr["MARS"] = [MARS_tr_RMSE,MARS_tr_MAE,MARS_tr_MAPE]
perf_tr["SVR"] = [SVR_tr_RMSE,SVR_tr_MAE,SVR_tr_MAPE]
perf_tr["DNN"] = [DNN_tr_RMSE,DNN_tr_MAE,DNN_tr_MAPE]
perf_tr.index = ["RMSE","MAE","MAPE"]
print("\n Performance of training\n")
print(perf_tr)
print("\n")

#testing
perf_ts = pd.DataFrame()
perf_ts["MLR"] = [MLR_ts_RMSE,MLR_ts_MAE,MLR_ts_MAPE]
perf_ts["MARS"] = [MARS_ts_RMSE,MARS_ts_MAE,MARS_ts_MAPE]
perf_ts["SVR"] = [SVR_ts_RMSE,SVR_ts_MAE,SVR_ts_MAPE]
perf_ts["DNN"] = [DNN_ts_RMSE,DNN_ts_MAE,DNN_ts_MAPE]
perf_ts.index = ["RMSE","MAE","MAPE"]
print("\n Performance of testing\n")
print(perf_ts)

#%%
# plot實際值與預測值
real=pd.concat([pd.DataFrame(y_train),pd.DataFrame(y_test)],axis=0)
real.index= pd.date_range('2011',periods = 153,freq = '1m')
MLR_pred=pd.concat([pd.DataFrame(MLR_train),pd.DataFrame(MLR_test)],axis=0)
MLR_pred=MLR_pred.reset_index(drop=True)
MLR_pred.index= pd.date_range('2011',periods = 153,freq = '1m')
MARS_pred=pd.concat([pd.DataFrame(MARS_train),pd.DataFrame(MARS_test)],axis=0)
MARS_pred=MARS_pred.reset_index(drop=True)
MARS_pred.index= pd.date_range('2011',periods = 153,freq = '1m')
#SVR_pred=pd.concat([pd.DataFrame(SVR_train),pd.DataFrame(SVR_test)],axis=0)
#SVR_pred=SVR_pred.reset_index(drop=True)
#SVR_pred.index= pd.date_range('2011',periods = 153,freq = '1m')
DNN_pred=pd.concat([pd.DataFrame(DNN_train),pd.DataFrame(DNN_test)],axis=0)
DNN_pred=DNN_pred.reset_index(drop=True)
DNN_pred.index= pd.date_range('2011',periods = 153,freq = '1m')

plt.figure(figsize=(20,10))
plt.plot( real, color='black', label="Real",linewidth=1.5)
plt.plot( MLR_pred, color='orange', label="MLR_pred",linewidth=1.5)
plt.plot( MARS_pred, color='blue', label="MARS_pred",linewidth=1.5)
#plt.plot( SVR_pred, color='green', label="SVR_pred",linewidth=1.5)
plt.plot( DNN_pred, color='red', label="DNN_pred",linewidth=1.5)

plt.legend(loc = 'lower left')
plt.legend(fontsize=15)
plt.xlabel('Date', size=15)
plt.ylabel('Container Revenue', size=15)