# -*- coding: utf-8 -*-
"""
Created on Fri Apr 15 10:04:24 2022

@author: ku
"""

#%%
import numpy as np
import pandas as pd
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from tensorflow.keras.layers import Dense, Activation, Dropout,BatchNormalization, LSTM ,GRU ,SimpleRNN
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn import metrics
from tensorflow.keras import optimizers
from tensorflow.keras.wrappers.scikit_learn import KerasRegressor
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
import matplotlib.pyplot as plt
from skopt import BayesSearchCV

#%%
#載入DATA
power = pd.read_csv('electricity.csv')
power=power.drop(['Time','WEP','MEP'],axis=1)
df = power[['IPI','AverageTemp','ExportOrderAmount','ImportTotalValue_MachineryandEquipment','Humidity','SeasonIndex',
               'PM10','TotalDemand']]
print("資料特徵數(x+y)："+str(len(list(power.columns))))#+str(len(list(power.columns)))
print(power.columns)

x = df.iloc[0:289, 0:7]
y = df.iloc[0:289, 7]

x_train= df.iloc[0:264, 0:7]
y_train= df.iloc[0:264, 7]
x_test= df.iloc[264:288, 0:7]
y_test= df.iloc[264:288, 7]

print(x_train.shape, y_train.shape, x_test.shape, y_test.shape)

#%%
#DNN 標準化
X_scaler = MinMaxScaler()
X_train=X_scaler.fit_transform(x_train)
X_test=X_scaler.transform(x_test)
print(X_train.shape, y_train.shape, X_test.shape, y_test.shape)

#%%
#cell=Dense
es = EarlyStopping(monitor='val_loss', mode='min', patience = 20, verbose=1)
def bulid_model(first_hidden_neuron, n_dropout, n_hidden, n_neurons,kernel_initializer,
                learning_rate, activation, n_epochs, n_batch_size, select_optimizer):
    
    model = Sequential()
    model.add(Dense(first_hidden_neuron,input_dim=len(X_train[0]),activation=activation,kernel_initializer=kernel_initializer))
    for layer in range(n_hidden):
        model.add(Dense(n_neurons,activation=activation,kernel_initializer=kernel_initializer))
        model.add(Dropout(n_dropout))
        
    model.add(Dense(1,activation='linear'))
    
    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='mean_squared_error',optimizer=optimizer)
    
    model.fit(X_train,y_train, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2, callbacks=[es])
    return model

keras=KerasRegressor(bulid_model)

#%%
#DNN調參
params_DNN = {
        "n_dropout":[0.1,0.2,0.3],
        "n_hidden":[2,3,4],
        'first_hidden_neuron':[30],
        "n_neurons":[50,75,100],
        "learning_rate":[0.01,0.05,0.1],
        "activation":['relu','softplus','elu'],
        "n_epochs":[200],
        "n_batch_size":[8,16],
        "kernel_initializer": ['glorot_uniform', 'lecun_normal'], #'uniform'
        "select_optimizer":[optimizers.Adam, optimizers.RMSprop, optimizers.Adagrad]
        }

# Randomized Search
RS_cv=RandomizedSearchCV(keras,params_DNN,n_iter=20,cv=3,random_state=516, scoring='neg_mean_squared_error')
RS_cv.fit(X_train,y_train)
print(RS_cv.best_params_)
#{'select_optimizer': <class 'keras.optimizers.optimizer_v2.rmsprop.RMSprop'>, 'n_neurons': 90, 'n_hidden': 2, 'n_epochs': 200, 'n_dropout': 0.2, 'n_batch_size': 16, 'learning_rate': 0.01, 'kernel_initializer': 'glorot_uniform', 'first_hidden_neuron': 30, 'activation': 'relu'}
DNN = RS_cv.best_estimator_

#%%
DNN_train = DNN.predict(X_train)

DNN_RMSEr=np.sqrt(metrics.mean_squared_error(y_train, DNN_train))
print('training RMSE:',DNN_RMSEr)
DNN_MAEr=metrics.mean_absolute_error(y_train, DNN_train)
print('training MAE:',DNN_MAEr)
DNN_MAPEr=metrics.mean_absolute_percentage_error(y_train, DNN_train)
print('training MAPE:',DNN_MAPEr)

DNN_test = DNN.predict(X_test)

DNN_RMSEs=np.sqrt(metrics.mean_squared_error(y_test, DNN_test))
print('testing RMSE:',DNN_RMSEs)
DNN_MAEs=metrics.mean_absolute_error(y_test, DNN_test)
print('testing MAE:',DNN_MAEs)
DNN_MAPEs=metrics.mean_absolute_percentage_error(y_test, DNN_test)
print('testing MAPE:',DNN_MAPEs)

#%%RNN GRU LSTM標準化
#X_scaler = MinMaxScaler()
#X_train=X_scaler.fit_transform(x_train)
#X_test=X_scaler.transform(x_test)
y_train, y_test = y_train.values.reshape(-1, 1), y_test.values.reshape(-1, 1)

t_value=1
xx_train = X_train.reshape((X_train.shape[0], t_value, int(X_train.shape[1]/t_value)))
xx_test = X_test.reshape((X_test.shape[0], t_value, int(X_test.shape[1]/t_value)))
print(xx_train.shape, y_train.shape, xx_test.shape, y_test.shape)

#%%
#cell=eval('SimpleRNN')
#cell=eval('LSTM')
cell=eval('GRU')

es = EarlyStopping(monitor='val_loss', mode='min', patience = 20, verbose=1)
def bulid_model(n_dropout, n_hidden,n_neurons,learning_rate, activation, n_epochs, n_batch_size, select_optimizer):
    
    model = Sequential()
    for layer in range(n_hidden):
        model.add(cell(units=n_neurons,input_shape=(xx_train.shape[1], xx_train.shape[2]),activation=activation,return_sequences=True))
        model.add(Dropout(n_dropout))
        
    model.add(cell(units=n_neurons,input_shape=(xx_train.shape[1], xx_train.shape[2]),activation=activation,return_sequences=False))    
    model.add(Dense(1,activation='linear'))

    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='mean_absolute_percentage_error',optimizer=optimizer)
    
    model.fit(xx_train,y_train, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2, callbacks=[es])
    return model

keras=KerasRegressor(bulid_model)

#%%
#RNN調參
params_DL = {
        "n_dropout":[0.1,0.2,0.3],
        "n_hidden":[1,2,3],
        "n_neurons":[50,70,90],
        "learning_rate":[0.01,0.05,0.1],
        "activation":['relu','softplus','elu'],
        "n_epochs":[300],
        "n_batch_size":[8,16],
        "select_optimizer":[optimizers.Adam, optimizers.RMSprop, optimizers.Adagrad]
        }

#Bayes search
BS_cv=BayesSearchCV(keras,params_DL,n_iter=10,cv=3,random_state=516, scoring = 'neg_mean_absolute_percentage_error') 
BS_cv.fit(xx_train,y_train)
print(BS_cv.best_params_)
RNN= BS_cv.best_estimator_
LSTM = BS_cv.best_estimator_
GRU = BS_cv.best_estimator_


#%%
#{'select_optimizer': <class 'keras.optimizers.optimizer_v2.adam.Adam'>, 'n_neurons': 70, 'n_hidden': 2, 'n_epochs': 300, 'n_dropout': 0.3, 'n_batch_size': 8, 'learning_rate': 0.01, 'activation': 'elu'}
RNN_train = RNN.predict(xx_train)

RNN_RMSEr=np.sqrt(metrics.mean_squared_error(y_train, RNN_train))
print('training RMSE:',RNN_RMSEr)

RNN_MAEr=metrics.mean_absolute_error(y_train, RNN_train)
print('training MAE:',RNN_MAEr)

RNN_MAPEr=metrics.mean_absolute_percentage_error(y_train, RNN_train)
print('training MAPE:',RNN_MAPEr)

RNN_test = RNN.predict(xx_test)

RNN_RMSEs=np.sqrt(metrics.mean_squared_error(y_test, RNN_test))
print('testing RMSE:',RNN_RMSEs)

RNN_MAEs=metrics.mean_absolute_error(y_test, RNN_test)
print('testing MAE:',RNN_MAEs)

RNN_MAPEs=metrics.mean_absolute_percentage_error(y_test, RNN_test)
print('testing MAPE:',RNN_MAPEs)

#%%
#{'select_optimizer': <class 'keras.optimizers.optimizer_v2.adam.Adam'>, 'n_neurons': 70, 'n_hidden': 2, 'n_epochs': 300, 'n_dropout': 0.3, 'n_batch_size': 8, 'learning_rate': 0.01, 'activation': 'elu'}
GRU_train = GRU.predict(xx_train)

GRU_RMSEr=np.sqrt(metrics.mean_squared_error(y_train, GRU_train))
print('training RMSE:',GRU_RMSEr)
GRU_MAEr=metrics.mean_absolute_error(y_train, GRU_train)
print('training MAE:',GRU_MAEr)
GRU_MAPEr=metrics.mean_absolute_percentage_error(y_train, GRU_train)
print('training MAPE:',GRU_MAPEr)

GRU_test = GRU.predict(xx_test)

GRU_RMSEs=np.sqrt(metrics.mean_squared_error(y_test, GRU_test))
print('testing RMSE:',GRU_RMSEs)
GRU_MAEs=metrics.mean_absolute_error(y_test, GRU_test)
print('testing MAE:',GRU_MAEs)
GRU_MAPEs=metrics.mean_absolute_percentage_error(y_test, GRU_test)
print('testing MAPE:',GRU_MAPEs)

#%%
#{'select_optimizer': <class 'keras.optimizers.optimizer_v2.adam.Adam'>, 'n_neurons': 50, 'n_hidden': 3, 'n_epochs': 300, 'n_dropout': 0.3, 'n_batch_size': 16, 'learning_rate': 0.01, 'activation': 'softplus'}
LSTM_train = LSTM.predict(xx_train)

LSTM_RMSEr=np.sqrt(metrics.mean_squared_error(y_train, LSTM_train))
print('training RMSE:',LSTM_RMSEr)
LSTM_MAEr=metrics.mean_absolute_error(y_train, LSTM_train)
print('training MAE:',LSTM_MAEr)
LSTM_MAPEr=metrics.mean_absolute_percentage_error(y_train, LSTM_train)
print('training MAPE:',LSTM_MAPEr)

LSTM_test = LSTM.predict(xx_test)

LSTM_RMSEs=np.sqrt(metrics.mean_squared_error(y_test, LSTM_test))
print('testing RMSE:',LSTM_RMSEs)
LSTM_MAEs=metrics.mean_absolute_error(y_test, LSTM_test)
print('testing MAE:',LSTM_MAEs)
LSTM_MAPEs=metrics.mean_absolute_percentage_error(y_test, LSTM_test)
print('testing MAPE:',LSTM_MAPEs)

#%%
perf_tr = pd.DataFrame({
    'Training':['RMSE','MAE','MAPE'],
    'DNN':[round(x, 3) for x in (DNN_RMSEr,DNN_MAEr,DNN_MAPEr)],
    'RNN':[round(x, 3) for x in (RNN_RMSEr,RNN_MAEr,RNN_MAPEr)],
    'GRU':[round(x, 3) for x in(GRU_RMSEr,GRU_MAEr,GRU_MAPEr)],
    'LSTM':[round(x, 3) for x in(LSTM_RMSEr,LSTM_MAEr,LSTM_MAPEr)],
})

perf_ts = pd.DataFrame({
    'Testing':['RMSE','MAE','MAPE'],
    'DNN':[round(x, 3) for x in (DNN_RMSEs,DNN_MAEs,DNN_MAPEs)],
    'RNN':[round(x, 3) for x in (RNN_RMSEs,RNN_MAEs,RNN_MAPEs)],
    'GRU':[round(x, 3) for x in(GRU_RMSEs,GRU_MAEs,GRU_MAPEs)],
    'LSTM':[round(x, 3) for x in(LSTM_RMSEs,LSTM_MAEs,LSTM_MAPEs)],
})
performance_train = perf_tr.set_index(['Training'],drop=True)
performance_test = perf_ts.set_index(['Testing'],drop=True)

print(performance_train)
print('\n',performance_test)

#%%
# plot實際值與預測值
real=pd.concat([pd.DataFrame(y_train),pd.DataFrame(y_test)],axis=0)
real.index= pd.date_range('2001',periods = 288,freq = '1m')
DNN_pred=pd.concat([pd.DataFrame(DNN_train),pd.DataFrame(DNN_test)],axis=0)
DNN_pred=DNN_pred.reset_index(drop=True)
DNN_pred.index= pd.date_range('2001',periods = 288,freq = '1m')
RNN_pred=pd.concat([pd.DataFrame(RNN_train),pd.DataFrame(RNN_test)],axis=0)
RNN_pred=RNN_pred.reset_index(drop=True)
RNN_pred.index= pd.date_range('2001',periods = 288,freq = '1m')
GRU_pred=pd.concat([pd.DataFrame(GRU_train),pd.DataFrame(GRU_test)],axis=0)
GRU_pred=GRU_pred.reset_index(drop=True)
GRU_pred.index= pd.date_range('2001',periods = 288,freq = '1m')
LSTM_pred=pd.concat([pd.DataFrame(np.nan_to_num(LSTM_train).flatten()),pd.DataFrame(np.nan_to_num(LSTM_test).flatten())],axis=0)
LSTM_pred=LSTM_pred.reset_index(drop=True)
LSTM_pred.index= pd.date_range('2001',periods = 288,freq = '1m')

plt.figure(figsize=(20,10))
plt.plot( real, color='black', label="Real",linewidth=1.5)
plt.plot( DNN_pred, color='yellow', label="DNN_pred",linewidth=1.5)
plt.plot( RNN_pred, color='blue', label="RNN_pred",linewidth=1.5)
plt.plot( GRU_pred, color='green', label="DRU_pred",linewidth=1.5)
plt.plot( LSTM_pred, color='red', label="LSTM_pred",linewidth=1.5)

plt.legend(loc = 'lower left')
plt.legend(fontsize=15)
plt.title('Comparison of Actual and Predicted')
plt.xlabel('Date', size=15)
plt.ylabel('electricity Demand', size=15)