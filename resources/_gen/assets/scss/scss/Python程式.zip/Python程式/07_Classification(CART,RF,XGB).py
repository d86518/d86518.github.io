#Import packages
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, RandomizedSearchCV
#from sklearn.metrics import accuracy_score
from sklearn import metrics
from sklearn import tree
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
import warnings
from sklearn.metrics import confusion_matrix, accuracy_score, roc_curve, roc_auc_score, auc
from sklearn.metrics import roc_curve
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
#warnings.filterwarnings('ignore') #Ignore warning message
np.random.seed(516)

#%%
#############
###Titanic###   Classifier--->DecisionTree/RandomForest/XGBoost
#############
#%%
#load titanic data
df=pd.read_csv("titanic.csv")

#Remove Na and outlier
df = df.dropna(subset=['fare'])  #Remove NaN for 'fare' feature
df = df[df.age != 9999 ]   #Remove 9999 for age
df = df[df.fare != 9999]   #Remove 9999 for fare

#Select Variable
titan = df[['gender','age','class','fare','survival']]#Select Vatiable

#Encoding the target
titan.survival = titan.survival.replace(0,'No')
titan.survival = titan.survival.replace(1,'Yes')
titan.survival= pd.Series(titan.survival.astype("category"))
titan.gender= pd.Series(titan.gender.astype("category"))
print(titan)

#Get X and Y
titan_y = titan.survival
titan_x = titan
del titan_x['survival']

#Split train-test subset
titan_train_x,titan_test_x,titan_train_y,titan_test_y = train_test_split(titan_x,titan_y,test_size=0.25,random_state=1)

#%%
titan = df[['gender','age','class','fare','survival']]#Select Variable
#Encoding the target
titan.survival = titan.survival.replace(0,'No')
titan.survival = titan.survival.replace(1,'Yes')
titan.survival= pd.Series(titan.survival.astype("category"))
titan.gender= pd.Series(titan.gender.astype("category"))
print(titan)

## Dummy variable
titan.gender = titan.gender.replace(0,'male')
titan.gender = titan.gender.replace(1,'female')
titan=pd.get_dummies(titan,columns=['gender'],drop_first=True)
titan=pd.get_dummies(titan,columns=['class'],drop_first=True)

# #Get X and Y
titan_y_dum = titan.survival
titan_x_dum = titan
del titan_x_dum['survival']

# #Split train-test subset
titan_train_x,titan_test_x,titan_train_y,titan_test_y =  train_test_split(titan_x_dum,titan_y_dum,test_size=0.2,random_state=1)

#%%
##DecisionTree##
print("\n''''''''''''DecisionTree Classifier''''''''''''''''")
## Randominzed Search in DT
#parameter grid
params_DT = {'max_depth': list(range(2,5)), #The maximum depth of the tree
             'max_features': list(range(2,5)), #The size of the random subsets of features to consider when splitting a node.
             'min_samples_split': list(range(10,41,5)),# The minimum number of samples required to split an internal node
             'min_samples_leaf': list(range(5,21,5))}# The minimum number of samples required to be at a leaf node.

tunnDT = RandomizedSearchCV(DecisionTreeClassifier(), params_DT, cv=3)
tunnDT.fit(titan_train_x, titan_train_y)
    
#Get Best parameter
print('\nBest parameters :',tunnDT.best_params_)

#%%
#Build classifier
dt = DecisionTreeClassifier(criterion = 'gini',
                            max_depth = tunnDT.best_estimator_.max_depth,
                            max_features = tunnDT.best_estimator_.max_features, 
                            min_samples_split = tunnDT.best_estimator_.min_samples_split,
                            min_samples_leaf = tunnDT.best_estimator_.min_samples_leaf)
dt_titan = dt.fit(titan_train_x,titan_train_y)

#Plot decision tree structure
tree.plot_tree(dt_titan)
print(tree.export_text(dt_titan))

#Get importance of feature with sorting
titan_imp = pd.DataFrame({'Feature':titan_train_x.columns,
                         'Importance':dt_titan.feature_importances_})
print('\nFeature importance:\n',titan_imp.sort_values(by=['Importance'],ascending=False))

#%%
#Predict the train subset
train_pred = dt_titan.predict(titan_train_x)
train_conf = pd.crosstab(titan_train_y,train_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Training:\n',train_conf)

train_accu = accuracy_score(titan_train_y,train_pred,normalize = True)
print('\nAccuracy:',train_accu)

metrics.accuracy_score(titan_train_y, train_pred)
metrics.recall_score(titan_train_y, train_pred, pos_label='Yes', average='binary')
metrics.precision_score(titan_train_y, train_pred, pos_label='Yes', average='binary')
metrics.f1_score(titan_train_y, train_pred, pos_label='Yes', average='binary')

#Predict the test subset
test_pred = dt_titan.predict(titan_test_x)
test_conf = pd.crosstab(titan_test_y,test_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Testing:\n',test_conf)
dt_test_accu = accuracy_score(titan_test_y,test_pred,normalize = True)
print('\nAccuracy:',dt_test_accu)

dt_test_accuracy= metrics.accuracy_score(titan_test_y, test_pred)
dt_test_recall= metrics.recall_score(titan_test_y, test_pred, pos_label='Yes', average='binary')
dt_test_precision= metrics.precision_score(titan_test_y, test_pred, pos_label='Yes', average='binary')
dt_test_fmeasure= metrics.f1_score(titan_test_y, test_pred, pos_label='Yes', average='binary')

#%%

##RandomForest##
print("\n''''''''''''RandomForest Classifier''''''''''''''''")
## Randominzed Search in RF
#parameter grid
params_RF = {'n_estimators':list(range(50,151,20)), #The number of trees in the forest.
             'max_depth':list(range(2,5)),  #The maximum depth of the tree.
             'max_features':list(range(2,5)), #The number of features to consider when looking for the best split
             'min_samples_split':list(range(10,31,5)), #The minimum number of samples required to split an internal node
             'min_samples_leaf':list(range(5,21,5))} #The minimum number of samples required to be at a leaf node.

tunnRF = RandomizedSearchCV(RandomForestClassifier(), params_RF, cv = 3, random_state=(516))
tunnRF.fit(titan_train_x,titan_train_y)
    
#Get Best parameter
print('\nBest parameters :',tunnRF.best_params_)

#%%
#Build classifier
rf = RandomForestClassifier(criterion = 'gini',
                            n_estimators = tunnRF.best_estimator_.n_estimators,
                            max_depth = tunnRF.best_estimator_.max_depth,
                            max_features = tunnRF.best_estimator_.max_features, 
                            min_samples_split = tunnRF.best_estimator_.min_samples_split,
                            min_samples_leaf = tunnRF.best_estimator_.min_samples_leaf)
rf_titan = rf.fit(titan_train_x,titan_train_y)

#Get importance of feature with sorting
titan_imp = pd.DataFrame({'Feature':titan_train_x.columns,
                         'Importance':rf_titan.feature_importances_})
print('\nFeature importance:\n',titan_imp.sort_values(by=['Importance'],ascending=False))

#%%
#Predict the train subset
train_pred = rf_titan.predict(titan_train_x)
train_conf = pd.crosstab(titan_train_y,train_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Training:\n',train_conf)

train_accu = accuracy_score(titan_train_y,train_pred,normalize = True)
print('\nAccuracy:',train_accu)

metrics.accuracy_score(titan_train_y, train_pred)
metrics.recall_score(titan_train_y, train_pred, pos_label='Yes', average='binary')
metrics.precision_score(titan_train_y, train_pred, pos_label='Yes', average='binary')
metrics.f1_score(titan_train_y, train_pred, pos_label='Yes', average='binary')

#Predict the test subset
test_pred = rf_titan.predict(titan_test_x)
test_conf = pd.crosstab(titan_test_y,test_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Testing:\n',test_conf)

rf_test_accu = accuracy_score(titan_test_y,test_pred,normalize = True)
print('\nAccuracy:',rf_test_accu)

rf_test_accuracy= metrics.accuracy_score(titan_test_y, test_pred)
rf_test_recall= metrics.recall_score(titan_test_y, test_pred, pos_label='Yes', average='binary')
rf_test_precision= metrics.precision_score(titan_test_y, test_pred, pos_label='Yes', average='binary')
rf_test_fmeasure= metrics.f1_score(titan_test_y, test_pred, pos_label='Yes', average='binary')

 #%%
##XGBoost Classifier##
print("\n''''''''''''''''XGBoostClassifier''''''''''''''''")
# Prepare the data
titan_train_x_num = titan_train_x.astype(int)
titan_train_y_num = titan_train_y.replace('Yes',1).replace('No',0).astype(int)
titan_test_x_num = titan_test_x.astype(int)
titan_test_y_num = titan_test_y.replace('Yes',1).replace('No',0).astype(int)
## Randominzed Search in XGB

# parameter grid
xgb_candidates = {'n_estimators':list(range(50,151,20)), #The number of trees in the forest.
                  'max_depth':list(range(2,5)),  #The maximum depth of the tree.
                  'learning_rate':[0.1,0.05,0.01], #Step size shrinkage used in update to prevents overfitting.
                  'min_child_weight':[0.1,0.3,0.5], #The minimum sum of weights of all observations required in a child (not number of observations which is min_samples_leaf. ).
                  'colsample_bytree':[0.5,0.7,0.9]} #Similar to max_features. Denotes the fraction of columns to be randomly samples for each tree.
tunnXgb = RandomizedSearchCV(XGBClassifier(eval_metric='error'), xgb_candidates, cv = 3, random_state=(516))
tunnXgb.fit(titan_train_x_num,titan_train_y_num)

#Get Best parameter
print('\nBest parameters :',tunnXgb.best_params_)

#%%
#Build classifier
XGB = XGBClassifier(n_estimators=tunnXgb.best_estimator_.n_estimators,
                    learning_rate=tunnXgb.best_estimator_.learning_rate,
                    max_depth=tunnXgb.best_estimator_.max_depth,
                    min_child_weight=tunnXgb.best_estimator_.min_child_weight,
                    colsample_bytree=tunnXgb.best_estimator_.colsample_bytree,
                    eval_metric='error')
xgb_titan = XGB.fit(titan_train_x_num,titan_train_y_num)

#Get importance of feature with sorting
titan_imp_xgb = pd.DataFrame({'Feature':titan_train_x.columns,'Importance':xgb_titan.feature_importances_})
print('\nFeature importance:\n',titan_imp_xgb.sort_values(by=['Importance'],ascending=False))

#%%
#Predict the train subset
train_pred = xgb_titan.predict(titan_train_x_num)
train_pred = pd.Series(train_pred).replace(1,'Yes').replace(0,'No').astype("category")
train_conf = pd.crosstab(titan_train_y,train_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Training:\n',train_conf)

train_accu = accuracy_score(titan_train_y,train_pred,normalize = True)
print('\nAccuracy:',train_accu)

#Predict the test subset
test_pred = xgb_titan.predict(titan_test_x_num)
test_pred = pd.Series(test_pred).replace(1,'Yes').replace(0,'No').astype("category")
test_conf = pd.crosstab(titan_test_y.reset_index(drop=True),test_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Testing:\n',test_conf)

xgb_test_accu = accuracy_score(titan_test_y,test_pred,normalize = True)
print('\nAccuracy:',xgb_test_accu)

xgb_test_accuracy= metrics.accuracy_score(titan_test_y, test_pred)
xgb_test_recall= metrics.recall_score(titan_test_y, test_pred, pos_label='Yes', average='binary')
xgb_test_precision= metrics.precision_score(titan_test_y, test_pred, pos_label='Yes', average='binary')
xgb_test_fmeasure= metrics.f1_score(titan_test_y, test_pred, pos_label='Yes', average='binary')

#%%
print('Titanic data')
print('Accuracy of Using Decision Tree Classifier  =',dt_test_accu)
print('Accuracy of Using Random Forest Classifier  =',rf_test_accu)
print('Accuracy of Using XGB Classifier  =',xgb_test_accu)

print('Recall of Using Decision Tree Classifier  =',dt_test_recall)
print('Recall of Using Random Forest Classifier  =',rf_test_recall)
print('Recall of Using XGB Classifier  =',xgb_test_recall)

print('Precision of Using Decision Tree Classifier  =',dt_test_precision)
print('Preciison of Using Random Forest Classifier  =',rf_test_precision)
print('Preciison of Using XGB Classifier  =',xgb_test_precision)

print('Fmeasure of Using Decision Tree Classifier  =',dt_test_fmeasure)
print('Fmeasure of Using Random Forest Classifier  =',rf_test_fmeasure)
print('Fmeasure of Using XGB Classifier  =',xgb_test_fmeasure)

#%%

#%%
###########
###Churn###   Classifier--->DecisionTree/RandomForest/XGBoost
###########
'''
x1: time spent on long-distance call per month, x2: international calls, 
x3: local calls, x4: number of dropped calls, x5: payment method for the bill, 
x6: tariff for local calls, x7: tariff for long-distance calls, x8: age, x9: gender, 
x10: marital status, x11: # of children, x12: income, x13: car owner, x14: churn labels
Current (not churned), Vol: valuable churner, InVol: leavers (don’t care)
'''
#Read file
churn = pd.read_csv('churn.txt', sep = ',')
del churn['ID'] # remove customer ID
churn.info()

churn.SEX = churn.SEX.replace('F',0)
churn.SEX = churn.SEX.replace('M',1)
churn.Car_Owner = churn.Car_Owner.replace('N',0)
churn.Car_Owner = churn.Car_Owner.replace('Y',1)
churn.STATUS = churn.STATUS.replace('M',0)
churn.STATUS = churn.STATUS.replace('S',1)

#Preprocessing - get dummy variable
dummy = pd.get_dummies(churn[['PAY_MTHD','LocalBillType','LongDistanceBillType']],
                       prefix = ['PAY_MTHD','LocalBillType','LongDistanceBillType'], prefix_sep = '-',drop_first=True)
churn_dummy = churn.join(dummy)
churn_dummy = churn_dummy.drop(['PAY_MTHD','LocalBillType','LongDistanceBillType'], axis = 1)

#Get X and Y
churn_y = churn_dummy['CHURNED']
churn_x = churn_dummy
del churn_x['CHURNED']

#Split train-test subset
churn_train_x,churn_test_x,churn_train_y,churn_test_y = train_test_split(churn_x,churn_y,test_size=0.3,random_state=None)


#%%
##DecisionTree##
print("\n''''''''''''DecisionTree Classifier''''''''''''''''")
## Randominzed Search in DT
#parameter grid
params_DT = {'max_depth': list(range(2,6)), #The maximum depth of the tree
             'max_features': list(range(2,12)), #The size of the random subsets of features to consider when splitting a node.
             'min_samples_split': list(range(10,30)),# The minimum number of samples required to split an internal node
             'min_samples_leaf': list(range(5,20))}# The minimum number of samples required to be at a leaf node.


tunnDT = RandomizedSearchCV(DecisionTreeClassifier(), params_DT, cv=5, random_state=(516))
tunnDT.fit(churn_train_x, churn_train_y)
    
#Get Best parameter
print('\nBest parameters :',tunnDT.best_params_)

#Build classifier
dt = DecisionTreeClassifier(criterion = 'gini',max_depth = tunnDT.best_estimator_.max_depth,
                             max_features = tunnDT.best_estimator_.max_features, 
                             min_samples_split = tunnDT.best_estimator_.min_samples_split,
                             min_samples_leaf = tunnDT.best_estimator_.min_samples_leaf)
dt_churn = dt.fit(churn_train_x,churn_train_y)

#Plot decision tree structure
tree.plot_tree(dt_churn)
print(tree.export_text(dt_churn))

#%%
#Get importance of feature with sorting
churn_imp = pd.DataFrame({'Feature':churn_train_x.columns,
                         'Importance':dt_churn.feature_importances_})
print('\nFeature importance:\n',churn_imp.sort_values(by=['Importance'],ascending=False))

#Predict the train subset
train_pred = dt_churn.predict(churn_train_x)
train_conf = pd.crosstab(churn_train_y,train_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Training:\n',train_conf)
train_accu = accuracy_score(churn_train_y,train_pred,normalize = True)
print('\nAccuracy:',train_accu)

#Predict the test subset
test_pred = dt_churn.predict(churn_test_x)
test_conf = pd.crosstab(churn_test_y,test_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Testing:\n',test_conf)
dt_test_accu = accuracy_score(churn_test_y,test_pred,normalize = True)
print('\nAccuracy:',dt_test_accu)

#%%
##RandomForest##
print("\n''''''''''''RandomForest Classifier''''''''''''''''")
## Randominzed Search in RF
#parameter grid
params_RF = {'n_estimators':list(range(50,150,20)), #The number of trees in the forest.
             'max_depth':list(range(2,7)),  #The maximum depth of the tree.
             'max_features':list(range(2,14)), #The number of features to consider when looking for the best split
             'min_samples_split':list(range(10,30)), #The minimum number of samples required to split an internal node
             'min_samples_leaf':list(range(5,20))} #The minimum number of samples required to be at a leaf node.

tunnRF = RandomizedSearchCV(RandomForestClassifier(), params_RF, cv = 5, random_state=(516))
tunnRF.fit(churn_train_x,churn_train_y)
    
#Get Best parameter
print('\nBest parameters :',tunnRF.best_params_)

#Build classifier
rf = RandomForestClassifier(n_estimators = tunnRF.best_params_['n_estimators'],criterion = 'gini',
                            max_depth = tunnRF.best_params_['max_depth'],
                            max_features = tunnRF.best_params_['max_features'], 
                            min_samples_split = tunnRF.best_params_.min_samples_split,
                             min_samples_leaf = tunnRF.best_params_.min_samples_leaf)
rf_churn = rf.fit(churn_train_x,churn_train_y)

#%%
#Get importance of feature with sorting
churn_imp = pd.DataFrame({'Feature':churn_train_x.columns,
                         'Importance':rf_churn.feature_importances_})
print('\nFeature importance:\n',churn_imp.sort_values(by=['Importance'],ascending=False))

#Predict the train subset
train_pred = rf_churn.predict(churn_train_x)
train_conf = pd.crosstab(churn_train_y,train_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Training:\n',train_conf)
train_accu = accuracy_score(churn_train_y,train_pred,normalize = True)
print('\nAccuracy:',train_accu)

#Predict the test subset
test_pred = rf_churn.predict(churn_test_x)
test_conf = pd.crosstab(churn_test_y,test_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Testing:\n',test_conf)
rf_test_accu = accuracy_score(churn_test_y,test_pred,normalize = True)
print('\nAccuracy:',rf_test_accu)

#%%
##XGBoost Classifier##
print("\n''''''''''''''''XGBoostClassifier''''''''''''''''")
# Prepare the data
churn_train_x_num = churn_train_x.astype(int)
churn_train_y_num = churn_train_y.replace('Current',0).replace('InVol',1).replace('Vol',2).astype(int)
churn_test_x_num = churn_test_x.astype(int)
churn_test_y_num = churn_test_y.replace('Current',0).replace('InVol',1).replace('Vol',2).astype(int)
## Randominzed Search in XGB

# parameter grid
xgb_candidates = {'n_estimators':list(range(50,151,20)), #The number of trees in the forest.
                  'max_depth':list(range(2,6)),  #The maximum depth of the tree.
                  'learning_rate':[0.1,0.05,0.01], #Step size shrinkage used in update to prevents overfitting.
                  'min_child_weight':[0.1,0.3,0.5], #The minimum sum of weights of all observations required in a child (not number of observations which is min_samples_leaf. ).
                  'colsample_bytree':[0.5,0.7,0.9]} #Similar to max_features. Denotes the fraction of columns to be randomly samples for each tree.
tunnXgb = RandomizedSearchCV(XGBClassifier(eval_metric='error'), xgb_candidates, cv = 5, random_state=(516))
tunnXgb.fit(churn_train_x_num,churn_train_y_num)

    
#Get Best parameter
print('\nBest parameters :',tunnXgb.best_params_)

#Build classifier
XGB = XGBClassifier(n_estimators=tunnXgb.best_estimator_.n_estimators,
                    learning_rate=tunnXgb.best_estimator_.learning_rate,
                    max_depth=tunnXgb.best_estimator_.max_depth,
                    min_child_weight=tunnXgb.best_estimator_.min_child_weight,
                    colsample_bytree=tunnXgb.best_estimator_.colsample_bytree,
                    eval_metric='mlogloss')
xgb_churn = XGB.fit(churn_train_x_num,churn_train_y_num)

#%%
#Get importance of feature with sorting
churn_imp_xgb = pd.DataFrame({'Feature':churn_train_x.columns,'Importance':xgb_churn.feature_importances_})
print('\nFeature importance:\n',churn_imp_xgb.sort_values(by=['Importance'],ascending=False))

#Predict the train subset
train_pred = xgb_churn.predict(churn_train_x_num)
train_pred = pd.Series(train_pred).replace(0,'Current').replace(1,'InVol').replace(2,'Vol').astype("category")
train_conf = pd.crosstab(churn_train_y,train_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Training:\n',train_conf)
train_accu = accuracy_score(churn_train_y,train_pred,normalize = True)
print('\nAccuracy:',train_accu)

#Predict the test subset
test_pred = xgb_churn.predict(churn_test_x_num)
test_pred = pd.Series(test_pred).replace(0,'Current').replace(1,'InVol').replace(2,'Vol').astype("category")
test_conf = pd.crosstab(churn_test_y.reset_index(drop=True),test_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix Testing:\n',test_conf)
xgb_test_accu = accuracy_score(churn_test_y,test_pred,normalize = True)
print('\nAccuracy:',xgb_test_accu)

#%%
print('Churn data')
print('Accuracy of Using Decision Tree Classifier  =',dt_test_accu)
print('Accuracy of Using Random Forest Classifier  =',rf_test_accu)
print('Accuracy of Using XGB Classifier  =',xgb_test_accu)

