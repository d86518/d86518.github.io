# -*- coding: utf-8 -*-
"""
Created on Wed Sep  8 16:19:59 2021

@author: a0978
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import davies_bouldin_score

#%%
#affinity==>metric

def optimal_HC(df,kmax,method):
    perf = []
    for k in range(2,kmax+1):
        HC = AgglomerativeClustering(n_clusters=k,affinity='euclidean',linkage=method)
        HC.fit_predict(X)
        curr_db = davies_bouldin_score(df, HC.labels_)
        perf.append(curr_db)
    print(perf)
    print('the optimal k which has the lowerest DBindex score')
    print(np.argmin(perf)+2)
    return perf

#%%
df = pd.read_csv('iris.csv')
X = df.iloc[:,0:4]
y = df['Species']

#%%
SL = optimal_HC(X,10,'single')
hc1 = AgglomerativeClustering(n_clusters=SL.index(min(SL))+2,affinity='euclidean',linkage='single')
single = hc1.fit_predict(X)
single_result = pd.concat([df, pd.DataFrame(single+1,columns=['Cluster'])], axis=1)
print(single_result)

# Cluster Means
print('\nCluster Centers:')
single_center = pd.DataFrame()
for k in set(single_result.Cluster):
    single_center[k]=single_result[single_result['Cluster']==k].iloc[:,0:4].mean(axis=0)[0:len(single_result)]
print(single_center.T)
single_center=single_center.T

# Confusion Matrix
cmatrix_hc1 = pd.crosstab(y, single+1, colnames=['Clusters'])
print("\nConfusion matrix:")
print(cmatrix_hc1)
cmatrix_hc1.apply(sum,axis=0)
single_center['Samples'] = cmatrix_hc1.apply(sum,axis=0)
print(single_center)

#Plot
plt.scatter(X.iloc[:,2],X.iloc[:,3],c=single)
plt.title('HC using Single Link'); plt.xlabel('Petal.Length');plt.ylabel('Petal.Width')
plt.show()

#%%
CL = optimal_HC(X,10,'complete')
hc2 = AgglomerativeClustering(n_clusters=CL.index(min(CL))+2,affinity='euclidean',linkage='complete')
complete = hc2.fit_predict(X)
complete_result = pd.concat([df, pd.DataFrame(complete+1,columns=['Cluster'])], axis=1)
print(complete_result)

# Cluster Means
print('\nCluster Centers:')
complete_center = pd.DataFrame()
for k in set(complete_result.Cluster):
    complete_center[k]=complete_result[complete_result['Cluster']==k].iloc[:,0:4].mean(axis=0)
print(complete_center.T)
complete_center=complete_center.T

# Confusion Matrix
cmatrix_hc2 = pd.crosstab(y, complete+1, colnames=['Clusters'])
print("\nConfusion matrix:")
print(cmatrix_hc2)
cmatrix_hc2.apply(sum,axis=0)
complete_center['Samples'] = cmatrix_hc2.apply(sum,axis=0)
print(complete_center)

# Plot
plt.scatter(X.iloc[:,2],X.iloc[:,3],c=complete)
plt.title('HC using Complete Link');plt.xlabel('Petal.Length');plt.ylabel('Petal.Width')
plt.show()

#%%
# Data preparation
data = pd.read_csv('gender_size.csv')
y = data['Gender']
X = data.drop(['Gender'],axis=1)

#%%
AL = optimal_HC(X,10,'average')
hc3 = AgglomerativeClustering(n_clusters=AL.index(min(AL))+2,affinity='euclidean',linkage='average')
average = hc3.fit_predict(X)
average_result = pd.concat([data, pd.DataFrame(average+1,columns=['Cluster'])], axis=1)
print(average_result)

# Cluster Means
print('\nCluster Centers:')
average_center = pd.DataFrame()
for k in set(average_result.Cluster):
    average_center[k]=average_result[average_result['Cluster']==k].iloc[:,0:3].mean(axis=0)[0:len(average_result.columns)]
print(average_center.T)
average_center=average_center.T

# Confusion Matrix
cmatrix_hc3 = pd.crosstab(y, average+1, colnames=['Cluster Number'])
print("\nConfusion matrix:")
print(cmatrix_hc3)
cmatrix_hc3.apply(sum,axis=0)
average_center['Samples'] = cmatrix_hc3.apply(sum,axis=0)
print(average_center)

# Plot
plt.scatter(X.iloc[:,0],X.iloc[:,1],c=average)
plt.title('HC using Group Average');plt.xlabel('Height');plt.ylabel('Weight')
plt.show()

#%%
WD = optimal_HC(X,10,'ward')
hc4 = AgglomerativeClustering(n_clusters=WD.index(min(WD))+2,affinity='euclidean',linkage='ward')
ward = hc4.fit_predict(X)
ward_result = pd.concat([data, pd.DataFrame(ward+1,columns=['Cluster'])], axis=1)
print(ward_result)

# Cluster Means
print('\nCluster Centers:')
ward_center = pd.DataFrame()
for k in set(ward_result.Cluster):
    ward_center[k]=ward_result[ward_result['Cluster']==k].iloc[:,0:3].mean(axis=0)
print(ward_center.T)
ward_center=ward_center.T

# Confusion Matrix
cmatrix_hc4 = pd.crosstab(y, ward+1, colnames=['Cluster Num.'])
print("\nConfusion matrix:")
print(cmatrix_hc4)
cmatrix_hc4.apply(sum,axis=0)
ward_center['Samples'] = cmatrix_hc4.apply(sum,axis=0)
print(ward_center)

# Plot
plt.scatter(X.iloc[:,0],X.iloc[:,1],c=ward)
plt.title("HC using Ward's Method");plt.xlabel('Height');plt.ylabel('Weight')
plt.show()
