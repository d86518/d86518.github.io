# -*- coding: utf-8 -*-
"""
Created on Wed Nov 10 09:01:25 2021

@author: MB516_SL
"""
#%%
# Import library
import random
import pandas as pd
import numpy as np
#from sklearn import metrics
from sklearn import preprocessing
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV, train_test_split
from sklearn.utils import class_weight
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, confusion_matrix, make_scorer
from tensorflow.keras import optimizers, initializers, metrics
from tensorflow.keras.wrappers.scikit_learn import KerasClassifier
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from skopt.space import Real, Categorical, Integer
from skopt import BayesSearchCV
from tensorflow.keras.layers import Conv1D, MaxPooling1D, Flatten

#%%
def calPerf_class(y_true, y_pred):
    temp_list = []
    acc = accuracy_score(y_true, y_pred)
    temp_list.append(acc)
    rec = recall_score(y_true, y_pred)
    temp_list.append(rec)
    pre = precision_score(y_true, y_pred)
    temp_list.append(pre)
    f1 = f1_score(y_true, y_pred)
    temp_list.append(f1)
    return temp_list

random.seed(516)
np.random.seed(1)

#%%
## Classification ##
# Data Pre-processing
df_ori = pd.read_csv('IC_test.csv')
df_y = df_ori['CoreState']
df_y.replace({"Good": 0, "Scrap": 1}, inplace=True)

df = df_ori.drop(['CoreState','TipLength'], axis=1)
dum = pd.get_dummies(df.loc[:,df.dtypes=='object'],drop_first=True)
df_x = pd.merge(df.loc[:,df.dtypes!='object'],dum,left_index=True,right_index=True)

#%%
##RandomForest##
## Randominzed Search in RF
#parameter grid
params_RF = {'n_estimators':list(range(50,150,30)), #The number of trees in the forest.
             'max_depth':list(range(3,7)),  #The maximum depth of the tree.
             'max_features':list(range(4,10,2)), #The number of features to consider when looking for the best split
             'min_samples_split':list((20,30,40)), #The minimum number of samples required to split an internal node
             'min_samples_leaf':list((10,20,30))} #The minimum number of samples required to be at a leaf node.

rf = GridSearchCV(RandomForestClassifier(random_state=516), params_RF, cv = 3)
#tunnRF = RandomizedSearchCV(RandomForestClassifier(random_state=516), params_RF, cv = 3 )
rf.fit(df_x,df_y)
print('\nBest parameters :',rf.best_params_)
RF= rf.best_estimator_

#Get importance of feature with sorting
ic_imp = pd.DataFrame({'Feature':df_x.columns,
                       'Importance':RF.feature_importances_
                       })
print('\nFeature importance:\n',ic_imp.sort_values(by=['Importance'],ascending=False))

#'Cumulative': np.cumsum(RF.feature_importances_)
#%%
# Define KPI
KPI = ['CurrentTD','CleanOD','P_Size','vender_FO','TestOD','CleanTouchdown','vender_YO','vender_FO','Leads']
df_X = df_x[KPI]

# Train/test split
train_X, test_X, train_y, test_y = train_test_split(df_X, df_y, test_size=0.3, random_state=516)
print(train_X.shape, train_y.shape, test_X.shape, test_y.shape)

# Normalization
X_scaler = preprocessing.MinMaxScaler()
train_xx = X_scaler.fit_transform(train_X)
test_xx = X_scaler.transform(test_X)

#%%
# SVM
np.random.seed(1)
params_SVM = {'C': np.random.uniform(low=10, high=100, size=50),
               'gamma': np.random.uniform(low=0.5, high=50, size=50),
               'kernel':['rbf','sigmoid']}

SVM = SVC(probability=True)

# Search for best parameters
svc = RandomizedSearchCV(SVM, params_SVM, cv=3, random_state=516, scoring='f1')
svc.fit(train_xx, train_y)

# Best model
print(svc.best_params_)
SVC=svc.best_estimator_

#%%
# Predction
SVM_tr = SVC.predict(train_xx)
SVM_ts = SVC.predict(test_xx)

conf_SVM_tr = pd.crosstab(train_y, SVM_tr,rownames=['real'],colnames=['pred'])
conf_SVM_tr.columns=['Good','Scrap'];conf_SVM_tr.index=['Good','Scrap']
print('\nConfusion Matrix Training:\n',conf_SVM_tr)
train_SVM = calPerf_class(train_y,SVM_tr)

conf_SVM_ts = pd.crosstab(test_y,SVM_ts,rownames=['real'],colnames=['pred'])
conf_SVM_ts.columns=['Good','Scrap'];conf_SVM_ts.index=['Good','Scrap']
print('\nConfusion Matrix Testing:\n',conf_SVM_ts)
test_SVM = calPerf_class(test_y,SVM_ts)

# SVM result
SVM_tab = pd.DataFrame()
SVM_tab['SVM_train'] = train_SVM
SVM_tab['SVM_test'] = test_SVM
SVM_tab.index = ["Accuracy","Recall","Precision","F1_Score"]
print('\nPerformance:')
print(SVM_tab)

#%%
# Bulid the model
def DNN(n_hidden,n_neurons,learning_rate,
                 activation,kernel_initializer,n_epochs,n_batch_size, n_dropout,select_optimizer=optimizers.Adam): #n_dropout
                     
    model = Sequential()
    model.add(Dense(n_neurons, input_dim=len(train_xx[0]), activation=activation, kernel_initializer=kernel_initializer))
    
    for layer in range(n_hidden):
        model.add(Dense(n_neurons,activation=activation,kernel_initializer=kernel_initializer))
        model.add(Dropout(n_dropout))
        
    model.add(Dense(1, activation='sigmoid'))
    
    optimizer = select_optimizer(lr=learning_rate) #['Accuracy']
    model.compile(loss='binary_crossentropy',metrics=['Recall'],optimizer=optimizer)
    model.fit(train_xx,train_y, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2) 
    return model
keras=KerasClassifier(DNN)

#%%Random search
# Parameters sets
params_DNN = {
        "n_dropout":[0.1,0.2,0.3],
        "n_hidden":[1,2,3],
        "n_neurons":[8,16],
        "learning_rate":[0.01,0.05,0.1],
        "activation":['sigmoid','softmax','relu'], #'tanh','softmax'
        "n_epochs":[200],
        "n_batch_size":[8,16],
        "kernel_initializer":['he_uniform'],
        "select_optimizer":[optimizers.Adam,optimizers.SGD,optimizers.RMSprop]
        }

RS_cv=RandomizedSearchCV(keras,params_DNN,n_iter=10,scoring="recall", cv=3,random_state=516)
RS_cv.fit(train_xx,train_y)
print(RS_cv.best_params_) 
DNN=RS_cv.best_estimator_
#{'select_optimizer': <class 'keras.optimizers.optimizer_v2.rmsprop.RMSprop'>, 'n_neurons': 16, 'n_hidden': 3, 'n_epochs': 250, 'n_dropout': 0.1, 'n_batch_size': 8, 'learning_rate': 0.05, 'kernel_initializer': 'he_uniform', 'activation': 'softmax'}

#%%
# Prediction
DNN_tr = (DNN.predict(train_xx)>0.5).flatten()
DNN_ts = (DNN.predict(test_xx)>0.5).flatten()
#cm_tr = confusion_matrix(train_y,DNN_tr, labels=[1,0]) ##1 first scrap will put in top-left (2 class)

# Training performance
conf_DNN_tr = pd.crosstab(train_y,DNN_tr,rownames=['real'],colnames=['pred'])
conf_DNN_tr.columns=['Good','Scrap'];conf_DNN_tr.index=['Good','Scrap']
print('\nConfusion Matrix Training:\n',conf_DNN_tr)
train_DNN = calPerf_class(train_y,DNN_tr)

# Testing performance
conf_DNN_ts = pd.crosstab(test_y,DNN_ts,rownames=['real'],colnames=['pred'])
conf_DNN_ts.columns=['Good','Scrap'];conf_DNN_ts.index=['Good','Scrap']
print('\nConfusion Matrix Testing:\n',conf_DNN_ts)
test_DNN = calPerf_class(test_y,DNN_ts)

# DNN Result
DNN_tab = pd.DataFrame()
DNN_tab['DNN_train'] = train_DNN
DNN_tab['DNN_test'] = test_DNN
DNN_tab.index = ["Accuracy","Recall","Precision","F1_Score"]
print('\nPerformance:')
print(DNN_tab)

#%% convert to CNN1d input dimension
train_X_scaled = train_xx.reshape((train_xx.shape[0], 1, int(train_xx.shape[1]/1))) ##convert the input shape of x to (samples, time step, features), samples:ttl rows
test_X_scaled = test_xx.reshape((test_xx.shape[0], 1, int(test_xx.shape[1]/1)))
print(train_X_scaled.shape, train_y.shape, test_X_scaled.shape, test_y.shape)

#%%
def CNN(filters1,kernel_size, n_neurons, activation, select_optimizer, learning_rate,
                        n_batch_size, n_epochs, kernel_initializer, n_hidden, n_dropout): #, n_dropout
    model = Sequential()
    model.add(Conv1D(filters = filters1, kernel_size = 1, activation = activation, input_shape=(train_X_scaled.shape[1], train_X_scaled.shape[2])))
    model.add(MaxPooling1D(pool_size=(1), padding='same'))
    model.add(Flatten())
    for layer in range(n_hidden):
        model.add(Dense(n_neurons,activation=activation,kernel_initializer=kernel_initializer))
        model.add(Dropout(n_dropout))
        
    model.add(Dense(1, activation='sigmoid'))
    
    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='binary_crossentropy',metrics=['accuracy'],optimizer=optimizer)
    model.fit(train_X_scaled,train_y, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2) #, class_weight=cls_weights
    return model
keras=KerasClassifier(build_fn=CNN)

#%% Bayes search
params_CNN = {
    "n_dropout": [0.1,0.2], 
    "n_hidden": Integer(low=1, high=2),
    "n_neurons": Integer(low=10, high=30),
    "learning_rate": Real(low=1e-5, high=9e-1, prior='log-uniform'),
    "activation": Categorical(categories=['relu','sigmoid','tanh']), 
    "kernel_initializer": Categorical(categories=['he_uniform']), 
    "n_epochs": [150],
    "n_batch_size": [8,16],
    "select_optimizer": Categorical(categories=[optimizers.Adam]), 
    "filters1": [1,4],
    "kernel_size":[1]
}
BS_cv=BayesSearchCV(keras,params_CNN,n_iter=15,cv=3,random_state=None,scoring='f1', n_jobs=-1) #,scoring='f1'(2 class), n_jobs=-1
BS_cv.fit(train_X_scaled,train_y)
BS_cv.best_params_
CNN=BS_cv.best_estimator_

#%%
# Prediction
CNN_tr = (CNN.predict(train_X_scaled)>0.5).flatten()
CNN_ts = (CNN.predict(test_X_scaled)>0.5).flatten()
#cm_tr = confusion_matrix(train_y,CNN_tr, labels=[1,0]) ##1 first scrap will put in top-left (2 class)

# Training performance
conf_CNN_tr = pd.crosstab(train_y,CNN_tr,rownames=['real'],colnames=['pred'])
conf_CNN_tr.columns=['Good','Scrap'];conf_CNN_tr.index=['Good','Scrap']
print('\nConfusion Matrix Training:\n',conf_CNN_tr)
train_CNN = calPerf_class(train_y,CNN_tr)

# Testing performance
conf_CNN_ts = pd.crosstab(test_y,CNN_ts,rownames=['real'],colnames=['pred'])
conf_CNN_ts.columns=['Good','Scrap'];conf_CNN_ts.index=['Good','Scrap']
print('\nConfusion Matrix Testing:\n',conf_CNN_ts)
test_CNN = calPerf_class(test_y,CNN_ts)

# CNN Result
CNN_tab = pd.DataFrame()
CNN_tab['CNN_train'] = train_CNN
CNN_tab['CNN_test'] = test_CNN
CNN_tab.index = ["Accuracy","Recall","Precision","F1_Score"]
print('\nPerformance:')
print(CNN_tab)
#%%
# Comparision
perf_tab_Cls = pd.DataFrame()
for y in ['train','test']:
    for t in ['SVM','DNN',"CNN"]:
        perf_tab_Cls[f"{y}_{t}"] = eval(f"{y}_{t}")
perf_tab_Cls.index = ["Accuracy","Recall","Precision","F1_Score"]
print(perf_tab_Cls)    
