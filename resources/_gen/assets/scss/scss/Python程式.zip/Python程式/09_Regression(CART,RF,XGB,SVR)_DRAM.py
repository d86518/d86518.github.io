#!/usr/bin/env python
# coding: utf-8

#%%
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVR
from sklearn.preprocessing import MinMaxScaler
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import GridSearchCV
from sklearn import metrics
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb
from sklearn import tree

#%%
#df= pd.read_csv('DRAM_data.csv')
df= pd.read_csv('electronics.csv')
df=df.iloc[0:64,]
df.info()

tt=pd.DataFrame(df.iloc[0:64,8:11])
tt['total']=tt.iloc[:,0:3].sum(axis=1)

tr_x=df.iloc[0:56,11:18] #train2009Q1-2022Q4
#tr_y=df.iloc[0:56,8:11]
tr_y=tt.iloc[0:56,3] #total sales

ts_x=df.iloc[56:64,11:18] #test2023Q1-2024Q4
#ts_y=df.iloc[56:64,8:11]
ts_y=tt.iloc[56:64,3] #total sales

# In[3]:
## CART
tree_param_grid = { 'min_samples_split': list((4,7,10)),'min_samples_leaf':list((3,6,9)),'max_depth':list((3,4,5,6))}
grid = GridSearchCV(DecisionTreeRegressor(random_state=3),param_grid=tree_param_grid, cv=3)
grid.fit(tr_x, tr_y)
grid.cv_results_, grid.best_params_, grid.best_score_

# In[4]:
grid.best_params_
DT=DecisionTreeRegressor(max_depth=grid.best_params_['max_depth'], 
                         min_samples_leaf=grid.best_params_['min_samples_leaf'],
                         min_samples_split=grid.best_params_['min_samples_split'],random_state=3)
DT.fit(tr_x, tr_y)

tree.plot_tree(DT)
print(tree.export_text(DT))

# In[5]:

### 變數重要性
feature_name = tr_x.columns
feature_imp = DT.feature_importances_

feat_imp_dict = dict(zip(feature_name, feature_imp))
feat_imp = pd.DataFrame.from_dict(feat_imp_dict, orient='index')
feat_imp.rename(columns = {0:'FeatureImportance'}, inplace = True)
feat_imp.sort_values(by=['FeatureImportance'], ascending=False)

# In[6]:

DT_train_pred = DT.predict(tr_x)
DT_tr_RMSE=np.sqrt(metrics.mean_squared_error(tr_y, DT_train_pred))
print('training RMSE:',DT_tr_RMSE)

DT_tr_MAE=metrics.mean_absolute_error(tr_y,DT_train_pred)
print('training MAE:',DT_tr_MAE)

DT_tr_MAPE=metrics.mean_absolute_percentage_error(tr_y,DT_train_pred)
print('training MAPE:',DT_tr_MAPE)

# In[7]:

DT_test_pred = DT.predict(ts_x)

DT_ts_RMSE=np.sqrt(metrics.mean_squared_error(ts_y, DT_test_pred))
print('testing RMSE:',DT_ts_RMSE)

DT_ts_MAE=metrics.mean_absolute_error(ts_y,DT_test_pred)
print('testing MAE:',DT_ts_MAE)

DT_ts_MAPE=metrics.mean_absolute_percentage_error(ts_y,DT_test_pred)
print('testing MAPE:',DT_ts_MAPE)

# In[8]:

## RF
tree_param_grid = { 'min_samples_split': list((4,7,10)),'n_estimators':list((80,100,150))
                   ,'min_samples_leaf':list((3,6,9)),'max_depth':list((3,4,5,6))}
grid = GridSearchCV(RandomForestRegressor(random_state=3),param_grid=tree_param_grid, cv=3)
grid.fit(tr_x, tr_y)
grid.cv_results_, grid.best_params_, grid.best_score_

# In[ ]:
grid.best_params_
RF = RandomForestRegressor(max_depth=grid.best_params_['max_depth'],min_samples_leaf=grid.best_params_['min_samples_leaf']
                           , min_samples_split=grid.best_params_['min_samples_split'], n_estimators=grid.best_params_['n_estimators'],random_state=3)
RF.fit(tr_x, tr_y)

RF_train_pred = RF.predict(tr_x)
RF_train_pred

# In[11]:
### 變數重要性
feature_name = tr_x.columns
feature_imp = RF.feature_importances_

feat_imp_dict = dict(zip(feature_name, feature_imp))
feat_imp = pd.DataFrame.from_dict(feat_imp_dict, orient='index')
feat_imp.rename(columns = {0:'FeatureImportance'}, inplace = True)
feat_imp.sort_values(by=['FeatureImportance'], ascending=False)

# In[12]:

RF_tr_RMSE=np.sqrt(metrics.mean_squared_error(tr_y, RF_train_pred))
print('training RMSE:',RF_tr_RMSE)

RF_tr_MAE=metrics.mean_absolute_error(tr_y,RF_train_pred)
print('training MAE:',RF_tr_MAE)

RF_tr_MAPE=metrics.mean_absolute_percentage_error(tr_y,RF_train_pred)
print('training MAPE:',RF_tr_MAPE)

# In[13]:
RF_test_pred = RF.predict(ts_x)

RF_ts_RMSE=np.sqrt(metrics.mean_squared_error(ts_y, RF_test_pred))
print('testing RMSE:',RF_ts_RMSE)

RF_ts_MAE=metrics.mean_absolute_error(ts_y,RF_test_pred)
print('testing MAE:',RF_ts_MAE)

RF_ts_MAPE=metrics.mean_absolute_percentage_error(ts_y,RF_test_pred)
print('testing MAPE:',RF_ts_MAPE)

# In[14]:

## XGB
###調最佳參數
tree_param_grid = { 'min_samples_split': list((4,7,10)),'n_estimators':list((80,100,120)),
                   'max_depth':list((3,4,5,6)),'learning_rate':[0.01,0.025,0.03]}
grid = GridSearchCV(xgb.XGBRegressor(random_state=3, verbosity = 0),
                    param_grid=tree_param_grid, cv=3)
grid.fit(tr_x, tr_y)
grid.cv_results_, grid.best_params_, grid.best_score_

# In[15]:
grid.best_params_

XGB = xgb.XGBRegressor(max_depth=grid.best_params_['max_depth'], n_estimators=grid.best_params_['n_estimators'], learning_rate=grid.best_params_['learning_rate'],
                     min_samples_split=grid.best_params_['min_samples_split'],random_state=3, verbosity = 0 )
XGB.fit(tr_x, tr_y)

# In[18]:
### 變數重要性
feature_name = tr_x.columns
feature_imp = XGB.feature_importances_

feat_imp_dict = dict(zip(feature_name, feature_imp))
feat_imp = pd.DataFrame.from_dict(feat_imp_dict, orient='index')
feat_imp.rename(columns = {0:'FeatureImportance'}, inplace = True)
feat_imp.sort_values(by=['FeatureImportance'], ascending=False)

# In[19]:
XGB_train_pred = XGB.predict(tr_x)
    
XGB_tr_RMSE=np.sqrt(metrics.mean_squared_error(tr_y, XGB_train_pred))
print('training RMSE:',XGB_tr_RMSE)

XGB_tr_MAE=metrics.mean_absolute_error(tr_y,XGB_train_pred)
print('training MAE:',XGB_tr_MAE)

XGB_tr_MAPE=metrics.mean_absolute_percentage_error(tr_y,XGB_train_pred)
print('training MAPE:',XGB_tr_MAPE)

# In[20]:

XGB_test_pred = XGB.predict(ts_x)

XGB_ts_RMSE=np.sqrt(metrics.mean_squared_error(ts_y, XGB_test_pred))
print('testing RMSE:',XGB_ts_RMSE)

XGB_ts_MAE=metrics.mean_absolute_error(ts_y,XGB_test_pred)
print('testing MAE:',XGB_ts_MAE)

XGB_ts_MAPE=metrics.mean_absolute_percentage_error(ts_y,XGB_test_pred)
print('training MAPE:',XGB_ts_MAPE)

#%%For SVR/DNN
#MinMAXscaler
X_scaler = MinMaxScaler()
X_tr=X_scaler.fit_transform(tr_x)
X_ts=X_scaler.fit_transform(ts_x)

#%%
parameters = {'kernel':['rbf','sigmoid','linear','poly'], 'C':[50,100,150], 
              'gamma':[5**-3, 5**-2, 5**-1,1,5,25,125],
              'epsilon':[0.05,0.1,0.15],'degree':[1,2]}
svr= SVR()
grid = GridSearchCV(svr, param_grid=parameters,cv=3)
grid.fit(X_tr,tr_y)
grid.cv_results_, grid.best_params_, grid.best_score_

#%%
print(grid.best_params_)
svr = SVR(kernel=grid.best_params_['kernel'],C=grid.best_params_['C'],epsilon=grid.best_params_['epsilon']
          ,gamma=grid.best_params_['gamma'],degree=grid.best_params_['degree'])
svr.fit(X_tr,tr_y)
SVR_train_pred = svr.predict(X_tr)

#%%
#####train
SVR_tr_RMSE = np.sqrt(metrics.mean_squared_error(tr_y,SVR_train_pred))
print('\nRMSE for SVR of dataset = ', SVR_tr_RMSE)
#MAE
SVR_tr_MAE = metrics.mean_absolute_error(tr_y,SVR_train_pred)
print('\nMAE for SVR of dataset = ', SVR_tr_MAE)
#MAPE
SVR_tr_MAPE = metrics.mean_absolute_percentage_error(tr_y,SVR_train_pred)
print('\nMAPE for SVR of dataset = ', SVR_tr_MAPE)

#%%
SVR_test_pred = svr.predict(X_ts)

#####test
SVR_ts_RMSE = np.sqrt(metrics.mean_squared_error(ts_y,SVR_test_pred))
print('\nRMSE for SVR of dataset = ', SVR_ts_RMSE)
#MAE
SVR_ts_MAE = metrics.mean_absolute_error(ts_y,SVR_test_pred)
print('\nMAE for SVR of dataset = ', SVR_ts_MAE)
#MAPE
SVR_ts_MAPE = metrics.mean_absolute_percentage_error(ts_y,SVR_test_pred)
print('\nMAPE for SVR of dataset = ', SVR_ts_MAPE)

#%%
##Comparison
#training
perf_tr = pd.DataFrame()
perf_tr["DT"] = [DT_tr_RMSE,DT_tr_MAE,DT_tr_MAPE]
perf_tr["RF"] = [RF_tr_RMSE,RF_tr_MAE,RF_tr_MAPE]
perf_tr["XGB"] = [XGB_tr_RMSE,XGB_tr_MAE,XGB_tr_MAPE]
perf_tr["SVR"] = [SVR_tr_RMSE,SVR_tr_MAE,SVR_tr_MAPE]
perf_tr.index = ["RMSE","MAE","MAPE"]
print("\n Performance of training\n")
print(perf_tr)
print("\n")

#testing
perf_ts = pd.DataFrame()
perf_ts["DT"] = [DT_ts_RMSE,DT_ts_MAE,DT_ts_MAPE]
perf_ts["RF"] = [RF_ts_RMSE,RF_ts_MAE,RF_ts_MAPE]
perf_ts["XGB"] = [XGB_ts_RMSE,XGB_ts_MAE,XGB_ts_MAPE]
perf_ts["SVR"] = [SVR_ts_RMSE,SVR_ts_MAE,SVR_ts_MAPE]
perf_ts.index = ["RMSE","MAE","MAPE"]
print("\n Performance of testing\n")
print(perf_ts)

# In[27]:
#plot
real=pd.concat([pd.DataFrame(tr_y),pd.DataFrame(ts_y)],axis=0)
real.index= pd.date_range('2009',periods = 64,freq = '3m')
DT_pred=pd.concat([pd.DataFrame(DT_train_pred),pd.DataFrame(DT_test_pred)],axis=0)
DT_pred=DT_pred.reset_index(drop=True)
DT_pred.index= pd.date_range('2009',periods = 64,freq = '3m')
RF_pred=pd.concat([pd.DataFrame(RF_train_pred),pd.DataFrame(RF_test_pred)],axis=0)
RF_pred=RF_pred.reset_index(drop=True)
RF_pred.index= pd.date_range('2009',periods = 64,freq = '3m')
XGB_pred=pd.concat([pd.DataFrame(XGB_train_pred),pd.DataFrame(XGB_test_pred)],axis=0)
XGB_pred=XGB_pred.reset_index(drop=True)
XGB_pred.index= pd.date_range('2009',periods = 64,freq = '3m')
SVR_pred=pd.concat([pd.DataFrame(SVR_train_pred),pd.DataFrame(SVR_test_pred)],axis=0)
SVR_pred=SVR_pred.reset_index(drop=True)
SVR_pred.index= pd.date_range('2009',periods = 64,freq = '3m')

plt.figure(figsize=(20,10))
plt.plot( real, color='black', label="Real",linewidth=1.5)
plt.plot( DT_pred, color='green', label="DT_pred",linewidth=1.5)
plt.plot( RF_pred, color='orange', label="RF_pred",linewidth=1.5)
plt.plot( XGB_pred, color='red', label="XGB_pred",linewidth=1.5)
plt.plot( SVR_pred, color='blue', label="SVR_pred",linewidth=1.5)

plt.legend(loc = 'lower left')
plt.legend(fontsize=15)
plt.xlabel('Quarter', size=15)
plt.ylabel('DRAM Revenue', size=15)

# In[ ]:
## 三種模型比較


