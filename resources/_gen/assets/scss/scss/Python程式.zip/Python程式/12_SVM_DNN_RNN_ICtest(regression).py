# -*- coding: utf-8 -*-
"""
Created on Wed Nov 10 09:01:25 2021

@author: MB516_SL
"""
#%%
# Import library
import random
import math
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import xgboost as xgb
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV, train_test_split
from sklearn import metrics
from sklearn.metrics import mean_absolute_error,mean_squared_error,mean_absolute_percentage_error
from sklearn import preprocessing
from skopt import BayesSearchCV
from sklearn.svm import SVR
from tensorflow.keras import optimizers
from tensorflow.keras.wrappers.scikit_learn import KerasRegressor
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.layers import Dense, Activation, Dropout,BatchNormalization, LSTM ,GRU ,SimpleRNN

#%%

def calPerformance(y_true,y_pred):
    temp_list=[]  
    RMSE_score=math.sqrt(mean_squared_error(y_true,y_pred))  
    temp_list.append(RMSE_score)
    MAE_score=mean_absolute_error(y_true,y_pred)  
    temp_list.append(MAE_score)
    MAPE_score=mean_absolute_percentage_error(y_true,y_pred)  
    temp_list.append(MAPE_score) 
    return temp_list

def prediction_plot(testY, test_predict):
    len_prediction=[x for x in range(len(testY))]
    plt.figure(figsize=(50,8))
    plt.plot(len_prediction, testY, marker='.', label="actual")
    plt.plot(len_prediction, test_predict, 'r', label="predicted")
    plt.tight_layout()
    sns.despine(top=True)
    plt.subplots_adjust(left=0.07)
    plt.ylabel('y', size=15)
    plt.xlabel('X', size=15)
    plt.legend(fontsize=15)
    plt.show()

random.seed(516)
np.random.seed(1)

#%%
## Regression ##
# Data Pre-processing
df_ori = pd.read_csv('IC_test.csv')
df_y = df_ori['TipLength']
df = df_ori.drop(['CoreState','TipLength'], axis=1)
df.dtypes #features

dum = pd.get_dummies(df.loc[:,df.dtypes=='object'],drop_first=True)
df_x = pd.merge(df.loc[:,df.dtypes!='object'],dum,left_index=True,right_index=True)

# Train/test split
train_X, test_X, train_y, test_y = train_test_split(df_x, df_y, test_size=0.3, random_state=516)
print(train_X.shape, train_y.shape, test_X.shape, test_y.shape)

#%%
#XGB - Finding KPI
## Randominzed Search in XGB
#parameter grid
param_xgb = {'min_child_weight': list((10,20,30)),'n_estimators':list((100,120,150)),
             'max_depth':list((4,6,8)),'learning_rate':[0.01,0.025,0.05],
             'colsample_bytree':[0.5,0.7,0.9]}
xgb = GridSearchCV(xgb.XGBRegressor(random_state=3),
                    param_grid=param_xgb, cv=3)
xgb.fit(train_X, train_y)

#Get Best parameter
print('\nBest parameters :',xgb.best_params_)

#%%
XGB = xgb.best_estimator_
XGB.fit(train_X, train_y)
#Get importance of feature with sorting
ic_imp = pd.DataFrame({'Feature':df_x.columns,
                       'Importance':XGB.feature_importances_})
print('\nFeature importance:\n',ic_imp.sort_values(by=['Importance'],ascending=False))

#%%
# Define KPI
KPI = ['vender_FO','vender_YO','TestOD','CleanTouchdown','P_Size','CleanSheetHeight','Leads','Cleanfrequence','Testing_G2']
train_X = train_X[KPI]
test_X = test_X[KPI]

# Normalization
X_scaler = preprocessing.MinMaxScaler()
train_xx = X_scaler.fit_transform(train_X)
test_xx = X_scaler.transform(test_X)

#%%
# SVM
np.random.seed(0)
params_SVM = {'C': np.random.uniform(low=1, high=100, size=20).flatten(),
               'gamma': np.random.uniform(low=0.5, high=30, size=20).flatten(),
               'epsilon':np.random.uniform(low=0.05, high=0.15, size=20).flatten(),
               'kernel':['rbf']}

SVM = SVR()

# Search for best parameters
svr = RandomizedSearchCV(SVM, params_SVM, cv=3, random_state=516)
svr.fit(train_xx, train_y)

# Best model
print(svr.best_params_)
SVR = svr.best_estimator_
#{'kernel': 'rbf', 'gamma': 19.377670129161952, 'epsilon': 0.11976311959272648, 'C': 78.03751834403519}

#%%
# Best model
SVR.fit(train_xx, train_y)
SVR_tr = SVR.predict(train_xx)
SVR_ts = SVR.predict(test_xx)
prediction_plot(test_y, SVR_ts)

train_SVR = calPerformance(train_y, SVR_tr)
test_SVR = calPerformance(test_y, SVR_ts)

SVR_tab = pd.DataFrame()
SVR_tab['SVR_train'] = train_SVR
SVR_tab['SVR_test'] = test_SVR
SVR_tab.index = ["RMSE","MAE","MAPE"]
print(SVR_tab)

#%%
# DNN
# Bulid the model
es = EarlyStopping(monitor='val_loss', mode='min', patience = 20, verbose=1)
def build_model(first_hidden_neuron, n_dropout, n_hidden, n_neurons,kernel_initializer,
                learning_rate, activation, n_epochs, n_batch_size, select_optimizer):
    model = Sequential()
    model.add(Dense(first_hidden_neuron, input_dim=len(train_xx[0]), activation=activation, kernel_initializer=kernel_initializer))
    for layer in range(n_hidden):
        model.add(Dense(n_neurons, activation=activation, kernel_initializer=kernel_initializer))
        model.add(Dropout(n_dropout))
        
    model.add(Dense(1, activation='linear'))
    
    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='mean_squared_error', optimizer=optimizer)
    
    model.fit(train_xx,train_y, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2, callbacks=[es])
    return model

keras = KerasRegressor(build_model)  

#%% 
# Parameters sets
params_DNN = {
        "n_dropout":[0.1,0.2,0.3],
        "n_hidden":[1,2,3],
        'first_hidden_neuron':[6,12],
        "n_neurons":[8,16],
        "learning_rate":[0.01,0.02],
        "activation":['relu','softplus','elu'],
        "n_epochs":[200],
        "n_batch_size":[8,16],
        "kernel_initializer": ['glorot_uniform', 'lecun_normal'], #'uniform'
        "select_optimizer":[optimizers.Adam,optimizers.SGD,optimizers.RMSprop]
        }

#%%
# Randomized Search
RS_cv=RandomizedSearchCV(keras,params_DNN,n_iter=10,cv=3,random_state=516)
RS_cv.fit(train_xx,train_y)
print(RS_cv.best_params_)
DNN=RS_cv.best_estimator_

#%%
# Prediction
DNN_tr = DNN.predict(train_xx)
DNN_ts = DNN.predict(test_xx)
prediction_plot(test_y, DNN_ts)
train_DNN = calPerformance(train_y, DNN_tr)
test_DNN = calPerformance(test_y, DNN_ts)

# DNN Result
DNN_tab = pd.DataFrame()
DNN_tab['DNN_train'] = train_DNN
DNN_tab['DNN_test'] = test_DNN
DNN_tab.index = ["RMSE","MAE","MAPE"]
print(DNN_tab)

#%%RNN標準化           
train_y, test_y = train_y.values.reshape(-1, 1), test_y.values.reshape(-1, 1)
train_X_scaled = train_xx.reshape((train_xx.shape[0], 1, int(train_xx.shape[1])))
test_X_scaled = test_xx.reshape((test_xx.shape[0], 1, int(test_xx.shape[1])))
print(train_X_scaled.shape, train_y.shape, test_X_scaled.shape, test_y.shape)

#%%
cell=eval("SimpleRNN") #"SimpleRNN","GRU","LSTM"
es = EarlyStopping(monitor='val_loss', mode='min', patience = 20, verbose=1)

def build_model(n_dropout, n_hidden, n_neurons1, n_neurons2, n_neurons3,  last_n_neurons,
                learning_rate, activation, n_epochs, n_batch_size, select_optimizer):

    model = Sequential()
    for i in range(1, n_hidden):
        neurons = locals()[f"n_neurons{i}"]
        model.add(cell(units=neurons, input_shape=(train_X_scaled.shape[1],train_X_scaled.shape[2]), activation=activation, return_sequences=True))

    model.add(cell(units=last_n_neurons, input_shape=(train_X_scaled.shape[1], train_X_scaled.shape[2]), activation=activation, return_sequences=False))
    model.add(Dropout(n_dropout))
    model.add(Dense(1, activation='linear'))

    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='mean_absolute_percentage_error', optimizer=optimizer)

    model.fit(train_X_scaled, train_y, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2, callbacks=[es])
    return model

keras=KerasRegressor(build_model)

#%%RNN隨機搜索參數設定
params_RNN = {
        "n_dropout":[0.05, 0.1],
        "n_hidden":[2, 3, 4],
        "n_neurons1": [50, 100],
        "n_neurons2": [150, 200],
        "n_neurons3": [250, 300],
        "last_n_neurons": [30, 55, 80],
        "learning_rate":[0.001, 0.002, 0.004],
        "activation":['relu','softplus','elu'],
        "n_epochs":[250],
        "n_batch_size":[50, 100],
        "select_optimizer":[optimizers.Adam, optimizers.RMSprop, optimizers.Adagrad]
        #optimizers.Adam,optimizers.RMSprop,optimizers.SGD,optimizers.experimental.Adadelta
        }

BS_cv=BayesSearchCV(keras,params_RNN,n_iter=10,cv=3,random_state=516) 
BS_cv.fit(train_X_scaled,train_y)
print(BS_cv.best_params_)
RNN=BS_cv.best_estimator_
#{'select_optimizer': <class 'keras.optimizers.optimizer_v2.rmsprop.RMSprop'>, 'n_neurons3': 300, 'n_neurons2': 200, 'n_neurons1': 100, 'n_hidden': 2, 'n_epochs': 250, 'n_dropout': 0.1, 'n_batch_size': 50, 'learning_rate': 0.001, 'last_n_neurons': 55, 'activation': 'relu'}

#%%
# Prediction
RNN_tr = RNN.predict(train_X_scaled)
RNN_ts = RNN.predict(test_X_scaled)

prediction_plot(test_y, RNN_ts)
train_RNN = calPerformance(train_y, RNN_tr)
test_RNN = calPerformance(test_y, RNN_ts)

# RNN Result
RNN_tab = pd.DataFrame()
RNN_tab['RNN_train'] = train_RNN
RNN_tab['RNN_test'] = test_RNN
RNN_tab.index = ["RMSE","MAE","MAPE"]
print(RNN_tab)

#%%
# Comparison
perf_tab_Reg = pd.DataFrame()
for y in ['train','test']:
    for t in ['SVR','DNN','RNN']:
        perf_tab_Reg[f"{y}_{t}"] = eval(f"{y}_{t}")
perf_tab_Reg.index = ["RMSE","MAE","MAPE"]
print(perf_tab_Reg)

