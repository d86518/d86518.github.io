# -*- coding: utf-8 -*-
"""
Created on Mon Dec 25 14:45:33 2023

@author: scott
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
#import yellowbrick as yb
import scipy.spatial
from sklearn.cluster import KMeans
from sklearn.metrics import davies_bouldin_score
from sklearn.metrics import silhouette_score
#from yellowbrick.cluster import KElbowVisualizer
from sklearn.manifold import MDS
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from matplotlib.colors import ListedColormap, BoundaryNorm
import matplotlib.patches as mpatches
from sklearn.metrics import davies_bouldin_score
import scipy.spatial
import skfuzzy as fuzz #pip install scikit-fuzzy

#%%
# Data preparation
df = pd.read_csv('gender_size.csv')
y = df['Gender']
X = df.drop(['Gender'],axis=1)

# Plot the data
fig = plt.figure()
ax0 = fig.add_axes((0.1,0.5,1,1));ax0.set_xlabel('Height');ax0.set_ylabel('Weight')
d1 = df[df['Gender']=='male']
ax0.scatter(d1['Height'],d1['Weight'],c ='Navy',marker = 'o')

d2 = df[df['Gender']=='female']
ax0.scatter(d2['Height'],d2['Weight'],c ='Crimson',marker = 'x')
ax0.legend(['Male','Female'])
ax0.set_title("Gender Scatterplot")

#%%
def optimal_Kmean(df, kmax):
    array = df.to_numpy()
    perf = pd.DataFrame()
    for k in np.arange(2, kmax):
        kmeans = KMeans(n_clusters=k,random_state=1).fit(df)
        pred_clusters = kmeans.predict(df)
        centroids = kmeans.cluster_centers_
        
        curr_db = davies_bouldin_score(array, pred_clusters)
        curr_silhouette = silhouette_score(array, pred_clusters)
        
        curr_sst = 0
        for i in range(len(array)):
            total_mean = df.mean(0)
            curr_sst += sum(np.power((array[i,] - total_mean),2))
        
        curr_ssw = 0
        for i in range(len(array)):
           curr_mean = centroids[pred_clusters[i],:]
           curr_ssw += sum(np.power((array[i,] - curr_mean),2))
        
        curr_ssb = curr_sst-curr_ssw   
        
        perf.loc[k,'DBindex'] = curr_db
        perf.loc[k,'Silhouette'] = curr_silhouette
        perf.loc[k,'SSB'] = curr_ssb
        perf.loc[k,'SSW'] = curr_ssw
        perf.loc[k,'SSB/SSW'] = curr_ssb/curr_ssw
        
    return perf

result = optimal_Kmean(X,11)

#%%
print(result)
print("DB",np.argmin(result["DBindex"])+2)
print("Silhouette",np.argmax(result["Silhouette"])+2)
print("SSB",np.argmax(result["SSB"])+2)
print("SSW",np.argmin(result["SSW"])+2)
print("SSB/SSW",np.argmax(result["SSB/SSW"])+2)

#%%
import matplotlib.pyplot as plt
result = result.astype(float)

fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(8, 12), sharex=True)

ax1.plot(result.index, result['DBindex'], marker='o', label='Davies-Bouldin Index', color='blue')
ax2.plot(result.index, result['Silhouette'], marker='o', label='silhouette score', color='orange')
ax3.plot(result.index, result['SSW'], marker='o', label='SSW (within-cluster sums of squares) ', color='green')

ax3.set_xlabel('Number of Clusters (K)')
ax1.set_ylabel('Davies-Bouldin Index')
ax2.set_ylabel('Silhoutte score')
ax3.set_ylabel('SSW (within-cluster sums of squares)')
fig.suptitle('Clustering Performance Indices for Different Numbers of Clusters', y=0.92)
ax1.legend()
ax2.legend()
ax3.legend()
plt.show()

#%%
# Buliding model using best K and plot
best_k = 3
kmeans = KMeans(n_clusters= best_k, random_state=1).fit(X)
labels = kmeans.predict(X)
KM_result = pd.concat([df, pd.DataFrame(labels,columns=['Cluster'])], axis=1)
print(KM_result)

tab_gender=pd.crosstab(KM_result["Gender"],KM_result["Cluster"],rownames=['gender'],colnames=['group'])
tab_gender
tab_gender.apply(sum,axis=0)

#%%
# Cluster Means
KM_means = pd.concat([pd.DataFrame(kmeans.cluster_centers_), pd.DataFrame(tab_gender.apply(sum,axis=0).T)], axis=1)
KM_means.columns = ['Height','Weight','Waist','Number']
print('\nCluster Means:')
print(KM_means)

#%%
# plot
unique_labels = list(set(labels))
colors = ['b','g','r','0.25','0.5','0.75']

fig = plt.figure()
ax1 = fig.add_axes((0.1,0.5,0.8,0.8));ax1.set_xlabel('Height');ax1.set_ylabel('Weight')

for i in unique_labels:
    filtered_label = df[labels == i]
    m_label = filtered_label[filtered_label['Gender']=='male']
    ax1.scatter(m_label.iloc[:,0],m_label.iloc[:,1],
                color = colors[i],marker = 'o')
   
    f_label = filtered_label[filtered_label['Gender']=='female']
    ax1.scatter(f_label.iloc[:,0],f_label.iloc[:,1],
                color = colors[i],marker = 'x')
    ax1.legend(['Male','Female'])
    ax1.scatter(kmeans.cluster_centers_[i][0], kmeans.cluster_centers_[i][1], marker="+", c='black',s=300)
    ax1.set_title(f"KMeans (k={best_k})")

#%% KMedoids (Reuse the best_k determined by KMeans)
from sklearn_extra.cluster import KMedoids

kmedoids = KMedoids(n_clusters=best_k, random_state=1, metric='euclidean')
kmedoids.fit(X)
labels_km = kmedoids.labels_

KMedoids_result = pd.concat([df, pd.DataFrame(labels_km + 1, columns=['Cluster'])], axis=1)
print(KMedoids_result)
print(pd.crosstab(KMedoids_result["Gender"], KMedoids_result["Cluster"], rownames=['Gender'], colnames=['Group']))

# plot
unique_labels_km = list(set(labels_km))
colors = ['b', 'g', 'r', '0.25', '0.5', '0.75']

fig = plt.figure()
ax2 = fig.add_axes((0.1,0.5,0.8,0.8)); ax2.set_xlabel('Height'); ax2.set_ylabel('Weight')

for i in unique_labels_km:
    filtered_label = df[labels_km == i]
    m_label = filtered_label[filtered_label['Gender']=='male']
    ax2.scatter(m_label.iloc[:, 0], m_label.iloc[:, 1],
                color=colors[i], marker='o')
   
    f_label = filtered_label[filtered_label['Gender']=='female']
    ax2.scatter(f_label.iloc[:, 0], f_label.iloc[:, 1],
                color=colors[i], marker='x')

    ax2.scatter(kmedoids.cluster_centers_[i][0], kmedoids.cluster_centers_[i][1], marker="+", c='black', s=300)

ax2.legend(['Male', 'Female'])
ax2.set_title(f"KMedoids (k={best_k})")

# Cluster Medoids
cluster_medoids = pd.DataFrame(kmedoids.cluster_centers_)
cluster_medoids.columns = ['Height','Weight','Waist']
cluster_medoids.index = np.arange(1, best_k+1)

cluster_counts_km = pd.Series(labels_km).value_counts().sort_index()
cluster_counts_km.index = cluster_counts_km.index + 1  
cluster_medoids['Samples'] = cluster_counts_km.values

print('\nCluster Medoids:')
print(cluster_medoids)




#%%
# Data preparation
df = pd.read_csv('iris.csv')
y = df['Species']
X = df.drop(['Species'],axis=1)

#%%
# Plot the data
#sepal
fig = plt.figure()
ax0 = fig.add_axes((0.1,0.5,1,1));ax0.set_xlabel('Sepal.Length');ax0.set_ylabel('Sepal.Width')
d1 = df[df['Species']=='setosa']
ax0.scatter(d1['Sepal.Length'],d1['Sepal.Width'],c ='navy',marker = 'o')

d2 = df[df['Species']=='versicolor']
ax0.scatter(d2['Sepal.Length'],d2['Sepal.Width'],c ='crimson',marker = 'x')

d3 = df[df['Species']=='virginica']
ax0.scatter(d3['Sepal.Length'],d2['Sepal.Width'],c ='green',marker = '^')
ax0.legend(['setosa','versicolor','virginica'])
ax0.set_title("Species Scatterplot")

#%%
# Plot the data
#petal
fig = plt.figure()
ax0 = fig.add_axes((0.1,0.5,1,1));ax0.set_xlabel('Petal.Length');ax0.set_ylabel('Petal.Width')
d1 = df[df['Species']=='setosa']
ax0.scatter(d1['Petal.Length'],d1['Petal.Width'],c ='navy',marker = 'o')

d2 = df[df['Species']=='versicolor']
ax0.scatter(d2['Petal.Length'],d2['Petal.Width'],c ='crimson',marker = 'x')

d3 = df[df['Species']=='virginica']
ax0.scatter(d3['Petal.Length'],d2['Petal.Width'],c ='green',marker = '^')
ax0.legend(['setosa','versicolor','virginica'])
ax0.set_title("Species Scatterplot")

#%%
def FS(x, u, v): 
    u2 = u**2
    v_mean = v.mean(axis=0)
    d2 = scipy.spatial.distance.cdist(x, v)**2 
    distance_v_mean_squared = np.linalg.norm(v - v_mean, axis=1, keepdims=True)**2
    index_result = np.sum(u2.T*d2) - np.sum(u2*distance_v_mean_squared)
    return index_result
      
def XB(x, u, v):
    n = x.shape[0]
    u2 = u**2
    d2 = scipy.spatial.distance.cdist(x, v)**2 
    v2 = scipy.spatial.distance.cdist(v, v)**2 
    v2[v2 == 0.0] = np.inf
    index_result = np.sum(u2.T*d2)/(n*np.min(v2))
    return index_result

def optimal_Cmean(df, kmax):
    array = df.values
    perf = pd.DataFrame()
    
    for k in range(2, kmax+1): ##min cluster = 2
        centroids, possibility, u0, d, jm, p, fpc = fuzz.cluster.cmeans(array.T, k, 2, error=0.005, maxiter=200, init=None)
        
        pred_clusters = np.argmax(possibility.T, axis=1)
        
        ## Calculate DB index ##
        curr_db = davies_bouldin_score(array, pred_clusters)
        ## Calculate FS index ##
        curr_fs = FS(array, possibility, centroids)
        ## Calculate XB index ##
        curr_xb = XB(array, possibility, centroids)
        perf.loc[k, ['DBindex','FSindex','XBindex']] = curr_db,curr_fs,curr_xb 

    return perf

result = optimal_Cmean(X,10)
print(result)

# print('the optimal k which has the lowest DBindex, FSindex, XBindex score')
print("DB",np.argmin(result["DBindex"])+2)
print("FS",np.argmin(result["FSindex"])+2)
print("XB",np.argmin(result["XBindex"])+2)

#%%
import matplotlib.pyplot as plt
result = result.astype(float)

fig, (ax1, ax2, ax3) = plt.subplots(3, 1, figsize=(8, 12), sharex=True)

ax1.plot(result.index, result['DBindex'], marker='o', label='Davies-Bouldin Index', color='blue')
ax2.plot(result.index, result['FSindex'], marker='+', label='FS Index', color='orange')
ax3.plot(result.index, result['XBindex'], marker='x', label='XB Index', color='green')

ax3.set_xlabel('Number of Clusters (K)')
ax1.set_ylabel('DB Index')
ax2.set_ylabel('FS Index')
ax3.set_ylabel('XB Index')

fig.suptitle('Clustering Performance Indices for Different Numbers of Clusters', y=0.92)
ax1.legend()
ax2.legend()
ax3.legend()
plt.show()

#%%
## Build model using best K ##
best_k = 2

centroids, possibility, u0, d, jm, p, fpc = fuzz.cluster.cmeans(X.T, best_k, 2, error=0.005, maxiter=200, init=None)
possibility_result = pd.DataFrame(possibility.T, columns = range(0, best_k))
print(possibility_result)

pred_clusters = np.argmax(possibility.T, axis=1)
FCM_result = pd.concat([df, pd.DataFrame(pred_clusters,columns=['Cluster'])], axis = 1)
print(FCM_result)
tab_iris=pd.crosstab(FCM_result["Species"], FCM_result["Cluster"],rownames=['species'],colnames=['group'])
tab_iris
tab_iris.apply(sum,axis=0)

# Cluster Means
FCM_means = pd.concat([pd.DataFrame(centroids), pd.DataFrame(tab_iris.apply(sum,axis=0).T)], axis=1)
FCM_means.columns = ['Sepal.Length','Sepal.Width','Petal.Length','Petal.Width','Number']
print('\nCluster Means:')
print(FCM_means)

#%%
## plot ##
for i in range(len(df)):
    if df.loc[i,'Species']=='setosa': df.loc[i,'Species']=0
    elif df.loc[i,'Species']=='versicolor':df.loc[i,'Species']=1
    elif df.loc[i,'Species']=='virginica':df.loc[i,'Species']=2

unique_labels = list(set(pred_clusters))
colors = ['r','g','b','c','m','y','k','0.25','0.5','0.75']

fig = plt.figure()
ax1 = fig.add_axes((0.1,0.5,0.8,0.8));ax1.set_xlabel('Sepal.Length');ax1.set_ylabel('Sepal.Width')

for i in unique_labels:
    filtered_label = df[pred_clusters == i]
    m_label = filtered_label[filtered_label['Species']==0]
    ax1.scatter(m_label.iloc[:,0],
                m_label.iloc[:,1],
                color = colors[i],
                marker = 'o')
   
    f_label = filtered_label[filtered_label['Species']==1]
    ax1.scatter(f_label.iloc[:,0],
                f_label.iloc[:,1],
                color = colors[i],
                marker = 'x')
    
    f_label = filtered_label[filtered_label['Species']==2]
    ax1.scatter(f_label.iloc[:,0],
                f_label.iloc[:,1],
                color = colors[i],
                marker = '+')
    ax1.legend(['setosa','versicolor','virginica'])
    ax1.scatter(centroids[i][0], centroids[i][1], marker="*", c='black',s=300)
    ax1.set_title(f"CMeans (k={best_k})")

#%%
## plot ##
for i in range(len(df)):
    if df.loc[i,'Species']=='setosa': df.loc[i,'Species']=0
    elif df.loc[i,'Species']=='versicolor':df.loc[i,'Species']=1
    elif df.loc[i,'Species']=='virginica':df.loc[i,'Species']=2

unique_labels = list(set(pred_clusters))
colors = ['r','g','b','c','m','y','k','0.25','0.5','0.75']

fig = plt.figure()
ax1 = fig.add_axes((0.1,0.5,0.8,0.8));ax1.set_xlabel('Petal.Length');ax1.set_ylabel('Petal.Width')

for i in unique_labels:
    filtered_label = df[pred_clusters == i]
    m_label = filtered_label[filtered_label['Species']==0]
    ax1.scatter(m_label.iloc[:,2],
                m_label.iloc[:,3],
                color = colors[i],
                marker = 'o')
   
    f_label = filtered_label[filtered_label['Species']==1]
    ax1.scatter(f_label.iloc[:,2],
                f_label.iloc[:,3],
                color = colors[i],
                marker = 'x')
    
    f_label = filtered_label[filtered_label['Species']==2]
    ax1.scatter(f_label.iloc[:,2],
                f_label.iloc[:,3],
                color = colors[i],
                marker = '^')
    ax1.legend(['setosa','versicolor','virginica'])
    ax1.scatter(centroids[i][2], centroids[i][3], marker="+", c='black',s=300)
    ax1.set_title(f"CMeans (k={best_k})")
    
#%%
