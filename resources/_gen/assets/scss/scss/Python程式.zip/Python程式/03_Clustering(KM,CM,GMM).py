# -*- coding: utf-8 -*-
"""
Created on Mon Sep  6 11:03:14 2021

@author: a0978
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import davies_bouldin_score

#%%
# Data preparation
data = pd.read_csv('gender_size.csv')

y = data['Gender']
X = data.drop(['Gender'],axis=1)

# Plot the data
fig = plt.figure()
ax0 = fig.add_axes((0.1,0.5,1,1));ax0.set_xlabel('Height');ax0.set_ylabel('Weight')
d1 = data[data['Gender']=='male']
ax0.scatter(d1['Height'],
            d1['Weight'],
            c ='Navy',
            marker = 'o')

d2 = data[data['Gender']=='female']
ax0.scatter(d2['Height'],
            d2['Weight'],
            c ='Crimson',
            marker = 'x')
ax0.legend(['Male','Female'])
ax0.set_title("Gender Scatterplot")

# Normalization
# from sklearn.preprocessing import MinMaxScaler
# # build the scaler model
# scaler = MinMaxScaler()
# scaler.fit(X)
# # transform
# X = scaler.transform(X)


#%%
## K-Means ##
from sklearn.cluster import KMeans
# K means// K is the number of clusters

# Choosing optimal K
def optimal_Kmean(df, kmax):
    array = df.to_numpy()
    perf = pd.DataFrame()
    
    for k in range(1, kmax+1):
        kmeans = KMeans(n_clusters= k,random_state=1).fit(df)
        pred_clusters = kmeans.predict(df)
        curr_ssw = kmeans.inertia_
        if k == 1: curr_db = 1
        else: curr_db = davies_bouldin_score(df, pred_clusters)

        curr_sst = 0
        for i in range(len(array)):
            total_mean = df.mean(0)
            curr_sst += sum(np.power((array[i,] - total_mean),2))
            #curr_sst += (array[i, 0] - total_mean[0]) ** 2 + (array[i, 1] - total_mean[1]) ** 2 + (array[i, 2] - total_mean[2]) ** 2
        # curr_ssb = 0
        # for i in range(0,k):
        #     curr_center = df[pred_clusters==i].mean()
        #     curr_ssb += sum(sum(pred_clusters==i)*(curr_center - df.mean(0))**2)
        curr_ssb = curr_sst-curr_ssw
        perf.loc[k,'DBindex'] = curr_db
        perf.loc[k,'SSW'] = curr_ssw
        perf.loc[k,'SSB'] = curr_ssb
        perf.loc[k,'SSB/SSW'] = curr_ssb/curr_ssw
    return perf

result = optimal_Kmean(X,10)
print(result)

plt.plot(result['SSW'])
plt.xlabel('number of k')
plt.title('Within sum of squared errors by cluster')
plt.show()

#result['DBindex'].plot()
print('the optimal k which has the lowerest DBindex score')
print(np.argmin(result["DBindex"])+1)

#%%
# Buliding model using best K and plot
best_k = 3
kmeans = KMeans(n_clusters = best_k, random_state=1).fit(X)

labels = kmeans.predict(X)
KM_result = pd.concat([X, pd.DataFrame(labels+1,columns=['Cluster'])], axis=1)
print(KM_result)
# plot
for i in range(len(data)):
    if data.loc[i,'Gender']=='male': data.loc[i,'Gender']=0
    elif data.loc[i,'Gender']=='female':data.loc[i,'Gender']=1
    
unique_labels = list(set(labels))
colors = ['b','g','m','c','r','y','k','0.25','0.5','0.75']

fig = plt.figure()
ax1 = fig.add_axes((0.1,0.5,0.8,0.8));ax1.set_xlabel('Height');ax1.set_ylabel('Weight')

for i in unique_labels:
    filtered_label = data[labels == i]
    m_label = filtered_label[filtered_label['Gender']==0]
    ax1.scatter(m_label.iloc[:,0],
                m_label.iloc[:,1],
                color = colors[i],
                marker = 'o')
   
    f_label = filtered_label[filtered_label['Gender']==1]
    ax1.scatter(f_label.iloc[:,0],
                f_label.iloc[:,1],
                color = colors[i],
                marker = 'x')
    ax1.legend(['Male','Female'])
    ax1.scatter(kmeans.cluster_centers_[i][0], kmeans.cluster_centers_[i][1], marker="+", c='black',s=300)
    ax1.set_title(f"KMeans (k={best_k})")

# Cluster Means
cluster_means = pd.DataFrame(kmeans.cluster_centers_)
cluster_means.columns = ['Height','Weight','Waist']
cluster_means.index = range(1,best_k+1)
print('\nCluster Means:')
print(cluster_means)

# Confusion matrix
cmatrix_gender = pd.crosstab(y.astype(int), labels.astype(int)+1, colnames=['Clusters'])
cmatrix_gender.index = ['Male','Female']
cmatrix_gender.index.name = 'Gender'
print("\nConfusion matrix:")
print(cmatrix_gender)

#%%

#%%
## C-Means ##
from fcmeans import FCM

# Choosing optimal K
def optimal_Cmean(df, kmax):
    array = df.to_numpy()
    perf = pd.DataFrame()
    
    for k in range(1, kmax+1):
        cmeans = FCM(n_clusters = k)
        cmeans.fit(array)
        pred_clusters = cmeans.predict(array)
        
        if k == 1: curr_db = 1
        else: curr_db = davies_bouldin_score(df, pred_clusters)
        
        centroids = cmeans.centers
        # calculate square of Euclidean distance of each point from its cluster center and add to current WSS
        # https://medium.com/analytics-vidhya/how-to-determine-the-optimal-k-for-k-means-708505d204eb
        curr_sst = 0
        for i in range(len(array)):
            total_mean = df.mean(0)
            curr_sst += sum(np.power((array[i,] - total_mean),2))
            #curr_sst += (array[i, 0] - total_mean[0]) ** 2 + (array[i, 1] - total_mean[1]) ** 2 + (array[i, 2] - total_mean[2])** 2
                        
        curr_ssw = 0
        for i in range(len(array)):
            curr_center = centroids[pred_clusters[i],:]
            curr_ssw += sum(np.power((array[i,] - curr_center),2))
            #curr_ssw += (array[i, 0] - curr_center[0]) ** 2 + (array[i, 1] - curr_center[1]) ** 2 + (array[i, 2] - curr_center[2])** 2
        
        # curr_ssb = 0
        # for i in range(0,k):
        #     curr_center = centroids[i,:]
        #     curr_ssb += sum(sum(pred_clusters==i)*(curr_center - df.mean(0))**2)
        curr_ssb = curr_sst-curr_ssw
         
        perf.loc[k,'DBindex'] = curr_db
        perf.loc[k,'SSW'] = curr_ssw
        perf.loc[k,'SSB'] = curr_ssb
        perf.loc[k,'SSB/SSW'] = curr_ssb/curr_ssw
    return perf

result = optimal_Cmean(X,10)
print(result)

plt.plot(result['SSW'])
plt.xlabel('number of k')
plt.title('Within cluster sum of squares by cluster')
plt.show()

#result['DBindex'].plot()
print('the optimal k which has the lowerest DBindex score')
print(np.argmin(result["DBindex"])+1)


#%%
# Buliding model using best K and plot
best_k= np.argmin(result["DBindex"])+1
fcm = FCM(n_clusters = best_k)
fcm.fit(X.to_numpy())

labels = fcm.predict(X.to_numpy())
FCM_result = pd.concat([X, pd.DataFrame(labels+1,columns=['Cluster'])], axis=1)
print(FCM_result)

# plot
for i in range(len(data)):
    if data.loc[i,'Gender']=='male': data.loc[i,'Gender']=0
    elif data.loc[i,'Gender']=='female':data.loc[i,'Gender']=1
    
unique_labels = list(set(labels))
colors = ['b','g','m','c','r','y','k','0.25','0.5','0.75']

fig = plt.figure()
ax1 = fig.add_axes((0.1,0.5,0.8,0.8));ax1.set_xlabel('Height');ax1.set_ylabel('Weight')

for i in unique_labels:
    filtered_label = data[labels == i]
    m_label = filtered_label[filtered_label['Gender']==0]
    ax1.scatter(m_label.iloc[:,0],
                m_label.iloc[:,1],
                color = colors[i],
                marker = 'o')
   
    f_label = filtered_label[filtered_label['Gender']==1]
    ax1.scatter(f_label.iloc[:,0],
                f_label.iloc[:,1],
                color = colors[i],
                marker = 'x')
    ax1.legend(['Male','Female'])
    ax1.scatter(fcm.centers[i][0], fcm.centers[i][1], marker="+", c='black',s=300)
    ax1.set_title(f"CMeans (k={best_k})")
    
# Cluster Means
cluster_means = pd.DataFrame(fcm.centers)
cluster_means.columns = ['Height','Weight','Waist']
cluster_means.index = range(1,best_k+1)
print('\nCluster centers:')
print(cluster_means)

# Confusion matrix
cmatrix_gender = pd.crosstab(y.astype(int), labels.astype(int)+1, colnames=['Clusters'])
cmatrix_gender.index = ['Male','Female']
cmatrix_gender.index.name = 'Gender'
print("\nConfusion matrix:")
print(cmatrix_gender)


#%%

#%%
# GMC
from sklearn import mixture
# Finding best K
bic_gender = []
for k in range(1, 10):
    GMC = mixture.GaussianMixture(n_components=k,random_state=1)
    GMC.fit(X)
    bic_gender.append(str(GMC.bic(X)))
print("\n\nBIC")
print(bic_gender)
print('the optimal k which has the lowerest BIC score')
print(np.argmin(bic_gender)+1)

knee_gender = []
for i in range(1,10):
    gmc3 = mixture.GaussianMixture(n_components=i,random_state=1)
    gmc3.fit(X)
    knee_gender.append(gmc3.bic(X))
plt.plot(range(1,10) , knee_gender, marker = 'o')
plt.xlabel('Number of components')
plt.ylabel('Bayesian Information Criterion')
plt.show()

#%%
# Buliding model using best K and plot
best_k = np.argmin(bic_gender)+1
GMC = mixture.GaussianMixture(n_components=best_k,random_state=1)
GMC.fit(X)

labels = GMC.predict(X)
GMC_result = pd.concat([X, pd.DataFrame(labels+1,columns=['Cluster'])], axis=1)
print(GMC_result)

# plot
for i in range(len(data)):
    if data.loc[i,'Gender']=='male': data.loc[i,'Gender']=0
    elif data.loc[i,'Gender']=='female':data.loc[i,'Gender']=1
    
unique_labels = list(set(labels))
colors = ['b','g','m','c','r','y','k','0.25','0.5','0.75']

fig = plt.figure()
ax1 = fig.add_axes((0.1,0.5,0.8,0.8));ax1.set_xlabel('Height');ax1.set_ylabel('Weight')

for i in unique_labels:
    filtered_label = data[labels == i]
    m_label = filtered_label[filtered_label['Gender']==0]
    ax1.scatter(m_label.iloc[:,0],
                m_label.iloc[:,1],
                color = colors[i],
                marker = 'o')
   
    f_label = filtered_label[filtered_label['Gender']==1]
    ax1.scatter(f_label.iloc[:,0],
                f_label.iloc[:,1],
                color = colors[i],
                marker = 'x')
    ax1.legend(["Male", "Female"])
    ax1.scatter(GMC.means_[i][0], GMC.means_[i][1], marker="+", c='black',s=300)
    ax1.set_title(f"GMC (k={best_k})")
  
    
# Covariances
for i in range(0,best_k):
    print(f'\nCovariances of Cluster {i+1}:')
    c1=pd.DataFrame(GMC.covariances_[i])
    c1.columns = ['Height','Weight','Waist']
    c1.index = ['Height','Weight','Waist']
    print(c1)
    
    
# Cluster Means
cluster_means = pd.DataFrame(GMC.means_)
cluster_means.columns = ['Height','Weight','Waist']
cluster_means.index = range(1,best_k+1)
print('\nCluster centers:')
print(cluster_means)

# Confussion matrix
cmatrix_gender = pd.crosstab(y.astype(int), labels.astype(int)+1, colnames=['Cluster Num.'])
cmatrix_gender.index = ['Male','Female']
cmatrix_gender.index.name = 'Gender'
print("\nConfusion matrix:")
print(cmatrix_gender)
