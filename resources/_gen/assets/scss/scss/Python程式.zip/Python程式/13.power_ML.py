#!/usr/bin/env python
# coding: utf-8

# # Lasoo挑變數

# In[1]:
import matplotlib.pyplot as plt 
import numpy as np 
import pandas as pd 
import math
from pandas import read_csv
from sklearn.metrics import mean_squared_error
from sklearn.metrics import r2_score
import matplotlib
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split 
from sklearn.linear_model import LinearRegression
from sklearn.linear_model import Lasso,LassoCV
import statsmodels.api as sm
from pyearth import Earth

#%%
def RMSE(y_true,y_pred):
    return math.sqrt(np.mean(np.abs((y_true - y_pred)**2)))
def mean_absolute_error(y_true, y_pred):
    mae = np.mean((np.abs(y_true - y_pred)))
    return mae
def mean_absolute_percentage_error(y_true, y_pred): 
    y_true, y_pred = np.array(y_true).flatten(), np.array(y_pred).flatten()
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

def calPerformance(y_true,y_pred):
    temp_list=[]  
    RMSE_score=math.sqrt(mean_squared_error(y_true,y_pred))  
    temp_list.append(RMSE_score)
    MAE_score=mean_absolute_error(y_true,y_pred)  
    temp_list.append(MAE_score)
    MAPE_score=mean_absolute_percentage_error(y_true,y_pred)  
    temp_list.append(MAPE_score) 
    return temp_list

def error_plot(train, test):
      len_prediction=[x for x in range(len(test))]
      plt.figure(figsize=(10,10))
      plt.plot(len_prediction, train, label="train",linewidth=1.5)
      plt.plot(len_prediction, test, 'g', label="test",linewidth=1.5)
#       plt.axhline(y=20, xmin=1, xmax=100)
#       plt.axvline(x=5, ymin=0.1, ymax=0.9)
      plt.tight_layout()
#       sns.despine(top=True)
      plt.subplots_adjust(left=0.07)
      plt.ylabel('error', size=15)
      plt.xlabel('No.', size=15)
      plt.legend(fontsize=15)
      plt.show()
      
def error_test_train_plot(train,test):
      len_prediction=[x for x in range(len(test))]
      plt.figure(figsize=(10,10))
      plt.plot(len_prediction, abs(test-train), label="test-train",linewidth=1.5)
#       plt.axhline(y=20, xmin=1, xmax=100)
      plt.tight_layout()
#       sns.despine(top=True)
      plt.subplots_adjust(left=0.07)
      plt.ylabel('error', size=15)
      plt.xlabel('No.', size=15)
      plt.legend(fontsize=15)
      plt.show()

# In[80]:
power = pd.read_csv('electricity.csv')
power=power.drop(['Time','WEP','MEP'],axis=1)
#power = power[['IPI','AverageTemp','ExportOrderAmount','ImportTotalValue_MachineryandEquipment','Humidity','SeasonIndex',
#               'RegularWage','TotalDemand']]

print("資料特徵數(x+y)："+str(len(list(power.columns))))#+str(len(list(power.columns)))
print(power.columns)

x = power.iloc[0:289, 0:14]
y = power.iloc[0:289, 14]

x_train= power.iloc[0:264, 0:14]
y_train= power.iloc[0:264, 14]
x_test= power.iloc[264:288, 0:14]
y_test= power.iloc[264:288, 14]

print(x_train.shape, y_train.shape, x_test.shape, y_test.shape)

# In[81]:

# 建立MLR模型及變數顯著性展示
MLR = sm.OLS(y_train,x_train).fit()
print(MLR.summary())
MLR.pvalues

#MLR變數顯著性展示
result = pd.DataFrame()
result = pd.DataFrame(columns=['是否為重要變數'],index=x.columns)

for i in range(0,np.shape(x_train)[1]):
#     print(np.array(i))
    if MLR.pvalues[i]<0.05:
        result.iloc[i,0]="Yes"
    else:
        result.iloc[i,0]="No"
print("特徵個數:",np.shape(x_train)[1])
print(result)

MLR_train = MLR.predict(x_train)
perf_tr = calPerformance(y_train,MLR_train)
MLR_test = MLR.predict(x_test)
perf_ts = calPerformance(y_test,MLR_test)

MLR_perf = pd.DataFrame({
             'MLR': ['RMSE','MAE','MAPE'], 
             'Training': perf_tr ,
              'Testing':  perf_ts ,
             }) 
MLR_perf = MLR_perf.set_index(['MLR'],drop=True)
print(MLR_perf)

# In[93]:
# MARS調參 (Panalty 為GCV的懲罰值)
mars_grid = { 'max_degree': list((1,2,3)),'penalty':list((10,20,40))}
grid = GridSearchCV(Earth(feature_importance_type='gcv'),param_grid=mars_grid, cv=3)
grid.fit(x_train,y_train)
grid.cv_results_, grid.best_params_, grid.best_score_
print(grid.best_params_)#MARS最佳參數

MARS = grid.best_estimator_
MARS.fit(x_train,y_train)
print(MARS.summary_feature_importances(sort_by='gcv'))

# In[141]:
# MARS模型績效
MARS_train = MARS.predict(x_train)
perf_tr = calPerformance(y_train,MARS_train)
MARS_test = MARS.predict(x_test)
perf_ts = calPerformance(y_test,MARS_test)

MARS_perf = pd.DataFrame({
             'MARS': ['RMSE','MAE','MAPE'], 
             'Training': perf_tr ,
              'Testing':  perf_ts ,
             }) 
MARS_perf = MARS_perf.set_index(['MARS'],drop=True)
print(MARS_perf)

#%%
# KNN調參
from sklearn.neighbors import KNeighborsRegressor
range_=range(2,10,1)
error = pd.DataFrame()
error = pd.DataFrame(columns=['n_neighbors','train', 'test','']
                     ,index=range(0,np.shape(range_)[0]))

for i in range_:
    print("n_neighbors=",i)
    knn=KNeighborsRegressor(n_neighbors=i)
    train_KNN = knn.fit(x_train, y_train).predict(x_train)
    test_KNN = knn.fit(x_train, y_train).predict(x_test)
    #mape_train = np.mean(abs((np.array(y_train)-train_KNN)/np.array(y_train)))
    #mape_test = np.mean(abs((np.array(y_test)-test_KNN)/np.array(y_test)))
    mape_train = mean_absolute_percentage_error(y_train,train_KNN)
    mape_test = mean_absolute_percentage_error(y_test,test_KNN)
    print("train_mape:",mape_train)
    print("test_mape:",mape_test)
    print("difference:",mape_test-mape_train)
    
    error.iloc[(i-2),0]=i
    error.iloc[(i-2),1]=mape_train
    error.iloc[(i-2),2]=mape_test
    error.iloc[(i-2),3]=mape_test-mape_train
    print("**********************************************************")

print("K for min_mape:",error[error.test==error.test.min()].n_neighbors.values[0])#MAPE最小K值

# In[178]:
# 建立KNN模型  
best_k=error[error.test==error.test.min()].n_neighbors.values[0]
knn = KNeighborsRegressor(n_neighbors=best_k)
knn.fit(x_train, y_train)

# KNN模型績效
KNN_train =knn.predict(x_train)
perf_tr = calPerformance(y_train,KNN_train)
KNN_test = knn.predict(x_test)
perf_ts = calPerformance(y_test,KNN_test)

KNN_perf = pd.DataFrame({
             'KNN': ['RMSE','MAE','MAPE'], 
             'Train': perf_tr ,'Test':  perf_ts ,
             }) 
KNN_perf = KNN_perf.set_index(['KNN'],drop=True)
print(KNN_perf)

# In[84]:

lasso=LassoCV()
lasso.fit(x_train,y_train)
print(lasso.alpha_)

# In[85]:
range_= np.arange(50000,200000,10000)
error = pd.DataFrame()
error = pd.DataFrame(columns=['alpha','train', 'test','test_train','number of features used']
         ,index=range(0,np.shape(range_)[0]))
t=1
for i in range_:
    print("alpha=",i)
    lasso = Lasso(alpha=i, max_iter=1000,fit_intercept=True, random_state=0)
    lasso.fit(x_train,y_train) 
    train_score=lasso.score(x_train,y_train) 
    test_score=lasso.score(x_test,y_test) 
    coeff_lasso = np.sum(lasso.coef_!=0)
    train_lasso=lasso.fit(x_train,y_train).predict(x_train)
    test_lasso=lasso.fit(x_train,y_train).predict(x_test)
    
    error.iloc[(t-1),0]=i
    error.iloc[(t-1),1]=mean_absolute_percentage_error(y_train,train_lasso)
    error.iloc[(t-1),2]=mean_absolute_percentage_error(y_test,test_lasso)
    error.iloc[(t-1),3]=mean_absolute_percentage_error(y_test,test_lasso)-mean_absolute_percentage_error(y_train,train_lasso)
    error.iloc[(t-1),4]=coeff_lasso
    
    print ("features used: ", coeff_lasso)
    print("train_mape:",mean_absolute_percentage_error(y_train,train_lasso))
    print("test_mape:",mean_absolute_percentage_error(y_test,test_lasso))
    print("test-train:",mean_absolute_percentage_error(y_test,test_lasso)-mean_absolute_percentage_error(y_train,train_lasso))
    t=t+1
    print("**********************************************************")
    
print(error)

#%%
lasso = Lasso(alpha=130000, max_iter=5000,fit_intercept=True, random_state=0)
lasso.fit(x_train,y_train)

# Lasso變數重要性展示
result = pd.DataFrame()
result = pd.DataFrame(columns=['是否為重要變數'],index=x.columns)

for i in range(0,np.shape(x_train)[1]):
#     print(np.array(i))
    if lasso.coef_[i]!=0:
        result.iloc[i,0]="Yes"
    else:
        result.iloc[i,0]="No"
print("特徵個數:",np.shape(x_train)[1])
print(result)

# In[87]:
Lasso_train = lasso.predict(x_train)
perf_tr = calPerformance(y_train,Lasso_train)
Lasso_test = lasso.predict(x_test)
perf_ts = calPerformance(y_test,Lasso_test)

Lasso_perf = pd.DataFrame({
             'Lasso': ['RMSE','MAE','MAPE'], 
             'Training': perf_tr ,
              'Testing':  perf_ts ,
             }) 
Lasso_perf = Lasso_perf.set_index(['Lasso'],drop=True)
print(Lasso_perf)

#%%
len_pred=[x for x in range(len(error['number of features used']))]
plt.figure(figsize=(10,10))
plt.plot(len_pred, error['number of features used'], label="number of features used"
         ,linewidth=1.5)
#       plt.axhline(y=20, xmin=1, xmax=100)
plt.tight_layout()
#       sns.despine(top=True)
plt.subplots_adjust(left=0.07)
plt.ylabel('Number of features used', size=15)
plt.xlabel('No.', size=15)
plt.legend(fontsize=15)
plt.show()

error_plot(error["train"],error["test"])

# In[88]:
# Electricity電力各模型績效
print('---Electricity電力各模型績效----')
print(MLR_perf)
print('------------------------------')
print(MARS_perf)
print('------------------------------')
print(KNN_perf)
print('------------------------------')
print(Lasso_perf)

##四種種模型比較
perf_tr = pd.DataFrame({
    'Training':['RMSE','MAE','MAPE'],
    'MLR':[round(x, 3) for x in (MLR_perf.iloc[0,0],MLR_perf.iloc[1,0],MLR_perf.iloc[2,0])],
    'MARS':[round(x, 3) for x in(MARS_perf.iloc[0,0],MARS_perf.iloc[1,0],MARS_perf.iloc[2,0])],
    'KNN':[round(x, 3) for x in(KNN_perf.iloc[0,0],KNN_perf.iloc[1,0],KNN_perf.iloc[2,0])],
    'LASSO':[round(x, 3) for x in(Lasso_perf.iloc[0,0],Lasso_perf.iloc[1,0],Lasso_perf.iloc[2,0])]
})

perf_ts = pd.DataFrame({
    'Testing':['RMSE','MAE','MAPE'],
    'MLR':[round(x, 3) for x in (MLR_perf.iloc[0,1],MLR_perf.iloc[1,1],MLR_perf.iloc[2,1])],
    'MARS':[round(x, 3) for x in(MARS_perf.iloc[0,1],MARS_perf.iloc[1,1],MARS_perf.iloc[2,1])],
    'KNN':[round(x, 3) for x in(KNN_perf.iloc[0,1],KNN_perf.iloc[1,1],KNN_perf.iloc[2,1])],
    'LASSO':[round(x, 3) for x in(Lasso_perf.iloc[0,1],Lasso_perf.iloc[1,1],Lasso_perf.iloc[2,1])]
})
perf_tr = perf_tr.set_index(['Training'],drop=True)
perf_ts = perf_ts.set_index(['Testing'],drop=True)

print(perf_tr)
print('\n',perf_ts)    

# In[89]:
min_error=error[error.test_train==error['test_train'].min()].index.values
print("第%d資料訓練及測試表現最相近" % min_error[0])
print("*******************************")
print(error.loc[min_error[0]])

lasso = Lasso(alpha=error.iloc[min_error[0],0], max_iter=20000)
lasso.fit(x_train,y_train) 
train_score=lasso.score(x_train,y_train) 
test_score=lasso.score(x_test,y_test) 
coeff_used = np.sum(lasso.coef_!=0) 
train_pred=lasso.fit(x_train,y_train).predict(x_train)
test_pred=lasso.fit(x_train,y_train).predict(x_test)
print ("number of features used: ", coeff_used)
print("train_mape:",mean_absolute_percentage_error(y_train,train_pred))
print("train_mape:",mean_absolute_percentage_error(y_test,test_pred))
print("test_train:",mean_absolute_percentage_error(y_test,test_pred)-mean_absolute_percentage_error(y_test,test_pred))
print("************************************************************************")
print("所有的迴歸係數(不含截距):")
print(lasso.coef_)

# In[90]:

##四種種模型比較
#plot
real=pd.concat([pd.DataFrame(y_train),pd.DataFrame(y_test)],axis=0)
real.index= pd.date_range('2001',periods = 288,freq = '1m')
MLR_pred=pd.concat([pd.DataFrame(MLR_train),pd.DataFrame(MLR_test)],axis=0)
MLR_pred=MLR_pred.reset_index(drop=True)
MLR_pred.index= pd.date_range('2001',periods = 288,freq = '1m')
MARS_pred=pd.concat([pd.DataFrame(MARS_train),pd.DataFrame(MARS_test)],axis=0)
MARS_pred=MARS_pred.reset_index(drop=True)
MARS_pred.index= pd.date_range('2001',periods = 288,freq = '1m')
KNN_pred=pd.concat([pd.DataFrame(KNN_train),pd.DataFrame(KNN_test)],axis=0)
KNN_pred=KNN_pred.reset_index(drop=True)
KNN_pred.index= pd.date_range('2001',periods = 288,freq = '1m')
Lasso_pred=pd.concat([pd.DataFrame(Lasso_train),pd.DataFrame(Lasso_test)],axis=0)
Lasso_pred=Lasso_pred.reset_index(drop=True)
Lasso_pred.index= pd.date_range('2001',periods = 288,freq = '1m')

plt.figure(figsize=(20,10))
plt.plot( real, color='black', label="Real",linewidth=1.5)
plt.plot( MLR_pred, color='green', label="MLR_pred",linewidth=1.5)
plt.plot( MARS_pred, color='orange', label="MARS_pred",linewidth=1.5)
plt.plot( KNN_pred, color='red', label="KNN_pred",linewidth=1.5)
plt.plot( Lasso_pred, color='blue', label="Lasso_pred",linewidth=1.5)

plt.legend(loc = 'lower left')
plt.legend(fontsize=15)
plt.xlabel('Date', size=15)
plt.ylabel('Taiwan_electricity', size=15)

#%%

