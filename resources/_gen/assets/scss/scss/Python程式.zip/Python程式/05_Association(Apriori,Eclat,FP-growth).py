# -*- coding: utf-8 -*-
"""
Created on Sat Sep 11 13:41:45 2021

@author: SLPC
"""
## Apriori ##
import pandas as pd
from apyori import apriori #pip install apyori
from pyECLAT import ECLAT #pip install pyECLAT
from fpgrowth_py import fpgrowth #pip install fpgrowth-py

#%%
# Data Proprocessing
data= pd.read_csv('pima.csv')
data.describe()
df=data

#data[(data.BloodPressure!=0) & (data.BloodPressure!=0)] 
df=data[data.BloodPressure!=0]
df=df[df.Glucose!=0]
df=df[df.SkinThickness!=0]
df=df[df.BMI!=0]
df=df[df.Insulin!=0]
details=df.describe()
df.info()

#data1=data.drop(['Pregnancies','Outcome'],axis=1)
#df1=data1[data1.loc[:]!=0].dropna()

#discretize the data into 3 group: [Q1 low, Q2~Q3 medium, Q4 high]
df1 = df.drop(['SkinThickness','Insulin','Outcome'],axis=1).apply(lambda x: pd.qcut(x,[0,.25,.75,1] ,[f'low_{x.name}',f'med_{x.name}',f'high_{x.name}'],duplicates='drop'), axis=0)
df2 = df[['SkinThickness','Insulin']].apply(lambda x: pd.qcut(x,2,[f'low_{x.name}',f'high_{x.name}'],duplicates='drop'), axis=0)
df3 = df['Outcome'].replace(1,'Yes').replace(0,'No').astype('category')

output_df = pd.concat([df1, df2, df3], axis=1)
output_df.apply(lambda x: pd.value_counts(x),axis=0)
output_df.info()

#%%
# transfer df to list
records = []
for i in range(0, len(output_df)):
    records.append([str(output_df.values[i,j]) for j in range(0, len(output_df.columns))])

#%%
## Apriori ##
association_rules = apriori(records, min_support=0.1, min_confidence=0.6, min_lift=1) #, min_length=2
association_results = list(association_rules)

#%%
#Showing RHS = 'Yes'
#item[1]
RHS = 'Yes'
print(f'The Apriori rule when the RHS is {RHS} : \n')
count=0
for item in association_results:
    if len(item[0])>1:
        for i in item[2]:
            if RHS in list(i[1]) and len(i[1])==1:
                count +=1
                print("Rule: " + str(list(i[0])) + " -> " + str(list(i[1])))
                print("Support: " + str(item[1]))
                print("Confidence: " + str(i[2]))
                print("Lift: " + str(i[3]))
                print("=====================================")
print(f'\nThere are {count} rules when the RHS is {RHS}')

#%%
#Showing RHS = 'No'
RHS = 'No'
print(f'The Apriori rule when the RHS is {RHS} : \n')
count=0
for item in association_results:
    if len(item[0])>1:
        for i in item[2]:
            if RHS in list(i[1]) and len(i[1])==1:
                count +=1
                print("Rule: " + str(list(i[0])) + " -> " + str(list(i[1])))
                print("Support: " + str(item[1]))
                print("Confidence: " + str(i[2]))
                print("Lift: " + str(i[3]))
                print("=====================================")
print(f'\nThere are {count} rules when the RHS is {RHS}')

#%%
## Eclat ##
output_df2 = output_df
output_df2.columns = range(0,len(output_df2.columns))
eclat_instance = ECLAT(data=output_df2.reset_index(drop=True), verbose=True) #verbose=True to see the loading bar
get_ECLAT_indexes, get_ECLAT_supports = eclat_instance.fit(min_support=0.1,
                                                           min_combination=3,
                                                           max_combination=4,
                                                           separator=' & ',
                                                           verbose=True)

#%%
RHS = 'Yes'
count=0
print(f'The Eclat rule when the RHS is {RHS} : \n')
for item in get_ECLAT_supports:
    item_ = item.split(' & ')
    if RHS in item_ and len(item_)>1: 
        count+=1
        item_.remove(RHS)
        print("Rule: " + str(item_) + " -> " + RHS)
        print('Support: ' +str(get_ECLAT_supports.get(f'{item}')))
        print("\n=====================================")
print(f'\nThere are {count} rules when the RHS is {RHS}')   

#%%
RHS = 'No'
count=0
print(f'The Eclat rule when the RHS is {RHS} : \n')
for item in get_ECLAT_supports:
    item_ = item.split(' & ')
    if RHS in item_ and len(item_)>1: 
        count+=1
        item_.remove(RHS)
        print("Rule: " + str(item_) + " -> " + RHS)
        print('Support: ' +str(get_ECLAT_supports.get(f'{item}')))
        print("\n=====================================")
print(f'\nThere are {count} rules when the RHS is {RHS}')   


#%%
## FP-growth ##
freqItemSet, rules = fpgrowth(records, minSupRatio=0.1, minConf=0.6)

RHS = "Yes"
count = 0
print(f'The FP-growth rule when the RHS is {RHS} : \n')
for item in rules:
    if item[1] in [{RHS}]:
    # first index of the inner list
    # Contains base item and add item
        count+=1
        print("Rule: ",item[0:2])
        print("Confidence: ",item[2])
        print("=====================================")
print(f'\nThere are {count} rules when the RHS is {RHS}') 

#%%
RHS = 'No'
count = 0
print(f'The FP-growth rule when the RHS is {RHS} : \n')
for item in rules:
    if item[1] in [{RHS}]:
    # first index of the inner list
    # Contains base item and add item
        count+=1
        print("Rule: ",item[0:2])
        print("Confidence: ",item[2])
        print("=====================================")
print(f'\nThere are {count} rules when the RHS is {RHS}') 
