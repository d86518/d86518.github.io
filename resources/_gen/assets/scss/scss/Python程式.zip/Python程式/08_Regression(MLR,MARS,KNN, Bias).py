#!/usr/bin/env python
# coding: utf-8

# # Boston House Pricing Forecast

# In[94]:
import math
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np 
import pandas as pd 
import statsmodels.api as sm
from sklearn.metrics import mean_absolute_error,mean_squared_error,mean_absolute_percentage_error
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from pyearth import Earth
from sklearn.metrics import r2_score

#%%
def calPerformance(y_true,y_pred):
    temp_list=[]  
    RMSE_score=math.sqrt(mean_squared_error(y_true,y_pred))  
    temp_list.append(RMSE_score)
    MAE_score=mean_absolute_error(y_true,y_pred)  
    temp_list.append(MAE_score)
    MAPE_score=mean_absolute_percentage_error(y_true,y_pred)  
    temp_list.append(MAPE_score) 
    return temp_list

# In[121]:
### 載入Boston Data ###
data=pd.read_csv('boston.csv',delimiter=",")
print('The shape of our features is:', data.shape)
print(data.isnull().any())#檢查有無缺失值

#%%
# 加入虛擬變數
#df=data.join(pd.get_dummies(data.CHAS))
#df.rename(columns={1:'CHAS_Yes'},inplace=True)
#df = df.drop(['CHAS',0], axis=1)
#print(df['CHAS_Yes'])

#%%
# Randomly split data into train and test(非時間序列資料)
x = data.drop(['MV'], axis=1)
y = data['MV']
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.25, random_state=5)
print('The shape of x_train is:', x_train.shape)
print('The shape of y_train is:', y_train.shape)
print('The shape of x_test is:', x_test.shape)
print('The shape of y_test is:', y_test.shape)

# In[127]:
# Linear Model-correlation
plt.figure(figsize=(12,12))
sns.heatmap(data=data.corr().round(2).abs(), annot=True) 

# In[129]:
# 建立MLR模型及變數顯著性展示
est = sm.OLS(y,x).fit()
print(est.summary())
lm = LinearRegression()
lm.fit(x_train, y_train)

MLR_train = lm.predict(x_train)
perf_tr = calPerformance(y_train,MLR_train)
MLR_test = lm.predict(x_test)
perf_ts = calPerformance(y_test,MLR_test)

MLR_perf = pd.DataFrame({
             'MLR': ['RMSE','MAE','MAPE'], 
             'Training': perf_tr ,
              'Testing':  perf_ts ,
             }) 
MLR_perf = MLR_perf.set_index(['MLR'],drop=True)
print(MLR_perf)

# In[93]:
# MARS調參 (Panalty 為GCV的懲罰值)
mars_grid = { 'max_degree': list((1,2,3)),'penalty':list((10,15,20))}
grid = GridSearchCV(Earth(feature_importance_type='gcv'),param_grid=mars_grid, cv=5)
grid.fit(x_train,y_train)
grid.cv_results_, grid.best_params_, grid.best_score_
print(grid.best_params_)#MARS最佳參數

MARS = grid.best_estimator_
MARS.fit(x_train,y_train)
print(MARS.summary_feature_importances(sort_by='gcv'))

# In[141]:
# MARS模型績效
MARS_train = MARS.predict(x_train)
perf_tr = calPerformance(y_train,MARS_train)
MARS_test = MARS.predict(x_test)
perf_ts = calPerformance(y_test,MARS_test)

MARS_perf = pd.DataFrame({
             'MARS': ['RMSE','MAE','MAPE'], 
             'Training': perf_tr ,
              'Testing':  perf_ts ,
             }) 
MARS_perf = MARS_perf.set_index(['MARS'],drop=True)
print(MARS_perf)

# In[177]:
# KNN調參
from sklearn.neighbors import KNeighborsRegressor
range_=range(2,10,1)
error = pd.DataFrame()
error = pd.DataFrame(columns=['n_neighbors','train', 'test','']
                     ,index=range(0,np.shape(range_)[0]))
for i in range_:
    print("n_neighbors=",i)
    knn=KNeighborsRegressor(n_neighbors=i)
    knn.fit(x_train, y_train)
    train_KNN = knn.fit(x_train, y_train).predict(x_train)
    test_KNN = knn.fit(x_train, y_train).predict(x_test)
    mape_train = np.mean(abs((np.array(y_train)-train_KNN)/np.array(y_train)))
    mape_test = np.mean(abs((np.array(y_test)-test_KNN)/np.array(y_test)))
    print("train_mape:",mape_train)
    print("test_mape:",mape_test)
    print("difference:",mape_test-mape_train)
    
    error.iloc[(i-2),0]=i
    error.iloc[(i-2),1]=mape_train
    error.iloc[(i-2),2]=mape_test
    error.iloc[(i-2),3]=mape_test-mape_train
    print("**********************************************************")

print("k for min_mape:",error[error.test==error.test.min()].n_neighbors.values[0])#MAPE最小K值

# In[178]:
# 建立KNN模型  
best_k=error[error.test==error.test.min()].n_neighbors.values[0]
knn = KNeighborsRegressor(n_neighbors=best_k)
knn.fit(x_train, y_train)

# KNN模型績效
KNN_train =knn.predict(x_train)
perf_tr = calPerformance(y_train,KNN_train)
KNN_test = knn.predict(x_test)
perf_ts = calPerformance(y_test,KNN_test)

KNN_perf = pd.DataFrame({
             'KNN': ['RMSE','MAE','MAPE'], 
             'Train': perf_tr ,'Test':  perf_ts ,
             }) 
KNN_perf = KNN_perf.set_index(['KNN'],drop=True)
print(KNN_perf)

#%%# In[186]:
# Boston房價各模型績效
print('---Boston房價各模型績效---')
print(MLR_perf)
print('---------------------------')
print(MARS_perf)
print('---------------------------')
print(KNN_perf)

#%%
# Lasso調參
from sklearn.linear_model import Lasso,LassoCV
range_=np.arange(5,31,5)
error = pd.DataFrame()
error = pd.DataFrame(columns=['alpha','train', 'test','number of features used']
                     ,index=range(0,np.shape(range_)[0]))
t=1
for i in range_:
    print("alpha=",i)
    lasso = Lasso(alpha=i, max_iter=5000,fit_intercept=True, random_state=0)
    lasso.fit(x_train,y_train) 
    #train_score=lasso.score(x_train,y_train) 
    #test_score=lasso.score(x_test,y_test) 
    coeff_lasso = np.sum(lasso.coef_!=0)
    train_lasso=lasso.fit(x_train,y_train).predict(x_train)
    test_lasso=lasso.fit(x_train,y_train).predict(x_test)
    print ("features used: ", coeff_lasso)
    print("train_mape:",mean_absolute_percentage_error(y_train,train_lasso))
    print("test_mape:",mean_absolute_percentage_error(y_test,test_lasso))
    
    error.iloc[(t-1),0]=i
    error.iloc[(t-1),1]=mean_absolute_percentage_error(y_train,train_lasso)
    error.iloc[(t-1),2]=mean_absolute_percentage_error(y_test,test_lasso)
    error.iloc[(t-1),3]=coeff_lasso
    t=t+1
    print("**********************************************************")

error

#%%
lasso = Lasso(alpha=10, max_iter=5000,fit_intercept=True, random_state=0)
lasso.fit(x_train,y_train)

# Lasso變數重要性展示
result_l = pd.DataFrame()
result_l = pd.DataFrame(columns=['是否為重要變數'],index=x.columns)

for i in range(0,np.shape(x_train)[1]):
#     print(np.array(i))
    if lasso.coef_[i]!=0:
        result_l.iloc[i,0]="Yes"
    else:
        result_l.iloc[i,0]="No"
print("特徵個數:",np.shape(x_train)[1])
print(result_l)

#%%# Lasso模型績效
Lasso_train = lasso.predict(x_train)
perf_ltr = calPerformance(y_train,Lasso_train)
Lasso_test = lasso.predict(x_test)
perf_lts = calPerformance(y_test,Lasso_test)
Lasso_perf = pd.DataFrame({
             'Lasso': ['RMSE','MAE','MAPE'], 
             'Training': perf_ltr ,
              'Testing':  perf_lts ,
             }) 
Lasso_perf = Lasso_perf.set_index(['Lasso'],drop=True)
print(Lasso_perf)

#%%
from sklearn.linear_model import Ridge
error = pd.DataFrame()
error = pd.DataFrame(columns=['alpha','train', 'test','number of features used']
                     ,index=range(0,np.shape(range_)[0]))
t=1
for i in range_:
    print("alpha=",i)
    #from sklearn.metrics import r2_score
    ridge = Ridge(alpha=i, max_iter=5000,fit_intercept=True, random_state=0)
    ridge.fit(x_train,y_train) 
    #train_score=lasso.score(x_train,y_train) 
    #test_score=lasso.score(x_test,y_test) 
    coeff_ridge = np.sum(ridge.coef_!=0)
    train_ridge=ridge.fit(x_train,y_train).predict(x_train)
    test_ridge=ridge.fit(x_train,y_train).predict(x_test)
    print ("features used: ", coeff_ridge)
    print("train_mape:",mean_absolute_percentage_error(y_train,train_ridge))
    print("test_mape:",mean_absolute_percentage_error(y_test,test_ridge))
    error.iloc[(t-1),0]=i
    error.iloc[(t-1),1]=mean_absolute_percentage_error(y_train,train_ridge)
    error.iloc[(t-1),2]=mean_absolute_percentage_error(y_test,test_ridge)
    error.iloc[(t-1),3]=coeff_ridge
    t=t+1
    print("**********************************************************")

error 

#%%
ridge = Ridge(alpha=5, max_iter=5000,fit_intercept=True, random_state=0)
ridge.fit(x_train,y_train)

result_r = pd.DataFrame()
result_r = pd.DataFrame(columns=['是否為重要變數'],index=x.columns)

for i in range(0,np.shape(x_train)[1]):
#     print(np.array(i))
    if np.abs(ridge.coef_[i])>=0.05:
        result_r.iloc[i,0]="Yes"
    else:
        result_r.iloc[i,0]="No"
print("特徵個數:",np.shape(x_train)[1])
print(result_r)

#%%#
Ridge_train = ridge.predict(x_train)
perf_rtr = calPerformance(y_train,Ridge_train)
Ridge_test = ridge.predict(x_test)
perf_rts = calPerformance(y_test,Ridge_test)

Ridge_perf = pd.DataFrame({
             'Ridge': ['RMSE','MAE','MAPE'], 
             'Training': perf_rtr ,
              'Testing':  perf_rts ,
             }) 
Ridge_perf = Ridge_perf.set_index(['Ridge'],drop=True)
print(Ridge_perf)

#%%
from sklearn.linear_model import ElasticNet
error = pd.DataFrame()
error = pd.DataFrame(columns=['alpha','train', 'test','number of features used']
                     ,index=range(0,np.shape(range_)[0]))
t=1
for i in range_:
    print("alpha=",i)
    #from sklearn.metrics import r2_score
    elast = ElasticNet(alpha=i, max_iter=5000,fit_intercept=True, random_state=0)
    elast.fit(x_train,y_train) 
    #train_score=lasso.score(x_train,y_train) 
    #test_score=lasso.score(x_test,y_test) 
    coeff_elast = np.sum(elast.coef_!=0)
    train_elast=elast.fit(x_train,y_train).predict(x_train)
    test_elast=elast.fit(x_train,y_train).predict(x_test)
    print ("features used: ", coeff_elast)
    print("train_mape:",mean_absolute_percentage_error(y_train,train_elast))
    print("test_mape:",mean_absolute_percentage_error(y_test,test_elast))
    error.iloc[(t-1),0]=i
    error.iloc[(t-1),1]=mean_absolute_percentage_error(y_train,train_elast)
    error.iloc[(t-1),2]=mean_absolute_percentage_error(y_test,test_elast)
    error.iloc[(t-1),3]=coeff_elast
    t=t+1
    print("**********************************************************")

error

#%% 
elast = ElasticNet(alpha=5, max_iter=5000,fit_intercept=True, random_state=0)
elast.fit(x_train,y_train)

# elast變數重要性展示
result_e = pd.DataFrame()
result_e = pd.DataFrame(columns=['是否為重要變數'],index=x.columns)

for i in range(0,np.shape(x_train)[1]):
#     print(np.array(i))
    if elast.coef_[i]!=0:
        result_e.iloc[i,0]="Yes"
    else:
        result_e.iloc[i,0]="No"
print("特徵個數:",np.shape(x_train)[1])
print(result_e)

#%%#
Elast_train = elast.predict(x_train)
perf_etr = calPerformance(y_train,Elast_train)
Elast_test = elast.predict(x_test)
perf_ets = calPerformance(y_test,Elast_test)
Elast_perf = pd.DataFrame({
             'Elast': ['RMSE','MAE','MAPE'], 
             'Training': perf_etr ,
              'Testing':  perf_ets ,
             }) 
Elast_perf = Elast_perf.set_index(['Elast'],drop=True)
print(Elast_perf)

# In[186]:
# Boston房價各模型績效
print('---Boston房價各模型績效---')
print(Ridge_perf)
print('---------------------------')
print(Lasso_perf)
print('---------------------------')
print(Elast_perf)
