# -*- coding: utf-8 -*-
"""
Created on Mon Sep  6 11:03:14 2021

@author: a0978
"""
import pandas as pd
from matplotlib import pyplot as plt
from statsmodels.tsa.seasonal import seasonal_decompose
from statsmodels.tsa.holtwinters import SimpleExpSmoothing
from statsmodels.tsa.holtwinters import ExponentialSmoothing
import warnings
warnings.filterwarnings('ignore')

#%%
airline=pd.read_csv('AirPassengers.csv',index_col='Month', parse_dates=True)
#finding shape of the dataframe
print(airline.shape)
# having a look at the data
print(airline.head())
#plotting the original data
airline[['Passengers']].plot(title='Passengers Data')

decompose_result1 = seasonal_decompose(airline['Passengers'], model='multiplicative')
decompose_result1.plot();

decompose_result2 = seasonal_decompose(airline['Passengers'], model='additive')
decompose_result2.plot();

#%%
airline['HWES1'] = SimpleExpSmoothing(airline['Passengers']).fit(smoothing_level=0.25, optimized=False,use_brute=True).fittedvalues
airline[['Passengers','HWES1']].plot(title='Holt Winters Single Exponential Smoothing');

airline['HWES2_ADD'] = ExponentialSmoothing(airline['Passengers'],trend='add').fit().fittedvalues
airline['HWES2_MUL'] = ExponentialSmoothing(airline['Passengers'],trend='mul').fit().fittedvalues
airline[['Passengers','HWES2_ADD','HWES2_MUL']].plot(title='Holt Winters Double Exponential Smoothing: Additive and Multiplicative Trend');

airline['HWES3_ADD'] = ExponentialSmoothing(airline['Passengers'],trend='add',seasonal='add',seasonal_periods=12).fit().fittedvalues
airline['HWES3_MUL'] = ExponentialSmoothing(airline['Passengers'],trend='mul',seasonal='mul',seasonal_periods=12).fit().fittedvalues
airline[['Passengers','HWES3_ADD','HWES3_MUL']].plot(title='Holt Winters Triple Exponential Smoothing: Additive and Multiplicative Seasonality');


# Split into train and test set
train_airline = airline[:120]
test_airline = airline[120:]

fitted_model = ExponentialSmoothing(train_airline['Passengers'],trend='mul',seasonal='mul',seasonal_periods=12).fit()
test_predictions = fitted_model.forecast(24)
train_airline['Passengers'].plot(legend=True,label='TRAIN')
test_airline['Passengers'].plot(legend=True,label='TEST',figsize=(6,4))
test_predictions.plot(legend=True,label='PREDICTION')
plt.title('Train, Test and Predicted Test using Holt Winters')

from sklearn.metrics import mean_absolute_error,mean_squared_error,mean_absolute_percentage_error
print(f"Mean Absolute Error = {mean_absolute_error(test_airline['Passengers'],test_predictions)}")
print(f"Root Mean Squared Error = {mean_squared_error(test_airline['Passengers'],test_predictions)**0.5}")
print(f"Mean Absolute Percentage Error = {mean_absolute_percentage_error(test_airline['Passengers'],test_predictions)}")

#%%
from permetrics.regression import RegressionMetric

def calPerformance(y_true,y_pred):
    temp_list=[] 
    calPerf = RegressionMetric(y_true, y_pred, decimal=3)
    RMSE_score = calPerf.RMSE(multi_output="raw_values", decimal=3)
    temp_list.append(RMSE_score)
    MAE_score = calPerf.MAE(multi_output="raw_values", decimal=3)
    temp_list.append(MAE_score)
    MAPE_score = calPerf.MAPE(multi_output="raw_values", decimal=3)
    temp_list.append(MAPE_score)
    return temp_list

#%%
# Data preparation
data = pd.read_csv('2016_2024stock.csv')
data.head()
data.tail()
data.info()
price=data[['Index']]

price.plot(color='steelblue', linewidth=2, figsize=(10,6),title='Taiwan Stock (2016-2024)')
y_true = price.to_numpy()

#%%
# SMA- simple moving average
length = [5,10,20]
SMA_perf = pd.DataFrame(index=['RMSE','MAE','MAPE'])

temp = {}
for n in length:
    temp[f"SMA_{n}"] = price.rolling(n, min_periods=1).mean().shift(1).to_numpy().flatten()
    SMA_perf[f'SMA_{n}'] =  calPerformance(y_true.flatten(),temp[f"SMA_{n}"])
print(SMA_perf)

# plot
pred = pd.DataFrame.from_dict(temp).set_index(data.index)
SMA_pred = pd.concat([price, pred], axis=1)
SMA_pred.plot(linewidth=1, figsize=(10,6),title='Stock predction using SMA')
plt.show()

#%%
# EWMA- exponentially weighted moving average
lmbda = [0.15,0.25,0.35]
EWA_perf = pd.DataFrame(index=['RMSE','MAE','MAPE'])
temp = {}
for n in lmbda:
    temp[f"EWA_{n}"] = price.ewm(alpha=n,adjust=False).mean().shift(1).to_numpy().flatten()
    EWA_perf[f'EWA_{n}'] =  calPerformance(y_true.flatten(),temp[f"EWA_{n}"])

print(EWA_perf)

# plot
pred = pd.DataFrame.from_dict(temp).set_index(data.index)
EWA_pred = pd.concat([price, pred], axis=1)
EWA_pred.plot(linewidth=1, figsize=(10,6),title='Stock predction using EWA')
plt.show()

#%%
# Comparison
print('--- Comparison between SMA & EWA -----')
pred_all = pd.concat([SMA_pred.drop(['Index'], axis=1),EWA_pred.drop(['Index'], axis=1)], axis=1) 
pred_all.plot(linewidth=1, figsize=(10,6),title='Stock predction using SMA&EWA')
perf_all = pd.concat([SMA_perf,EWA_perf], axis=1)
print(perf_all)

from sklearn.metrics import mean_absolute_error,mean_squared_error,mean_absolute_percentage_error
SMA_perf0 =pd.DataFrame(columns=['SMA_5','SMA_10','SMA_20'],index=['RMSE','MAE','MAPE'])

SMA_perf0.iloc[0,0:1]=mean_squared_error(y_true[1:,],SMA_pred.iloc[1:,1].to_numpy())**0.5
SMA_perf0.iloc[0,1:2]=mean_squared_error(y_true[1:,],SMA_pred.iloc[1:,2].to_numpy())**0.5
SMA_perf0.iloc[0,2:3]=mean_squared_error(y_true[1:,],SMA_pred.iloc[1:,3].to_numpy())**0.5

SMA_perf0.iloc[1,0:1]=mean_absolute_error(y_true[1:,],SMA_pred.iloc[1:,1].to_numpy())
SMA_perf0.iloc[1,1:2]=mean_absolute_error(y_true[1:,],SMA_pred.iloc[1:,2].to_numpy())
SMA_perf0.iloc[1,2:3]=mean_absolute_error(y_true[1:,],SMA_pred.iloc[1:,3].to_numpy())

SMA_perf0.iloc[2,0:1]=mean_absolute_percentage_error(y_true[1:,],SMA_pred.iloc[1:,1].to_numpy())
SMA_perf0.iloc[2,1:2]=mean_absolute_percentage_error(y_true[1:,],SMA_pred.iloc[1:,2].to_numpy())
SMA_perf0.iloc[2,2:3]=mean_absolute_percentage_error(y_true[1:,],SMA_pred.iloc[1:,3].to_numpy())


EWA_perf0 =pd.DataFrame(columns=['EWA_0.15','EWA_0.25','EWA_0.35'],index=['RMSE','MAE','MAPE'])

EWA_perf0.iloc[0,0:1]=mean_squared_error(y_true[1:,],EWA_pred.iloc[1:,1].to_numpy())**0.5
EWA_perf0.iloc[0,1:2]=mean_squared_error(y_true[1:,],EWA_pred.iloc[1:,2].to_numpy())**0.5
EWA_perf0.iloc[0,2:3]=mean_squared_error(y_true[1:,],EWA_pred.iloc[1:,3].to_numpy())**0.5

EWA_perf0.iloc[1,0:1]=mean_absolute_error(y_true[1:,],EWA_pred.iloc[1:,1].to_numpy())
EWA_perf0.iloc[1,1:2]=mean_absolute_error(y_true[1:,],EWA_pred.iloc[1:,2].to_numpy())
EWA_perf0.iloc[1,2:3]=mean_absolute_error(y_true[1:,],EWA_pred.iloc[1:,3].to_numpy())

EWA_perf0.iloc[2,0:1]=mean_absolute_percentage_error(y_true[1:,],EWA_pred.iloc[1:,1].to_numpy())
EWA_perf0.iloc[2,1:2]=mean_absolute_percentage_error(y_true[1:,],EWA_pred.iloc[1:,2].to_numpy())
EWA_perf0.iloc[2,2:3]=mean_absolute_percentage_error(y_true[1:,],EWA_pred.iloc[1:,3].to_numpy())



