#!/usr/bin/env python
# coding: utf-8

# In[63]:

import pandas as pd 
import numpy as np
#from sklearn.preprocessing import LabelEncoder
from sklearn.model_selection import GridSearchCV
from sklearn.inspection import permutation_importance
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, accuracy_score, roc_curve, roc_auc_score, auc
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier , RandomForestRegressor 
from sklearn import ensemble, preprocessing, metrics
from sklearn.ensemble import AdaBoostClassifier
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

# In[66]:

#### 讀取資料
bank = pd.read_csv("bank.csv",sep=';')
print(bank.head(5))

for i in range(0,np.shape(bank)[1]):
    print(bank.columns[i])
    print(set(bank.iloc[:,i]))
    print("****************************************************************************************************************")

#### 觀察特徵，並去除太多層次的特徵
data=bank.drop(['day','month','job'],axis=1)

# In[72]:
#### 將類別變數轉換成用數字代表
#### 方法一:將所有變數轉換成01的虛擬變數
###Transfer to dummy
# job = pd.get_dummies(data['job'],prefix='job')
#housing = pd.get_dummies(data['housing'],prefix='housing')
#loan = pd.get_dummies(data['loan'],prefix='loan')
#poutcome = pd.get_dummies(data['poutcome'],prefix='poutcome')
data.housing = data.housing.replace('no',0)
data.housing = data.housing.replace('yes',1)
data.loan = data.loan.replace('no',0)
data.loan = data.loan.replace('yes',1)
data.default = data.default.replace('no',0)
data.default = data.default.replace('yes',1)
data.poutcome = data.poutcome.replace('unknown',0)
data.poutcome = data.poutcome.replace('other',0)
data.poutcome = data.poutcome.replace('failure',-1)
data.poutcome = data.poutcome.replace('success',1)

marital = pd.get_dummies(data['marital'],prefix='marital')
education = pd.get_dummies(data['education'],prefix='education')
contact = pd.get_dummies(data['contact'],prefix='contact')

# In[73]:

#Combine the dummy variables with original variable to a new dataframe
bank_dummy = data.join(marital)
bank_dummy = bank_dummy.join(education)
bank_dummy = bank_dummy.join(contact)
del bank_dummy['marital_divorced']
del bank_dummy['education_unknown']
del bank_dummy['contact_unknown']
#bank_dummy = bank_dummy.join(housing)
#bank_dummy = bank_dummy.join(loan)
#bank_dummy = bank_dummy.join(poutcome)

#Remove uncessary variables from the new dataframe
del bank_dummy['marital']
del bank_dummy['education']
del bank_dummy['contact']
#del bank_dummy['default']
#del bank_dummy['housing']
#del bank_dummy['loan']
#del bank_dummy['poutcome']
#Get X and Y

# In[74]:
bank_y = bank_dummy.y
bank_x = bank_dummy
del bank_x['y']

print(bank_x.head(5))
print(bank_x.info())

#Split train/test
bank_train_x,bank_test_x,bank_train_y,bank_test_y= train_test_split(bank_x ,bank_y,test_size=0.25,random_state=3)

# In[79]:
# #### 方法二:將所有變數給定一個數字
# data.info()
# data.columns
# data['month']=LabelEncoder().fit_transform(data['month'])
# data['poutcome']=LabelEncoder().fit_transform(data['poutcome'])
# data['job']=LabelEncoder().fit_transform(data['job'])
# data['contact']=LabelEncoder().fit_transform(data['contact'])
# data['education']=LabelEncoder().fit_transform(data['education'])
# data['marital']=LabelEncoder().fit_transform(data['marital'])
data.housing = data.housing.replace('no',0)
data.housing = data.housing.replace('yes',1)
data.loan = data.loan.replace('no',0)
data.loan = data.loan.replace('yes',1)
data.default = data.default.replace('no',0)
data.default = data.default.replace('yes',1)

data.contact = data.contact.replace('unknown',0)
data.contact = data.contact.replace('telephone',1)
data.contact = data.contact.replace('cellular',2)

data.education = data.education.replace('unknown',0)
data.education = data.education.replace('primary',1)
data.education = data.education.replace('secondary',2)
data.education = data.education.replace('tertiary',3)

data.marital = data.marital.replace('single',0)
data.marital = data.marital.replace('divorced',1)
data.marital = data.marital.replace('married',2)

data.poutcome = data.poutcome.replace('unknown',0)
data.poutcome = data.poutcome.replace('other',0)
data.poutcome = data.poutcome.replace('failure',-1)
data.poutcome = data.poutcome.replace('success',1)

# In[84]:
##### 方法二切分資料
data.head(5)
np.shape(data)
data.info()

bank_x=data.iloc[:,:-1]
bank_y=data.iloc[:,-1:]
#Split train/test
bank_train_x,bank_test_x,bank_train_y,bank_test_y = \
    train_test_split(bank_x ,bank_y,test_size=0.25,random_state=1)
bank_train_x.columns
bank_train_x.head(5)
#%%

for i in range(0,np.shape(data)[1]):
     print(data.columns[i])
     print(set(data.iloc[:,i]))
     print("****************************************************************************************************************")

# In[89]:
## cart挑選參數
#Tunning
dt_candidates = [{'max_depth':[4,6,8], 'min_samples_split':[20,40,60], 
                    'min_samples_leaf':[10,30,50]}]
tunDT = GridSearchCV(estimator = DecisionTreeClassifier(random_state=3), param_grid = dt_candidates, cv = 3)
tunDT.fit(bank_train_x,bank_train_y)
print('\nBest parameters using DT:',tunDT.best_params_)

# In[91]:
# #### 將最佳參數放進模型做訓練
#Build classifier
DT = DecisionTreeClassifier(criterion = 'gini', 
                              min_samples_split= tunDT.best_estimator_.min_samples_split, 
                              min_samples_leaf= tunDT.best_estimator_.min_samples_leaf,
                              max_depth= tunDT.best_estimator_.max_depth)
DT_bank = DT.fit(bank_train_x,bank_train_y)

### 變數重要性
#Get importance of feature with sorting
dt_imp = pd.DataFrame({'Feature':bank_train_x.columns,
                         'Importance':DT_bank.feature_importances_})
print('\nFeature importance:\n',dt_imp.sort_values(by=['Importance'],ascending=False))

# In[93]:
#Predict the train subset
train_pred_DT = DT_bank.predict(bank_train_x)
train_pred_DT = pd.DataFrame(train_pred_DT)
train_pred_DT = train_pred_DT.rename(columns={0: 'x'})
bank_train_y = bank_train_y.reset_index(drop=True)
df=pd.concat([bank_train_y,train_pred_DT],axis=1)
train_conf_DT = pd.crosstab(df['y'], df['x'])

#train_conf_DT = pd.crosstab(bank_train_y.values,train_pred_DT,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (training DT):\n',train_conf_DT)

train_accu_DT = accuracy_score(bank_train_y,train_pred_DT,normalize = True)
train_reca_DT =metrics.recall_score(bank_train_y,train_pred_DT, pos_label='yes', average='binary')
train_prec_DT =metrics.precision_score(bank_train_y,train_pred_DT, pos_label='yes',average='binary')
train_F_DT =metrics.f1_score(bank_train_y,train_pred_DT, pos_label='yes',average='binary')
                                          
print('\nAccuracy using CART:',train_accu_DT)
print('\nRecall using CART:', train_reca_DT)
print('\nPrecision using CART:', train_prec_DT)
print('\nF-measure using CART:', train_F_DT)                                     

# In[94]:

#Predict the test subset
test_pred_DT = DT_bank.predict(bank_test_x)
test_pred_DT = pd.DataFrame(test_pred_DT)
test_pred_DT = test_pred_DT.rename(columns={0: 'x'})
bank_test_y = bank_test_y.reset_index(drop=True)
df=pd.concat([bank_test_y,test_pred_DT],axis=1)
test_conf_DT = pd.crosstab(df['y'], df['x'])

#test_conf_DT = pd.crosstab(bank_test_y.values,test_pred_DT,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (testing DT):\n',test_conf_DT)

test_accu_DT = accuracy_score(bank_test_y,test_pred_DT,normalize = True)
test_reca_DT =metrics.recall_score(bank_test_y,test_pred_DT, pos_label='yes', average='binary')
test_prec_DT =metrics.precision_score(bank_test_y,test_pred_DT, pos_label='yes',average='binary')
test_F_DT =metrics.f1_score(bank_test_y,test_pred_DT, pos_label='yes',average='binary')
                                      
print('\nAccuracy using DT:',test_accu_DT)
print('\nRecall using DT:', test_reca_DT)
print('\nPrecision using DT:', test_prec_DT)
print('\nF-measure using DT:', test_F_DT)                                               

# In[95]:
#bank_test_y.iloc[i].values =="yes"
QQ= (bank_test_y =="yes")
bank_array = np.array(QQ).astype(int)

###ROC curve using CART
bank_y_predprob = DT.fit(bank_train_x, bank_train_y).predict_proba(bank_test_x)
fpr_DT, tpr_DT, thr_DT = roc_curve(bank_array, bank_y_predprob[:,1], pos_label = 1)
roc_auc_DT = auc(fpr_DT, tpr_DT)
print('\nArea under curve = ', roc_auc_DT)
plt.figure()
plt.figure(figsize=(10,10))
plt.plot(fpr_DT, tpr_DT, color='blue',lw=2, label='ROC curve (AUC = %.2f)'%roc_auc_DT) 

##Title and label
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC curve using DT')
plt.legend(loc = 'lower right')
plt.show()

# In[97]:
## RF
#Tunning
rf_candidates = [{'n_estimators':[i for i in range(100,305,25)], 'max_depth':[4,6,8], 'max_features':[8,10,12],
                 'min_samples_split':[20,40,60], 'min_samples_leaf':[10,30,50]}]
tunrf = GridSearchCV(estimator = RandomForestClassifier(random_state=3), param_grid = rf_candidates, cv = 3, n_jobs=-1)
tunrf.fit(bank_train_x,bank_train_y)
print('\nBest parameters using RF:',tunrf.best_params_)

# In[100]:
#Build classifier
rf = RandomForestClassifier(n_estimators = tunrf.best_estimator_.n_estimators,criterion = 'gini',
                            max_depth = tunrf.best_estimator_.max_depth,
                            max_features = tunrf.best_estimator_.max_features, 
                            min_samples_split = tunrf.best_estimator_.min_samples_split,
                            min_samples_leaf = tunrf.best_estimator_.min_samples_leaf,random_state=3)
rf_bank = rf.fit(bank_train_x,bank_train_y)

#Get importance of feature with sorting
rf_imp = pd.DataFrame({'Feature':bank_train_x.columns,
                         'Importance':rf_bank.feature_importances_})
print('\nFeature importance:\n',rf_imp.sort_values(by=['Importance'],ascending=False))

# In[102]:

#Predict the train subset
train_pred_rf = rf_bank.predict(bank_train_x)
train_pred_rf = pd.DataFrame(train_pred_rf)
train_pred_rf = train_pred_rf.rename(columns={0: 'x'})
bank_train_y = bank_train_y.reset_index(drop=True)
df=pd.concat([bank_train_y,train_pred_rf],axis=1)
train_conf_rf = pd.crosstab(df['y'], df['x'])
#train_conf_rf = pd.crosstab(bank_train_y.values,train_pred_rf,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (training RF):\n',train_conf_rf)

train_accu_rf = accuracy_score(bank_train_y,train_pred_rf,normalize = True)
train_reca_rf =metrics.recall_score(bank_train_y,train_pred_rf, pos_label='yes', average='binary')
train_prec_rf =metrics.precision_score(bank_train_y,train_pred_rf, pos_label='yes',average='binary')
train_F_rf =metrics.f1_score(bank_train_y,train_pred_rf, pos_label='yes',average='binary')
          
print('\nAccuracy using RF:',train_accu_rf)
print('\nRecall using RF:', train_reca_rf)
print('\nPrecision using RF:', train_prec_rf)
print('\nF-measure using RF:', train_F_rf)

# In[103]:

#Predict the test subset
test_pred_rf = rf_bank.predict(bank_test_x)
test_pred_rf = pd.DataFrame(test_pred_rf)
test_pred_rf = test_pred_rf.rename(columns={0: 'x'})
bank_test_y = bank_test_y.reset_index(drop=True)
df=pd.concat([bank_test_y,test_pred_rf],axis=1)
test_conf_rf = pd.crosstab(df['y'], df['x'])
#test_conf_rf = pd.crosstab(bank_test_y.values,test_pred_rf,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (testing RF):\n',test_conf_rf)

test_accu_rf = accuracy_score(bank_test_y,test_pred_rf,normalize = True)
test_reca_rf =metrics.recall_score(bank_test_y,test_pred_rf, pos_label='yes', average='binary')
test_prec_rf =metrics.precision_score(bank_test_y,test_pred_rf, pos_label='yes',average='binary')
test_F_rf =metrics.f1_score(bank_test_y,test_pred_rf, pos_label='yes',average='binary')

print('\nAccuracy using RF:',test_accu_rf)
print('\nRecall using RF:', test_reca_rf)
print('\nPrecision using RF:', test_prec_rf)
print('\nF-measure using RF:', test_F_rf)

# In[104]:
QQ= (bank_test_y =="yes")
bank_array = np.array(QQ).astype(int)

###ROC curve using RF
bank_y_predprob = rf.fit(bank_train_x, bank_train_y).predict_proba(bank_test_x)
fpr_rf, tpr_rf, thr_rf = roc_curve(bank_array, bank_y_predprob[:,1], pos_label = 1)
roc_auc_rf = auc(fpr_rf, tpr_rf)
print('\nArea under curve = ', roc_auc_rf)
plt.figure()
plt.figure(figsize=(10,10))
plt.plot(fpr_rf, tpr_rf, color='blue',lw=2, label='ROC curve (AUC = %.2f)'%roc_auc_rf) #lw = linewidth

##Title and label
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC curve using RF')
plt.legend(loc = 'lower right')
plt.show()

# In[106]:
## XGB
# xgb_min_child_weight = [int(x) for x in np.linspace(1, 10, 10)]

xgb_candidates = { 'min_samples_split': list((20,40,60)),
                   'n_estimators':[i for i in range(100,305,25)],
                   'max_depth':list((4,6,8)),
                   'learning_rate':[x for x in np.linspace(0.01, 0.2, 5)]}

tunxgb = GridSearchCV(XGBClassifier(random_state=3),param_grid=xgb_candidates, cv=3, n_jobs=-1)
bank_train_y_num = bank_train_y.replace('yes',1).replace('no',0).astype(int) #新增
tunxgb.fit(bank_train_x, bank_train_y_num) #新增
#(原)grid.fit(bank_train_x, bank_train_y)
tunxgb.cv_results_, tunxgb.best_params_, tunxgb.best_score_
print('\nBest parameters using XGB:',tunxgb.best_params_)

#%%
xgb = XGBClassifier(max_depth=tunxgb.best_params_['max_depth'],
                        learning_rate=tunxgb.best_params_['learning_rate'],
                        n_estimators=tunxgb.best_params_['n_estimators'], 
                        min_samples_split=tunxgb.best_params_['min_samples_split'],random_state=3)
xgb_bank = xgb.fit(bank_train_x, bank_train_y_num) #新增
#(原)xgb.fit(bank_train_x, bank_train_y)
#Get importance of feature with sorting
xgb_imp = pd.DataFrame({'Feature':bank_train_x.columns,'Importance':xgb_bank.feature_importances_})
print('\nFeature importance:\n',xgb_imp.sort_values(by=['Importance'],ascending=False))
    
# In[110]:

#Predict the train subset
train_pred_xgb = xgb_bank.predict(bank_train_x)
train_pred_xgb = pd.Series(train_pred_xgb).replace(1,'yes').replace(0,'no').astype("category") #新增
train_pred_xgb = pd.DataFrame(train_pred_xgb)
train_pred_xgb = train_pred_xgb.rename(columns={0: 'x'})
bank_train_y = bank_train_y.reset_index(drop=True)
df=pd.concat([bank_train_y,train_pred_xgb],axis=1)
train_conf_xgb = pd.crosstab(df['y'], df['x'])
#train_conf_xgb = pd.crosstab(bank_train_y.values,train_pred_xgb,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (training XGB):\n',train_conf_xgb)

train_accu_xgb = accuracy_score(bank_train_y,train_pred_xgb,normalize = True)
train_reca_xgb =metrics.recall_score(bank_train_y,train_pred_xgb, pos_label='yes', average='binary')
train_prec_xgb =metrics.precision_score(bank_train_y,train_pred_xgb, pos_label='yes',average='binary')
train_F_xgb =metrics.f1_score(bank_train_y,train_pred_xgb, pos_label='yes',average='binary')
          
print('\nAccuracy using XGB:',train_accu_xgb)
print('\nRecall using XGB:', train_reca_xgb)
print('\nPrecision using XGB:', train_prec_xgb)
print('\nF-measure using XGB:', train_F_xgb)

# In[111]:

#Predict the test subset
test_pred_xgb = xgb_bank.predict(bank_test_x)
test_pred_xgb = pd.Series(test_pred_xgb).replace(1,'yes').replace(0,'no').astype("category") #新增
test_pred_xgb = pd.DataFrame(test_pred_xgb)
test_pred_xgb = test_pred_xgb.rename(columns={0: 'x'})
bank_test_y = bank_test_y.reset_index(drop=True)
df=pd.concat([bank_test_y,test_pred_xgb],axis=1)
test_conf_xgb = pd.crosstab(df['y'], df['x'])
#test_conf_xgb = pd.crosstab(bank_test_y.values,test_pred_xgb,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (testing XGB):\n',test_conf_xgb)

test_accu_xgb = accuracy_score(bank_test_y,test_pred_xgb,normalize = True)
test_reca_xgb =metrics.recall_score(bank_test_y,test_pred_xgb, pos_label='yes', average='binary')
test_prec_xgb =metrics.precision_score(bank_test_y,test_pred_xgb, pos_label='yes',average='binary')
test_F_xgb =metrics.f1_score(bank_test_y,test_pred_xgb, pos_label='yes',average='binary')

print('\nAccuracy using XGB:',test_accu_xgb)
print('\nRecall using XGB:', test_reca_xgb)
print('\nPrecision using XGB:', test_prec_xgb)
print('\nF-measure using XGB:', test_F_xgb)

# In[112]:
QQ= (bank_test_y =="yes")
bank_array = np.array(QQ).astype(int)

###ROC curve using XGB
#(原)bank_y_predprob = xgb.fit(bank_train_x, bank_train_y).predict_proba(bank_test_x)
bank_y_predprob = xgb.fit(bank_train_x, bank_train_y_num).predict_proba(bank_test_x) #新增
fpr_xgb, tpr_xgb, thr_xgb = roc_curve(bank_array, bank_y_predprob[:,1], pos_label = 1)
roc_auc_xgb = auc(fpr_xgb, tpr_xgb)
print('\nArea under curve = ', roc_auc_xgb)
plt.figure()
plt.figure(figsize=(10,10))
plt.plot(fpr_xgb, tpr_xgb, color='blue',lw=2, label='ROC curve (AUC = %.2f)'%roc_auc_xgb) #lw = linewidth

##Title and label
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC curve using XGB')
plt.legend(loc = 'lower right')
plt.show()

# In[114]:
#Tunning adaboost
adb_candidates = [{'learning_rate':[x for x in np.linspace(0.01, 0.2, 5)],
                   'n_estimators':[i for i in range(100,305,25)]}]
tun_adb = GridSearchCV(estimator = AdaBoostClassifier(random_state=3), param_grid = adb_candidates, cv = 3, n_jobs=-1)
tun_adb.fit(bank_train_x,bank_train_y)

#%%
#Build classifier
adb =AdaBoostClassifier(learning_rate = tun_adb.best_estimator_.learning_rate,
                        n_estimators = tun_adb.best_estimator_.n_estimators,random_state=3)
adb_bank = adb.fit(bank_train_x,bank_train_y)

#Get importance of feature with sorting
adb_imp = pd.DataFrame({'Feature':bank_train_x.columns,'Importance':adb_bank.feature_importances_})
print('\nFeature importance:\n',adb_imp.sort_values(by=['Importance'],ascending=False))
    
# In[118]:

#Predict the train subset
train_pred_adb = adb_bank.predict(bank_train_x)
train_pred_adb = pd.DataFrame(train_pred_adb)
train_pred_adb = train_pred_adb.rename(columns={0: 'x'})
bank_train_y = bank_train_y.reset_index(drop=True)
df=pd.concat([bank_train_y,train_pred_adb],axis=1)
train_conf_adb = pd.crosstab(df['y'], df['x'])
#train_conf_adb = pd.crosstab(bank_train_y.values,train_pred_adb,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (training adaboost):\n',train_conf_adb)

train_accu_adb = accuracy_score(bank_train_y,train_pred_adb,normalize = True)
train_reca_adb =metrics.recall_score(bank_train_y,train_pred_adb, pos_label='yes', average='binary')
train_prec_adb =metrics.precision_score(bank_train_y,train_pred_adb, pos_label='yes',average='binary')
train_F_adb =metrics.f1_score(bank_train_y,train_pred_adb, pos_label='yes',average='binary')
          
print('\nAccuracy using adaboost:',train_accu_adb)
print('\nRecall using adaboost:', train_reca_adb)
print('\nPrecision using adaboost:', train_prec_adb)
print('\nF-measure using adaboost:', train_F_adb)

# In[119]:

#Predict the test subset
test_pred_adb = adb_bank.predict(bank_test_x)
test_pred_adb = pd.DataFrame(test_pred_adb)
test_pred_adb = test_pred_adb.rename(columns={0: 'x'})
bank_test_y = bank_test_y.reset_index(drop=True)
df=pd.concat([bank_test_y,test_pred_adb],axis=1)
test_conf_adb = pd.crosstab(df['y'], df['x'])
#test_conf_adb = pd.crosstab(bank_test_y.values,test_pred_adb,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (testing adaboost):\n',test_conf_adb)

test_accu_adb = accuracy_score(bank_test_y.values,test_pred_adb,normalize = True)
test_reca_adb =metrics.recall_score(bank_test_y,test_pred_adb, pos_label='yes', average='binary')
test_prec_adb =metrics.precision_score(bank_test_y,test_pred_adb, pos_label='yes',average='binary')
test_F_adb =metrics.f1_score(bank_test_y,test_pred_adb, pos_label='yes',average='binary')

print('\nAccuracy using adaboost:',test_accu_adb)
print('\nRecall using adaboost:', test_reca_adb)
print('\nPrecision using adaboost:', test_prec_adb)
print('\nF-measure using adaboost:', test_F_adb)

# In[130]:
#ROC, AUC --> Only accept numeric Y(Dummy variable)
QQ= (bank_test_y =="yes")
bank_array = np.array(QQ).astype(int)

###ROC curve using ADA
bank_y_predprob = adb_bank.fit(bank_train_x, bank_train_y).predict_proba(bank_test_x)
fpr_adb, tpr_adb, thr_adb = roc_curve(bank_array, bank_y_predprob[:,1], pos_label = 1)
roc_auc_adb = auc(fpr_adb, tpr_adb)
print('\nArea under curve = ', roc_auc_adb)
plt.figure()
plt.figure(figsize=(10,10))
plt.plot(fpr_adb, tpr_adb, color='blue',lw=2, label='ROC curve (AUC = %.2f)'%roc_auc_adb) #lw = linewidth

##Title and label
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC curve using ADB')
plt.legend(loc = 'lower right')
plt.show()

# In[129]:
print('\nDecisionTree Area under curve = ', roc_auc_DT)
print('\nRandomForest Area under curve = ', roc_auc_rf)
print('\nxgb Area under curve = ', roc_auc_xgb)
print('\nadaboost Area under curve = ', roc_auc_adb)

plt.figure(figsize=(10,10))
plt.plot(fpr_DT, tpr_DT, color='blue',lw=2, label='ROC curve in dt (AUC = %.2f)'%roc_auc_DT) #lw = linewidth
plt.plot(fpr_rf, tpr_rf, color='red',lw=2, label='ROC curve in rf (AUC = %.2f)'%roc_auc_rf) #lw = linewidth
plt.plot(fpr_xgb, tpr_xgb, color='green',lw=2, label='ROC curve in xgb (AUC = %.2f)'%roc_auc_xgb) #lw = linewidth
plt.plot(fpr_adb, tpr_adb,lw=2, color='black', label='ROC curve in adaboost (AUC = %.2f)'%roc_auc_adb) #lw = linewidth

##Title and label
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC curve')
plt.legend(loc = 'lower right')
plt.show()
