# -*- coding: utf-8 -*-
"""
Created on Fri Apr 15 10:04:24 2022

@author: ku
"""

#%%
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.metrics import mean_squared_error as MSE
from sklearn.metrics import mean_absolute_error as MAE
from sklearn.metrics import mean_absolute_percentage_error as MAPE
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import MinMaxScaler
from sklearn import metrics
from tensorflow import keras 
from tensorflow.keras import optimizers
from tensorflow.keras.wrappers.scikit_learn import KerasRegressor
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout,InputLayer,Activation,BatchNormalization,Reshape
from tensorflow.keras.layers import LSTM ,GRU ,SimpleRNN
from tensorflow.keras.optimizers import Adam,SGD,RMSprop,Adagrad,Adadelta,Adamax,Nadam
from sklearn.metrics import explained_variance_score, mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import  RandomizedSearchCV, train_test_split,TimeSeriesSplit,GridSearchCV
from sklearn.preprocessing import LabelBinarizer
from tensorflow.keras.regularizers import l2
from tensorflow.keras.initializers import RandomNormal
from tensorflow.keras.models import Sequential
from tensorflow.python.keras import backend as K

#%%
#載入DATA
data=pd.read_csv('handysize.csv')
x_all, y_all = data.iloc[0:154,2:], data.iloc[0:154,1 ]
x_train, y_train = data.iloc[0:142,2:], data.iloc[0:142,1 ]
x_test, y_test = data.iloc[142:154,2: ], data.iloc[142:154,1]
y_train_ori,y_test_ori = y_train,y_test
y_train_ori.index = data['Date'].iloc[0:142]
y_test_ori.index = data['Date'].iloc[142:154]
print(x_all.shape,y_all.shape)
print(x_train.shape, y_train.shape, x_test.shape, y_test.shape)

#%%XGB
#優化參數
import xgboost as xgb
from xgboost import plot_importance
xgb_param_grid = {'min_samples_split': list((5,10,15)),'n_estimators':list((40,60,100)),
                   'max_depth':np.linspace(3,6,4,dtype=int),'max_features':list((0.6,0.8,1)),
                   'min_child_weight':np.linspace(5,10,6,dtype=int)}
xgb_grid = GridSearchCV(xgb.XGBRegressor(learning_rate=0.1),
                    param_grid=xgb_param_grid, cv=3)

xgb_grid.fit(x_all, y_all)
xgb_grid.cv_results_, xgb_grid.best_params_, xgb_grid.best_score_

#最佳參數
print(xgb_grid.best_params_)
XGB = xgb_grid.best_estimator_
XGB.fit(x_all, y_all)

#%%XGB變數重要性
feature =x_all.columns
importances = XGB.feature_importances_
feat_imp_dict = dict(zip(feature, importances))
feat_imp = pd.DataFrame.from_dict(feat_imp_dict, orient='index')
feat_imp.rename(columns = {0:'Importance'}, inplace = True)
feat_imp.sort_values(by=['Importance'], ascending=False)

#%%
XGB_train =XGB.predict(x_train)
XGB_test = XGB.predict(x_test)

XGB_RMSEr =np.sqrt(MSE(y_train, XGB_train))
print('training RMSE:',XGB_RMSEr)

XGB_MAEr =MAE(y_train,XGB_train)
print('training MAE:',XGB_MAEr)

XGB_MAPEr =MAPE(y_train,XGB_train)
print('training MAPE:',XGB_MAPEr)

XGB_RMSEs =np.sqrt(MSE(y_test, XGB_test))
print('testing RMSE:',XGB_RMSEs)

XGB_MAEs =MAE(y_test,XGB_test)
print('testing MAE:',XGB_MAEs)

XGB_MAPEs =MAPE(y_test,XGB_test)
print('testing MAPE:',XGB_MAPEs)

perf_XGB=pd.DataFrame()
perf_XGB["XGB_train"] = [XGB_RMSEr,XGB_MAEr,XGB_MAPEr]
perf_XGB["XGB_test"] = [XGB_RMSEs,XGB_MAEs,XGB_MAPEs]
perf_XGB.index=["RMSE","MAE","MAPE"]
perf_XGB

#%%
df_X=data[["BHI_t-1","BSI_t-1","BPI_t-1","Soybeans","Corn","CN_metal production","Australian thermal coal"]]#1Y聯集1.5Y聯集2Y變數 
x_train, y_train = df_X.iloc[0:142,], data.iloc[0:142,1 ]
x_test, y_test = df_X.iloc[142:154,], data.iloc[142:154,1]

X_scaler = MinMaxScaler()
X_train=X_scaler.fit_transform(x_train)
X_test=X_scaler.transform(x_test)

#%%
from sklearn.svm import SVR
parameters = {'kernel':['rbf','sigmoid','poly'], 'C':[50,100,200], 
              'gamma':[pow(5,-2),pow(5,-1),1,5,25],
              'epsilon':[0.05,0.1,0.15],'degree':[1,2]}
svr= SVR()
svr_grid = GridSearchCV(svr, param_grid=parameters,cv=3)
svr_grid.fit(X_train,y_train)
svr_grid.cv_results_, svr_grid.best_params_, svr_grid.best_score_

#最佳參數
print(svr_grid.best_params_)
svr = SVR(kernel=svr_grid.best_params_['kernel'],C=svr_grid.best_params_['C'],epsilon=svr_grid.best_params_['epsilon']
          ,gamma=svr_grid.best_params_['gamma'],degree=svr_grid.best_params_['degree'])
svr.fit(X_train,y_train)

#%%
##training
SVR_train = svr.predict(X_train)
SVR_test = svr.predict(X_test)

SVR_RMSEr=np.sqrt(MSE(y_train, SVR_train))
print('training RMSE:',SVR_RMSEr)

SVR_MAEr=MAE(y_train,SVR_train)
print('training MAE:',SVR_MAEr)

SVR_MAPEr=MAPE(y_train,SVR_train)
print('training MAPE:',SVR_MAPEr)

###testing
SVR_RMSEs=np.sqrt(MSE(y_test, SVR_test))
print('testing RMSE:',SVR_RMSEs)

SVR_MAEs=MAE(y_test,SVR_test)
print('testing MAE:',SVR_MAEs)

SVR_MAPEs=MAPE(y_test,SVR_test)
print('testing MAPE:',SVR_MAPEs)

perf_SVR=pd.DataFrame()
perf_SVR["SVR_train"] = [SVR_RMSEr,SVR_MAEr,SVR_MAPEr]
perf_SVR["SVR_test"] = [SVR_RMSEs,SVR_MAEs,SVR_MAPEs]
perf_SVR.index=["RMSE","MAE","MAPE"]
perf_SVR

#%%LSTM & GRU標準化(直接預測當期)           
y_train, y_test = y_train.values.reshape(-1, 1), y_test.values.reshape(-1, 1)

X_train = X_train.reshape((X_train.shape[0], 1, int(X_train.shape[1])))
X_test = X_test.reshape((X_test.shape[0], 1, int(X_test.shape[1])))
print(X_train.shape, y_train.shape, X_test.shape, y_test.shape)

#%%RNN 標準化(加入Time Step)
feature =df_X.columns
Y = "Handysize"
df = data.iloc[:,1:] 
df_x=data[["BHI_t-1","BSI_t-1","BPI_t-1","Soybeans","Corn","CN_metal production","Australian thermal coal"]]
df_x=X_scaler.fit_transform(df_x)
df_x=pd.DataFrame(df_x,columns=feature)
df.iloc[:,0]
df=pd.concat([df.iloc[:,0],df_x],axis=1)
df.index = data['Date']
window_size = 3 # time step
train = df.iloc[:142,:]   
test = df.iloc[142:154,:]  
  
def buildTrain(train, pastDay, Y, futureDay):
    X_train, Y_train = [], []
    for i in range(train.shape[0]-futureDay-pastDay+1):
        Y_train.append(np.array(train.iloc[i+pastDay:i+pastDay+futureDay][Y]))
        train2 = train.drop([Y], axis=1)
        X_train.append(np.array(train2.iloc[i:i+pastDay]))
    return np.array(X_train), np.array(Y_train)

X_train, y_train = buildTrain(train, window_size, Y, 1)
X_test, y_test = buildTrain(test, window_size, Y, 1)
print(X_train.shape, y_train.shape, X_test.shape, y_test.shape)

#%%
cell=eval('GRU')
es = EarlyStopping(monitor='val_loss', mode='min', patience = 20, verbose=1)

def bulid_model(n_dropout, n_hidden,n_neurons,learning_rate, activation, n_epochs, n_batch_size, select_optimizer):
    
    model = Sequential()
    for layer in range(n_hidden-1):
        model.add(cell(units=n_neurons,input_shape=(X_train.shape[1], X_train.shape[2]),activation=activation,return_sequences=True))
        
    model.add(cell(units=n_neurons,input_shape=(X_train.shape[1], X_train.shape[2]),activation=activation,return_sequences=False))    
    model.add(Dropout(n_dropout))  
    model.add(Dense(1,activation='linear'))

    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='mean_squared_error',optimizer=optimizer)
    
    model.fit(X_train,y_train, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2, callbacks=[es])
    return model

keras=KerasRegressor(bulid_model)
#%%
#GRU調參
params_GRU = {
        "n_dropout":[0.15,0.25,0.35],
        "n_hidden":[2,3,4],
        "n_neurons":[30,60,90],
        "learning_rate":[0.01,0.05,0.1],
        "activation":['relu','softplus','elu'],
        "n_epochs":[100,200],
        "n_batch_size":[6,8,10],
        "select_optimizer":[optimizers.Adam,optimizers.Adagrad,optimizers.RMSprop]
        }

# Randomized Search
RS_cv=RandomizedSearchCV(keras,params_GRU,n_iter=10,cv=3,random_state=516)
RS_cv.fit(X_train,y_train)
print(RS_cv.best_params_)
GRU = RS_cv.best_estimator_

#%%
GRU_train = GRU.predict(X_train)
GRU_test = GRU.predict(X_test)

GRU_RMSEr=np.sqrt(metrics.mean_squared_error(y_train, GRU_train))
print('training RMSE:',GRU_RMSEr)
GRU_MAEr=metrics.mean_absolute_error(y_train, GRU_train)
print('training MAE:',GRU_MAEr)
GRU_MAPEr=metrics.mean_absolute_percentage_error(y_train, GRU_train)
print('training MAPE:',GRU_MAPEr)

GRU_RMSEs=np.sqrt(metrics.mean_squared_error(y_test, GRU_test))
print('training RMSE:',GRU_RMSEs)
GRU_MAEs=metrics.mean_absolute_error(y_test, GRU_test)
print('training MAE:',GRU_MAEs)
GRU_MAPEs=metrics.mean_absolute_percentage_error(y_test, GRU_test)
print('training MAPE:',GRU_MAPEs)

perf_GRU=pd.DataFrame()
perf_GRU["GRU_train"] = [GRU_RMSEr,GRU_MAEr,GRU_MAPEr]
perf_GRU["GRU_test"] = [GRU_RMSEs,GRU_MAEs,GRU_MAPEs]
perf_GRU.index=["RMSE","MAE","MAPE"]
perf_GRU

#%%
cell=eval('LSTM')
es = EarlyStopping(monitor='val_loss', mode='min', patience = 20, verbose=1)
def bulid_model(n_dropout, n_hidden,n_neurons,learning_rate, activation, n_epochs, n_batch_size, select_optimizer):
    
    model = Sequential()
    for i in range(n_hidden-1):
        model.add(cell(units=n_neurons,input_shape=(X_train.shape[1], X_train.shape[2]),activation=activation,return_sequences=True))
        
    model.add(cell(units=n_neurons,input_shape=(X_train.shape[1], X_train.shape[2]),activation=activation,return_sequences=False))    
    model.add(Dropout(n_dropout))  
    model.add(Dense(1,activation='linear'))

    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='mean_squared_error',optimizer=optimizer)
    
    model.fit(X_train,y_train, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2, callbacks=[es])
    return model

keras=KerasRegressor(bulid_model)
#%%
#LSTM調參
from skopt import BayesSearchCV
params_LSTM = {
        "n_dropout":[0.15,0.25,0.35],
        "n_hidden":[2,3,4],
        "n_neurons":[30,60,90],
        "learning_rate":[0.01,0.05, 0.1],
        "activation":['relu','softplus','elu'],
        "n_epochs":[100,300],
        "n_batch_size":[6,8,10],
        "select_optimizer":[optimizers.Adam,optimizers.Adagrad,optimizers.RMSprop]
        }

#Bayes search
BS_cv=BayesSearchCV(keras,params_LSTM,n_iter=10,cv=3,random_state=516) 
BS_cv.fit(X_train,y_train)
print(BS_cv.best_params_)
LSTM = BS_cv.best_estimator_

#%%
LSTM_train = LSTM.predict(X_train)
LSTM_test = LSTM.predict(X_test)

LSTM_RMSEr=np.sqrt(metrics.mean_squared_error(y_train, LSTM_train))
print('training RMSE:',LSTM_RMSEr)
LSTM_MAEr=metrics.mean_absolute_error(y_train, LSTM_train)
print('training MAE:',LSTM_MAEr)
LSTM_MAPEr=metrics.mean_absolute_percentage_error(y_train, LSTM_train)
print('training MAPE:',LSTM_MAPEr)

LSTM_RMSEs=np.sqrt(metrics.mean_squared_error(y_test, LSTM_test))
print('training RMSE:',LSTM_RMSEs)
LSTM_MAEs=metrics.mean_absolute_error(y_test, LSTM_test)
print('training MAE:',LSTM_MAEs)
LSTM_MAPEs=metrics.mean_absolute_percentage_error(y_test, LSTM_test)
print('training MAPE:',LSTM_MAPEs)

perf_LSTM=pd.DataFrame()
perf_LSTM["LSTM_train"] = [LSTM_RMSEr,LSTM_MAEr,LSTM_MAPEr]
perf_LSTM["LSTM_test"] = [LSTM_RMSEs,LSTM_MAEs,LSTM_MAPEs]
perf_LSTM.index=["RMSE","MAE","MAPE"]
perf_LSTM

#%%
performance_train = pd.DataFrame({
    'Training':['RMSE','MAE','MAPE'],
    'XGB':[round(x, 3) for x in (XGB_RMSEr,XGB_MAEr,XGB_MAPEr)],
    'SVR':[round(x, 3) for x in (SVR_RMSEr,SVR_MAEr,SVR_MAPEr)],
    'GRU':[round(x, 3) for x in(GRU_RMSEr,GRU_MAEr,GRU_MAPEr)],
    'LSTM':[round(x, 3) for x in(LSTM_RMSEr,LSTM_MAEr,LSTM_MAPEr)],
})

performance_test = pd.DataFrame({
    'Testing':['RMSE','MAE','MAPE'],
    'XGB':[round(x, 3) for x in (XGB_RMSEs,XGB_MAEs,XGB_MAPEs)],
    'SVR':[round(x, 3) for x in (SVR_RMSEs,SVR_MAEs,SVR_MAPEs)],
    'GRU':[round(x, 3) for x in(GRU_RMSEs,GRU_MAEs,GRU_MAPEs)],
    'LSTM':[round(x, 3) for x in(LSTM_RMSEs,LSTM_MAEs,LSTM_MAPEs)],
})
perf_tr = performance_train.set_index(['Training'],drop=True)
perf_ts = performance_test.set_index(['Testing'],drop=True)

print(perf_tr)
print('\n',perf_ts)

#%%
# plot實際值與預測值
real=y_all
real.index= pd.date_range('2001',periods = 154,freq = '1m')
XGB_pred=pd.concat([pd.DataFrame(XGB_train),pd.DataFrame(XGB_test)])
XGB_pred=XGB_pred.reset_index(drop=True)
XGB_pred.index= pd.date_range('2001',periods = 154,freq = '1m')
SVR_pred=pd.concat([pd.DataFrame(SVR_train),pd.DataFrame(SVR_test)])
SVR_pred=SVR_pred.reset_index(drop=True)
SVR_pred.index= pd.date_range('2001',periods = 154,freq = '1m')
GRU_pred=pd.concat([pd.DataFrame([GRU_train.squeeze()], columns=y_train_ori[window_size:].index, index=['GRU']).T,pd.DataFrame([GRU_test.squeeze()], columns=y_test_ori[window_size:].index, index=['GRU']).T],axis=0)
GRU_pred = GRU_pred.reindex(df.index).fillna(np.nan)
GRU_pred=GRU_pred.reset_index(drop=True)
GRU_pred.index= pd.date_range('2001',periods = 154,freq = '1m')
LSTM_pred=pd.concat([pd.DataFrame([LSTM_train.squeeze()], columns=y_train_ori[window_size:].index, index=['LSTM']).T,pd.DataFrame([LSTM_test.squeeze()], columns=y_test_ori[window_size:].index, index=['LSTM']).T],axis=0)
LSTM_pred = LSTM_pred.reindex(df.index).fillna(np.nan)
LSTM_pred=LSTM_pred.reset_index(drop=True)
LSTM_pred.index= pd.date_range('2001',periods = 154,freq = '1m')

plt.figure(figsize=(20,10))
plt.plot( real, color='black', label="Real",linewidth=1.5)
plt.plot( XGB_pred, color='orange', label="XGB_pred",linewidth=1.5)
plt.plot( SVR_pred, color='blue', label="SVR_pred",linewidth=1.5)
plt.plot( GRU_pred, color='red', label="GRU_pred",linewidth=1.5)
plt.plot( LSTM_pred, color='green', label="LSTM_pred",linewidth=1.5)

plt.legend(loc = 'lower left')
plt.legend(fontsize=15)
plt.xlabel('Date', size=15)
plt.ylabel('Handysize Revenue', size=15)