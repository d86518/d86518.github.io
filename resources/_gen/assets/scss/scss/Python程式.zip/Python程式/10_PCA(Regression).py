#!/usr/bin/env python
# coding: utf-8

# In[1]:
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV, RandomizedSearchCV
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
import xgboost as xgb
from sklearn import preprocessing
from sklearn.svm import SVR
from sklearn import metrics
from tensorflow.keras import optimizers
from tensorflow.keras.wrappers.scikit_learn import KerasRegressor
from tensorflow.keras.callbacks import EarlyStopping
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from sklearn import tree
import warnings
warnings.filterwarnings('ignore')

# In[2]:

##################
### white-wine ###
##################
white = pd.read_csv('winequality-white.csv')
white_y = white['quality']

white_x = white
del white_x['quality']

# In[3]:
scaler=StandardScaler()
scaler.fit(white_x)
white_xx=pd.DataFrame( scaler.transform(white_x) )  #standard normalization
    
pca_w = PCA(n_components=11) #11個主成分
pca_w.fit_transform(white_xx)

eigen_value = pd.DataFrame(np.round(pca_w.explained_variance_), columns=['eigen value']) #變異量,越大越好
print('eigen value:\n',eigen_value)

white_var = np.round(pca_w.explained_variance_ratio_,4)*100 #11個主成分各自解釋了多少%變異
white_var=pd.DataFrame(white_var)
white_var.columns = ['explained var']
print("\n解釋變量(%):\n",white_var)

white_cumvar = np.cumsum(white_var) #11個主成分累計解釋變異
white_cumvar = pd.DataFrame(white_cumvar)
white_cumvar.columns = ['cumulative var']
print("\n累計解釋變量(%):\n",white_cumvar)

plt.plot(white_cumvar)
plt.xlabel('components')
plt.ylabel('cumulative explained variance')
#需要6個主成分就能解釋80%的變異

# In[4]:

#choose components
pca_white = PCA(n_components=6)

#函數新座標
new_x = pd.DataFrame(pca_white.fit_transform(white_xx), columns=['pc1','pc2','pc3','pc4','pc5','pc6'])
print('new x:\n',new_x)

eigen_vector = pd.DataFrame(pca_white.components_.T, columns=['pc1','pc2','pc3','pc4','pc5','pc6'], index=list(white_x.columns)) #vector的權重，vector為資料投影後有最大變異量的投影軸
print('\neigen vector:\n',eigen_vector) 

# reb = pca_red.inverse_transform(pca_red.fit_transform(red_x))
# reb #轉回無雜訊之原始值,重新建構原始值,reb與x誤差越小越好

# In[22]:
#### PCA ####
###Tunning    
###Set the parameter for tunning
tree_param_grid = { 'min_samples_split': list((20,30,40)),
                   'min_samples_leaf':list((10,20,30)),'max_depth':list((4,6,8))}
grid = GridSearchCV(DecisionTreeRegressor(random_state=516),param_grid=tree_param_grid, cv=3)
grid.fit(new_x, white_y)
grid.cv_results_, grid.best_params_, grid.best_score_
print(grid.best_params_)

# In[23]:

#建立迴歸模型
DT=DecisionTreeRegressor(max_depth=grid.best_params_['max_depth'], 
                         min_samples_leaf=grid.best_params_['min_samples_leaf'], 
                         min_samples_split=grid.best_params_['min_samples_split'],random_state=516)
DT.fit(new_x,white_y)
tree.plot_tree(DT)
print(tree.export_text(DT))
pred_DT = DT.predict(new_x)

#pca in regression
perf_DT = pd.DataFrame()
perf_DT['RMSE']=[np.sqrt(metrics.mean_squared_error(white_y, pred_DT))]
perf_DT['MAE']=[metrics.mean_absolute_error(white_y, pred_DT)]
perf_DT['MAPE']=[metrics.mean_absolute_percentage_error(white_y, pred_DT)]
print("\n Performance in regression by using PCA+CART\n")
print(perf_DT)

# In[9]:
#### PCA ####
#RF調參
rf_param_grid = { 'min_samples_split': list((20,30,40)),
                   'min_samples_leaf':list((10,20,30)),
                   'n_estimators':list((80,100,150)),
                   'max_depth':list((4,6,8))}
grid = GridSearchCV(RandomForestRegressor(random_state=516),param_grid=rf_param_grid, cv=3)
grid.fit(new_x, white_y)
grid.cv_results_, grid.best_params_, grid.best_score_
print(grid.best_params_)

# In[10]:
#建立迴歸模型
RF=RandomForestRegressor(max_depth=grid.best_params_['max_depth'], 
                         min_samples_leaf=grid.best_params_['min_samples_leaf'],
                         n_estimators=grid.best_params_['n_estimators'],  
                         min_samples_split=grid.best_params_['min_samples_split'],
                         random_state=516)
RF.fit(new_x,white_y)
pred_RF = RF.predict(new_x)

#pca in regression
perf_RF = pd.DataFrame()
perf_RF['RMSE']=[np.sqrt(metrics.mean_squared_error(white_y, pred_RF))]
perf_RF['MAE']=[metrics.mean_absolute_error(white_y, pred_RF)]
perf_RF['MAPE']=[metrics.mean_absolute_percentage_error(white_y, pred_RF)]
print("\n Performance in regression by using PCA+RF\n")
print(perf_RF)

# In[13]:
#### PCA ####
###XGB調最佳參數
xgb_param_grid = { 'min_samples_split': list((20,30,40)),
                   'n_estimators':list((80,120,150)),
                   'max_depth':list((4,6,8)),'learning_rate':[0.01,0.05,0.1]}
grid = GridSearchCV(xgb.XGBRegressor(random_state=516, verbosity = 0),
                    param_grid=xgb_param_grid, cv=3)
grid.fit(new_x, white_y)
grid.cv_results_, grid.best_params_, grid.best_score_
print(grid.best_params_)

# In[14]:
#建立迴歸模型
XGB = xgb.XGBRegressor(max_depth=grid.best_params_['max_depth'], 
                       n_estimators=grid.best_params_['n_estimators'], 
                       learning_rate=grid.best_params_['learning_rate'],
                       min_samples_split=grid.best_params_['min_samples_split'],
                       random_state=516)
#learning_rate=0.05, max_depth=4, min_samples_split=20, n_estimators=120
XGB.fit(new_x, white_y)
pred_XGB = XGB.predict(new_x)

#pca in regression
perf_XGB = pd.DataFrame()
perf_XGB['RMSE']=[np.sqrt(metrics.mean_squared_error(white_y, pred_XGB))]
perf_XGB['MAE']=[metrics.mean_absolute_error(white_y, pred_XGB)]
perf_XGB['MAPE']=[metrics.mean_absolute_percentage_error(white_y, pred_XGB)]
print("\n Performance in regression by using PCA+XGB\n")
print(perf_XGB)

# In[17]:
#### PCA ####
#SVR調參
parameters = {'kernel':['rbf'], 'C':[10,50,100],'epsilon':[0.1,0.15,0.2],
              'gamma':[10**-2, 10**-1, 1,10,100]}
grid = GridSearchCV(SVR(),param_grid=parameters, cv=3)

grid.fit(new_x,white_y)
grid.cv_results_, grid.best_params_, grid.best_score_
print(grid.best_params_)

# In[18]:
#建立迴歸模型
svr = SVR(kernel=grid.best_params_['kernel'],
          C=grid.best_params_['C'],epsilon=grid.best_params_['epsilon'],
          gamma=grid.best_params_['gamma'])
#C=50, epsilon=0.1, gamma=125, kernel='rbf'
svr.fit(new_x,white_y)
pred_SVR = svr.predict(new_x)

#pca in regression
perf_SVR = pd.DataFrame()
perf_SVR['RMSE']=[np.sqrt(metrics.mean_squared_error(white_y, pred_SVR))]
perf_SVR['MAE']=[metrics.mean_absolute_error(white_y, pred_SVR)]
perf_SVR['MAPE']=[metrics.mean_absolute_percentage_error(white_y, pred_SVR)]
print("\n Performance in regression by using PCA+SVR\n")
print(perf_SVR)

# In[22]:
#### PCA ####
# DNN建立模型
#X_scaler = preprocessing.MinMaxScaler()
#X_scaler.fit_transform(new_x) #why??
#new_xx = X_scaler.fit_transform(new_x)
new_xx = np.array(new_x)

es = EarlyStopping(monitor='val_loss', mode='min', patience = 20, verbose=1)
def bulid_model(first_hidden_neuron=6,n_dropout=0.15,n_hidden=1,n_neurons=4,
                learning_rate=1e-2, activation='relu',
                kernel_initializer='uniform',n_epochs=10,
                n_batch_size=10,select_optimizer=optimizers.Adamax):#
    
    model = Sequential()
    model.add(Dense(first_hidden_neuron,input_dim=len(new_xx[0]),activation=activation,kernel_initializer=kernel_initializer))
    for layer in range(n_hidden):
        model.add(Dense(n_neurons,activation=activation,kernel_initializer=kernel_initializer))
        model.add(Dropout(n_dropout))
        
    model.add(Dense(1,activation='linear'))
    
    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='mean_squared_error',optimizer=optimizer)
    
    model.fit(new_xx,white_y, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2, callbacks=[es])
    return model

#%%
keras=KerasRegressor(bulid_model)
#DNN調參
params_DNN = {
        "n_dropout":[0.15,0.25,0.35],
        "n_hidden":[1,2,3],
        'first_hidden_neuron':[4,8,16],
        "n_neurons":[4,8,16],
        "learning_rate":[0.01,0.005,0.001],
        "activation":['relu','softplus','elu'], #softplus vs. softmax #'sigmoid'
        "n_epochs":[100],
        "n_batch_size":[32, 64, 128],
        "select_optimizer":[optimizers.Adam,optimizers.SGD,optimizers.RMSprop]
        }

# Randomized Search
RS_cv=RandomizedSearchCV(keras,params_DNN,n_iter=10,cv=3,random_state=516)
RS_cv.fit(new_xx,white_y)
print(RS_cv.best_params_)

# In[23]]:
#{'select_optimizer': <class 'tensorflow.python.keras.optimizer_v2.gradient_descent.SGD'>, 'n_neurons': 16, 'n_hidden': 1, 'n_epochs': 100, 'n_dropout': 0.15, 'n_batch_size': 4, 'learning_rate': 0.005, 'first_hidden_neuron': 4, 'activation': 'relu'}
#建立迴歸模型
DNN = RS_cv.best_estimator_
pred_DNN = DNN.predict(new_xx)

#pca in regression
perf_DNN = pd.DataFrame()
perf_DNN['RMSE']=[np.sqrt(metrics.mean_squared_error(white_y, pred_DNN))]
perf_DNN['MAE']=[metrics.mean_absolute_error(white_y, pred_DNN)]
perf_DNN['MAPE']=[metrics.mean_absolute_percentage_error(white_y, pred_DNN)]
print("\n Performance in regression by using PCA+DNN\n")
print(perf_DNN)

# In[26]:
## 統整
#pca
perf_r = pd.DataFrame()
perf_r['DT'] = perf_DT.iloc[0]
perf_r["RF"] = perf_RF.iloc[0]
perf_r["XGB"] = perf_XGB.iloc[0]
perf_r["SVR"] = perf_SVR.iloc[0]
perf_r["DNN"] = perf_DNN.iloc[0]
#perf_r.index = ["RMSE","MAE","MAPE"] 
print("\n Performance of PCA\n")
print(round(perf_r,4))

