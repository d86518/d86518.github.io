#####Normality test (?`?A???˩w)
data(iris)
attach(iris)
hist(Sepal.Length, breaks=seq(4.0, 8.0, 0.05))
hist(Sepal.Length, breaks=seq(4.0, 8.0, 0.25), prob=TRUE)
qqnorm(Sepal.Length, xlab="Z-score", ylab="Sepal.Length")
qqline(Sepal.Length, col="red")
shapiro.test(Sepal.Length)
curve(dnorm(x, mean(Sepal.Length), sd(Sepal.Length)), 4.0, 8.0, col="red") #simulation

qqplot(Sepal.Length, Sepal.Width) #judging the similarity of probability distribution 
qqplot(Petal.Length, Petal.Width)

#install.packages("nortest")
library(nortest)
ad.test(Sepal.Width)
sf.test(Sepal.Width)
cvm.test(Sepal.Width)
shapiro.test(Sepal.Width)

#####Chi-square/Proportion tests (?d???˩w/?????˩w)
male= c(Bush=315, Perot=152, Clinton=337)
female= c(Bush=346, Perot=126, Clinton=571)
rbind(male, female)
chisq.test(rbind(male, female))
citizen= c(sum(male), sum(female))

bush= c(male[1], female[1])
prop.test(bush, citizen, alternative="greater")
prop.test(bush, citizen, alternative="less")

perot= c(male[2], female[2])
prop.test(perot, citizen, alternative="two.sided")
prop.test(perot, citizen, alternative="greater")

clinton= c(male[3], female[3])
prop.test(clinton, citizen, alternative="less")
prop.test(clinton, citizen, alternative="greater")

#####gender_size dataset (?ʧO???ƶ?)
gender_size <-read.csv("gender_size.csv")
attach(gender_size)
gender_size[,4]<- as.factor(gender_size[,4])

Male=subset(gender_size, Gender=="male")
Female=subset(gender_size, Gender=="female")

var.test(Male$Height, Female$Height)
t.test(Male$Height, Female$Height, var.equal=FALSE)

var.test(Male$Weight, Female$Weight)
t.test(Male$Weight, Female$Weight, var.equal=FALSE)

var.test(Male$Waist, Female$Waist)
t.test(Male$Waist, Female$Waist, var.equal=FALSE)

#One sample/ Two sample T-test
attach(gender_size)
sexht=split(Height, Gender)
sexwt=split(Weight, Gender)
sexws=split(Waist, Gender)

t.test(sexht$male, mu=170, alternative="greater")
t.test(sexht$male, mu=175, alternative="greater", conf.level=0.95)

t.test(sexwt$female, mu=50, alternative="less")
t.test(sexwt$female, mu=50, alternative="two.sided", conf.level=0.95)

#f.test(sexws$male, sexws$female)
var.test(sexws$male, sexws$female)
t.test(sexws$male, sexws$female, alternative="greater", var.equal=FALSE)
t.test(sexws$male, sexws$female, alternative="less", var.equal=FALSE)

#install.packages("car")
library(car)
attach(gender_size)
MR2<- lm(Waist~Height+Weight, gender_size[, -4])
summary(MR2)
vif(MR2) #Conlinearity test (threshold=10)

#####descriptive analytics (bank dataset)
bank=read.csv("bank.csv", header=TRUE, sep=";", stringsAsFactors = T)
summary(bank)
attach(bank)
hist(age)

char=0 ###discretize variables (???????ܼ?)
for (i in 1:nrow(bank))
{
  if (bank[i,1]<35) char[i]="young"
  else if(bank[i,1]<50) char[i]="middle"
  else char[i]="old"
}
bank$agg=factor(char)
summary(bank$agg)

###age vs. loan (?~???P?ɶU?O?_????)
young_y=sum((bank$agg=="young") & (bank$loan=="yes"))
young_n=sum((bank$agg=="young") & (bank$loan=="no"))
middle_y=sum((bank$agg=="middle") & (bank$loan=="yes"))
middle_n=sum((bank$agg=="middle") & (bank$loan=="no"))
old_y=sum((bank$agg=="old") & (bank$loan=="yes"))
old_n=sum((bank$agg=="old") & (bank$loan=="no"))

age_y<-c(young=young_y, middle=middle_y, old=old_y)
age_n<-c(young=young_n, middle=middle_n, old=old_n)
rbind(age_y, age_n)
chisq.test(rbind(age_y, age_n))

###education level vs. loan (?Ш|?����P?ɶU?O?_????)
pri_y=sum((bank$education=="primary") & (bank$loan=="yes"))
pri_n=sum((bank$education=="primary") & (bank$loan=="no"))
sec_y=sum((bank$education=="secondary") & (bank$loan=="yes"))
sec_n=sum((bank$education=="secondary") & (bank$loan=="no"))
ter_y=sum((bank$education=="tertiary") & (bank$loan=="yes"))
ter_n=sum((bank$education=="tertiary") & (bank$loan=="no"))
#unk_y=sum((bank$education=="unknown") & (bank$loan=="yes"))
#unk_n=sum((bank$education=="unknown") & (bank$loan=="no"))
table(bank$loan,bank$education) #******
edu_y<-c(primary=pri_y, secondary=sec_y, tertiary=ter_y)
edu_n<-c(primary=pri_n, secondary=sec_n, tertiary=ter_n)
rbind(edu_y, edu_n)

chisq.test(rbind(edu_y, edu_n))
chisq.test(table(bank$loan,bank$education)) #********

primary_y=sum((bank$education=="primary") & (bank$loan=="yes"))
tertiary_y=sum((bank$education=="tertiary") & (bank$loan=="yes"))
x=c(primary_y, tertiary_y)
y=c(sum((bank$education=="primary")), sum((bank$education=="tertiary")))
prop.test(x, y)

primary_y=sum((bank$education=="primary") & (bank$loan=="yes"))
secondary_y=sum((bank$education=="secondary") & (bank$loan=="yes"))
x=c(primary_y, secondary_y)
y=c(sum((bank$education=="primary")), sum((bank$education=="secondary")))
prop.test(x, y)

###marital status vs. loan (?B?ê??A?P?ɶU?O?_????)
mar_y<-c(single=nrow(subset(bank, marital=="single" & loan=="yes")), married=nrow(subset(bank, marital=="married" & loan=="yes")), divorced=nrow(subset(bank, marital=="divorced" & loan=="yes")))
mar_n<-c(single=nrow(subset(bank, marital=="single" & loan=="no")), married=nrow(subset(bank, marital=="married" & loan=="no")), divorced=nrow(subset(bank, marital=="divorced" & loan=="no")))
rbind(mar_y, mar_n)
chisq.test(rbind(mar_y, mar_n))
table(bank$loan,bank$marital)
chisq.test(table(bank$loan,bank$marital))

###married & unmarried vs. loan (?w?B?O?_?P?ɶU????)
married_y=sum((bank$marital=="married") & (bank$loan=="yes"))
unmarried_y=sum((bank$marital!="married") & (bank$loan=="yes"))
x=c(married_y, unmarried_y)
y=c(sum((bank$marital=="married")), sum((bank$marital!="married")))
prop.test(x, y)

###single & nonsingle vs. loan (?樭?O?_?P?ɶU????)
married_y=sum((bank$marital=="single") & (bank$loan=="yes"))
unmarried_y=sum((bank$marital!="single") & (bank$loan=="yes"))
x=c(married_y, unmarried_y)
y=c(sum((bank$marital=="single")), sum((bank$marital!="single")))
prop.test(x, y)

###married & divorced vs. loan (?w?B???B?P?ɶU????)
married_y=sum((bank$marital=="married") & (bank$loan=="yes"))
divorced_y=sum((bank$marital=="divorced") & (bank$loan=="yes"))
x=c(married_y, divorced_y)
y=c(sum((bank$marital=="married")), sum((bank$marital=="divorced")))
prop.test(x, y)

###Single & non-single vs. balance(?樭?O?_?P?b???l?B)
single=subset(bank, marital=="single")
nonsingle=subset(bank, marital!="single")
var.test(single$balance, nonsingle$balance)
t.test(single$balance, nonsingle$balance, var.equal=FALSE)

###loan & non-loan vs. balance(?U?ڬO?_?P?b???l?B)
loan=subset(bank, loan=="yes")
nonloan=subset(bank, loan=="no")
var.test(loan$balance, nonloan$balance)
t.test(loan$balance, nonloan$balance, var.equal=FALSE)

###yes & no vs. duration(?ѥ[???ʬO?_?P???Ӯɶ?)
yes=subset(bank, y=="yes")
no=subset(bank, y=="no")
var.test(yes$duration, no$duration)
t.test(yes$duration, no$duration, var.equal=FALSE)

yes=subset(bank, y=="yes")
no=subset(bank, y=="no")
var.test(yes$age, no$age)
t.test(yes$age, no$age, var.equal=FALSE)

#####One-way anova/ Two-way anova
fit1<- lm(balance~marital)
summary(fit1)

ano1<- aov(balance~marital, data= bank)
summary(ano1)

fit2<-lm(balance~marital+agg, data= bank)
summary(fit2)

fit4<-lm(balance~marital+age, data= bank)
summary(fit4)

ano2 <- aov(balance~marital+agg, data= bank)
summary(ano2)

fit3<-lm(balance~marital+agg+marital*agg, data= bank)
summary(fit3)

ano3 <- aov(balance~marital+agg+marital*agg, data= bank)
summary(ano3)

interaction.plot(bank$agg, marital, balance, col=1:3)
interaction.plot(bank$age, marital, balance, col=1:3)

################################################
single=subset(bank, marital=="single")
married=subset(bank, marital=="married")
var.test(single$balance, married$balance)
t.test(single$balance, married$balance, var.equal=FALSE)

single_blan=bank[marital=="single", "balance"]
married_blan=bank[marital=="married", "balance"]
divorced_blan=bank[marital=="divorced", "balance"]

blan.survey <- data.frame( blan= c(single_blan, married_blan, divorced_blan), mar= factor(c(rep("1", length(single_blan)), rep("2", length(married_blan)), rep("3", length(divorced_blan)))) )
summary( lm(blan~mar, data= blan.survey) )
summary( aov(blan~mar, data= blan.survey) )
