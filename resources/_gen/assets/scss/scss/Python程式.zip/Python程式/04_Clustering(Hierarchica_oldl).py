# -*- coding: utf-8 -*-
"""
Created on Wed Sep  8 16:19:59 2021

@author: a0978
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import AgglomerativeClustering
from sklearn.metrics import davies_bouldin_score

def optimal_HC(df,kmax,method='single'):
    perf = []
    for k in range(2,kmax+1):
        HC = AgglomerativeClustering(n_clusters=k,affinity='euclidean',linkage=method)
        HC.fit_predict(X)
        curr_db = davies_bouldin_score(df, HC.labels_)
        perf.append(curr_db)
    print('the optimal k which has the lowerest DBindex score')
    print(np.argmin(perf)+2)
    return perf



#%%
iris = pd.read_csv('iris.csv')
X = iris.iloc[:,0:4]
y = iris['Species']


#%%
single = optimal_HC(X,10,'single')
#%%
hc1 = AgglomerativeClustering(n_clusters=2,affinity='euclidean',linkage='single',compute_distances=True)
single = hc1.fit_predict(X)

# Result
single_result = pd.concat([X, pd.DataFrame(single+1,columns=['Cluster'])], axis=1)
print(single_result)

# Cluster Means
print('\nCluster Centers:')
single_center = pd.DataFrame()
for k in set(single_result.Cluster):
    single_center[f'k={k}']=single_result[single_result['Cluster']==k].mean(axis=0)[0:4]
print(single_center)

# Plot
plt.scatter(X.iloc[:,2],X.iloc[:,3],c=single)
plt.title('HC using Single Link');plt.xlabel('Petal.Length');plt.ylabel('Petal.Width')
plt.show()

# Confusion Matrix
cmatrix_hc1 = pd.crosstab(y, single+1, colnames=['Cluster Num.'])
print("\nConfusion matrix:")
print(cmatrix_hc1)


#%%
complete = optimal_HC(X,10,'complete')
#%%
hc2 = AgglomerativeClustering(n_clusters=3,affinity='euclidean',linkage='complete')
complete = hc2.fit_predict(X)

complete_result = pd.concat([X, pd.DataFrame(complete+1,columns=['Cluster'])], axis=1)
print(complete_result)

# Cluster Means
print('\nCluster Centers:')
complete_center = pd.DataFrame()
for k in set(complete_result.Cluster):
    complete_center[f'k={k}']=complete_result[complete_result['Cluster']==k].mean(axis=0)[0:4]
print(complete_center)

# Plot
plt.scatter(X.iloc[:,2],X.iloc[:,3],c=complete)
plt.title('HC using Complete Link');plt.xlabel('Petal.Length');plt.ylabel('Petal.Width')
plt.show()

# Confusion Matrix
cmatrix_hc2 = pd.crosstab(y, complete+1, colnames=['Cluster Num.'])
print("\nConfusion matrix:")
print(cmatrix_hc2)




#%%
average = optimal_HC(X,10,'average')
#%%
hc3 = AgglomerativeClustering(n_clusters=2,affinity='euclidean',linkage='average')
average = hc3.fit_predict(X)

average_result = pd.concat([X, pd.DataFrame(average+1,columns=['Cluster'])], axis=1)
print(average_result)

# Cluster Means
print('\nCluster Centers:')
average_center = pd.DataFrame()
for k in set(average_result.Cluster):
    average_center[f'k={k}']=average_result[average_result['Cluster']==k].mean(axis=0)[0:4]
print(average_center)

# Plot
plt.scatter(X.iloc[:,2],X.iloc[:,3],c=average)
plt.title('HC using Group Average');plt.xlabel('Petal.Length');plt.ylabel('Petal.Width')
plt.show()

# Confusion Matrix
cmatrix_hc3 = pd.crosstab(y, average+1, colnames=['Cluster Num.'])
print("\nConfusion matrix:")
print(cmatrix_hc3)



#%%
ward = optimal_HC(X,10,'ward')
#%%
hc4 = AgglomerativeClustering(n_clusters=2,affinity='euclidean',linkage='ward')
ward = hc4.fit_predict(X)

ward_result = pd.concat([X, pd.DataFrame(ward+1,columns=['Cluster'])], axis=1)
print(ward_result)

# Cluster Means
print('\nCluster Centers:')
ward_center = pd.DataFrame()
for k in set(ward_result.Cluster):
    ward_center[f'k={k}']=ward_result[ward_result['Cluster']==k].mean(axis=0)[0:4]
print(ward_center)

# Plot
plt.scatter(X.iloc[:,2],X.iloc[:,3],c=ward)
plt.title("HC using Ward's Method");plt.xlabel('Petal.Length');plt.ylabel('Petal.Width')
plt.show()

# Confusion Matrix
cmatrix_hc4 = pd.crosstab(y, ward+1, colnames=['Cluster Num.'])
print("\nConfusion matrix:")
print(cmatrix_hc4)