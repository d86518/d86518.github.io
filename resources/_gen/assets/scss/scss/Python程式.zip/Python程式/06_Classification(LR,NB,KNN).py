#!/usr/bin/env python
# coding: utf-8

# In[1]:
import itertools
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import statsmodels.api as sm
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn import metrics
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import train_test_split , KFold , cross_val_score
from sklearn.metrics import accuracy_score , confusion_matrix , mean_squared_error
import csv
from sklearn.naive_bayes import GaussianNB 
from sklearn import preprocessing, linear_model
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import label_binarize
from sklearn.feature_selection import f_regression
from sklearn.metrics import confusion_matrix, accuracy_score, roc_curve, roc_auc_score, auc
from sklearn.preprocessing import LabelEncoder
import warnings
from sklearn.metrics import roc_curve
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score

# In[125]:
###############
#####Cancer####
###############
#Load cancer data
cancer = pd.read_csv('breast_cancer.csv')
cancer_data=cancer
del cancer['id']
print(cancer['Bare.Nuclei'].describe())

mask=cancer['Bare.Nuclei']!=9999 #利用遮罩篩選資料
cancer=cancer.loc[mask]
cancer_y = cancer['Class']
cancer_x=cancer
del cancer_x['Class']
print(cancer_y.shape)  #確認筆數

#切測試與訓練
class_names = ["benign","malignant"]
cancer_train_x, cancer_test_x, cancer_train_y, cancer_test_y = train_test_split(cancer_x, cancer_y, test_size = 0.25,random_state=0)

#%%
################
###white-wine###
################
#load white wine data
white = pd.read_csv('winequality-white.csv')
white_y = pd.DataFrame(white['quality'])
white_x = white
del white_x['quality']

#quality分群
conditions = [
    white_y['quality'] > 6,
    white_y['quality'] == 6,
    white_y['quality'] < 6
]
choices = ['good','medium','bad']

white_y['rating'] = np.select(conditions, choices, default = 'no rating')
del white_y['quality']

#Split train/test
white_train_x,white_test_x,white_train_y,white_test_y = train_test_split(white_x,white_y,test_size=0.25,random_state=0)

#%%
#############
###Titanic###
#############
#load titanic data
titanicdata=pd.read_csv("titanic.csv")

#Remove Na and outlier
df = titanicdata.dropna(subset=['fare'])  #Remove NaN for 'fare' feature
df = df[df.age != 9999 ]   #Remove 9999 for age
df = df[df.fare != 9999]   #Remove 9999 for fare
df.shape

#Select Variable
titan = df[['gender','age','class','fare','survival']]#Select Vatiable
#Encoding the target
titan.survival = titan.survival.replace(0,'No')
titan.survival = titan.survival.replace(1,'Yes')
titan.survival= pd.Series(titan.survival.astype("category"))
print(titan)

#Get X and Y
titan_y = titan.survival
titan_x = titan
del titan_x['survival']

#Split train-test subset
titan_train_x,titan_test_x,titan_train_y,titan_test_y= train_test_split(titan_x,titan_y,test_size=0.3,random_state=1)

#%%
###############################################################################

#Select Variable
titan = df[['gender','age','class','fare','survival']]#Select Vatiable
#Encoding the target
titan.survival = titan.survival.replace(0,'No')
titan.survival = titan.survival.replace(1,'Yes')
titan.survival= pd.Series(titan.survival.astype("category"))

titan.gender = titan.gender.replace(0,'male')
titan.gender = titan.gender.replace(1,'female')
titan=pd.get_dummies(titan,columns=['gender'])
titan=pd.get_dummies(titan,columns=['class'])
del titan['gender_male']
del titan['class_1']

#titan.gender= pd.Series(titan.gender.astype("category"))
print(titan)

#Get X and Y
titan_y_dum = titan.survival
titan_x_dum = titan
del titan_x_dum['survival']

#Split train-test subset
titan_train_x_dum,titan_test_x_dum,titan_train_y_dum,titan_test_y_dum = train_test_split(titan_x_dum,titan_y_dum,test_size=0.3,random_state=1)

# In[3]:
###################
#####Cancer KNN####
###################
#選擇K的個數
range = np.arange(3, 10, 2)
accur = []
table=[]

for i in range:
    knn = KNeighborsClassifier(n_neighbors = i)
    knn_clf = knn.fit(cancer_train_x, cancer_train_y)
    test_pred = knn_clf.predict(cancer_train_x)
    accu = metrics.accuracy_score(cancer_train_y, test_pred)
    accur.append(accu)
table=pd.Series(accur) 
print("選擇K的個數\n\n",table)

best_k = range[accur.index(max(accur))]
print("最佳K的個數:",best_k)
plt.scatter(range, accur)
plt.show()

#%%
#建立分類器
knn = KNeighborsClassifier(n_neighbors = best_k)
knn_cancer = knn.fit(cancer_train_x, cancer_train_y)

#訓練集預測
train_pred = knn_cancer.predict(cancer_train_x)
train_conf=pd.crosstab(cancer_train_y, train_pred,rownames=['real'],colnames=['pred'])
print(train_conf)

train_accu_cancerKNN= metrics.accuracy_score(cancer_train_y, train_pred)
train_reca_cancerKNN =metrics.recall_score(cancer_train_y, train_pred, pos_label='malignant', average='binary')
train_prec_cancerKNN =metrics.precision_score(cancer_train_y, train_pred, pos_label='malignant',average='binary')
train_F_cancerKNN =metrics.f1_score(cancer_train_y, train_pred, pos_label='malignant',average='binary')

#train_reca_cancerKNN = train_conf.values[1,1]/(train_conf.values[1,1]+train_conf.values[1,0])
#train_prec_cancerKNN = train_conf.values[1,1]/(train_conf.values[1,1]+train_conf.values[0,1])
#train_F_cancerKNN = (2*train_reca_cancerKNN*train_prec_cancerKNN)/(train_reca_cancerKNN+train_prec_cancerKNN)
                                               
print('\nTrain Accuracy using KNN:',train_accu_cancerKNN)
print('\nTrain Recall using KNN:', train_reca_cancerKNN)
print('\nTrain Precision using KNN:', train_prec_cancerKNN)
print('\nTrain F-measure using KNN:', train_F_cancerKNN)  

#%%
#測試集預測
test_pred = knn_cancer.predict(cancer_test_x)
test_conf=pd.crosstab(cancer_test_y, test_pred,rownames=['real'],colnames=['pred'])
print(test_conf)

test_accu_cancerKNN= metrics.accuracy_score(cancer_test_y, test_pred)
test_reca_cancerKNN =metrics.recall_score(cancer_test_y, test_pred, pos_label='malignant', average='binary')
test_prec_cancerKNN =metrics.precision_score(cancer_test_y, test_pred, pos_label='malignant',average='binary')
test_F_cancerKNN =metrics.f1_score(cancer_test_y, test_pred, pos_label='malignant',average='binary')

#test_reca_cancerKNN = test_conf.values[1,1]/(test_conf.values[1,1]+test_conf.values[1,0])
#test_prec_cancerKNN = test_conf.values[1,1]/(test_conf.values[1,1]+test_conf.values[0,1])
#test_F_cancerKNN = (2*test_reca_cancerKNN*test_prec_cancerKNN)/(test_reca_cancerKNN+test_prec_cancerKNN)
                                               
print('\nTest Accuracy using KNN:',test_accu_cancerKNN)
print('\nTest Recall using KNN:', test_reca_cancerKNN)
print('\nTest Precision using KNN:', test_prec_cancerKNN)
print('\nTest F-measure using KNN:', test_F_cancerKNN) 

# In[7]:

##################
#####Cancer NB####
##################

#Build NB classifier
nbc = GaussianNB()
nbc_cancer = nbc.fit(cancer_train_x, cancer_train_y)

#Predict the train subset
train_pred = nbc_cancer.predict(cancer_train_x)
train_conf = pd.crosstab(cancer_train_y,train_pred,rownames=['real'],colnames=['pred'])
print('\nTrain Confusion Matrix for Cancer:\n',train_conf)

train_accu_cancerNB = accuracy_score(cancer_train_y, train_pred)
train_reca_cancerNB =metrics.recall_score(cancer_train_y, train_pred, pos_label='malignant', average='binary')
train_prec_cancerNB =metrics.precision_score(cancer_train_y, train_pred, pos_label='malignant',average='binary')
train_F_cancerNB =metrics.f1_score(cancer_train_y, train_pred, pos_label='malignant',average='binary')
                                    
print('\nTrain Accuracy using NB:',train_accu_cancerNB)
print('\nTrain Recall using NB:', train_reca_cancerNB)
print('\nTrain Precision using NB:', train_prec_cancerNB)
print('\nTrain F-measure using NB:', train_F_cancerNB)  

#%%
#Predict the test subset & probability
test_pred = nbc_cancer.predict(cancer_test_x)
cancer_predprob = nbc_cancer.predict_proba(cancer_test_x)
cancer_predprobdf = pd.DataFrame(cancer_predprob)

cancer_tableprob = pd.DataFrame({'Real':cancer_test_y, 'Pred':test_pred,
                'Pred prob 1':cancer_predprobdf[0].values,
                'Pred prob 2':cancer_predprobdf[1].values,}, index = cancer_test_y.index)
cancer_tableprob.columns = ['Real', 'Pred', 'Pb-benign', 'Pb-malignant']
cancer_tableprob = cancer_tableprob[['Real', 'Pred', 'Pb-benign', 'Pb-malignant']]
cancer_tableprob

#Compare true and predict Y
test_conf = pd.crosstab(cancer_test_y,test_pred,rownames=['real'],colnames=['pred'])
print('\nTest Confusion Matrix for Cancer:\n',test_conf)

test_accu_cancerNB= accuracy_score(cancer_test_y, test_pred)
test_reca_cancerNB =metrics.recall_score(cancer_test_y, test_pred, pos_label='malignant', average='binary')
test_prec_cancerNB =metrics.precision_score(cancer_test_y, test_pred, pos_label='malignant',average='binary')
test_F_cancerNB =metrics.f1_score(cancer_test_y, test_pred, pos_label='malignant',average='binary')
                               
print('\nTest Accuracy using NB:',test_accu_cancerNB)
print('\nTest Recall using NB:', test_reca_cancerNB)
print('\nTest Precision using NB:', test_prec_cancerNB)
print('\nTest F-measure using NB:', test_F_cancerNB) 

#%%
####################
###white-wine KNN###
####################

#選擇K的個數
range = np.arange(3, 10, 2)
accur = []
table=[]

for i in range:
    knn = KNeighborsClassifier(n_neighbors = i)
    knn_clf = knn.fit(white_train_x, white_train_y)
    test_pred = knn_clf.predict(white_train_x)
    accu = metrics.accuracy_score(white_train_y, test_pred)
    accur.append(accu)
table=pd.Series(accur) 
print("選擇K的個數\n\n",table)

best_k = range[accur.index(max(accur))]
print("最佳K的個數:",best_k)
plt.scatter(range, accur)
plt.show()

#%%
#建立分類器
knn = KNeighborsClassifier(n_neighbors = best_k)
knn_white = knn.fit(white_train_x, white_train_y)

#訓練集預測
train_pred = knn_white.predict(white_train_x)
#Confusion Matrix & Accuracy
train_conf = pd.crosstab(white_train_y["rating"],train_pred,rownames=['real'],colnames=['pred'])
print("\nTrain Confusion matrix：\n",train_conf)
     
train_accu_whiteKNN= metrics.accuracy_score(white_train_y, train_pred)
train_accubad_whiteKNN = train_conf.values[0,0]/(train_conf.values[0,0]+train_conf.values[0,1]+train_conf.values[0,2])
train_accugood_whiteKNN = train_conf.values[1,1]/(train_conf.values[1,0]+train_conf.values[1,1]+train_conf.values[1,2])
train_accumedium_whiteKNN = train_conf.values[2,2]/(train_conf.values[2,0]+train_conf.values[2,1]+train_conf.values[2,2])

print('\nTrain Accuracy using KNN:',train_accu_whiteKNN)
print('\nTrain Accuracy for bad using KNN:', train_accubad_whiteKNN)
print('\nTrain Accuracy for good using KNN:', train_accugood_whiteKNN)
print('\nTrain Accuracy for medium using KNN:', train_accumedium_whiteKNN) 

#%%
#測試集預測
test_pred = knn_white.predict(white_test_x)
#Confusion Matrix & Accuracy
test_conf = pd.crosstab(white_test_y["rating"],test_pred,rownames=['real'],colnames=['pred'])
print("\nTest Confusion matrix：\n",test_conf)

test_accu_whiteKNN= metrics.accuracy_score(white_test_y, test_pred)
test_accubad_whiteKNN = test_conf.values[0,0]/(test_conf.values[0,0]+test_conf.values[0,1]+test_conf.values[0,2])
test_accugood_whiteKNN = test_conf.values[1,1]/(test_conf.values[1,0]+test_conf.values[1,1]+test_conf.values[1,2])
test_accumedium_whiteKNN = test_conf.values[2,2]/(test_conf.values[2,0]+test_conf.values[2,1]+test_conf.values[2,2])

print('\nTest Accuracy using KNN:',test_accu_whiteKNN)
print('\nTest Accuracy for bad using KNN:', test_accubad_whiteKNN)
print('\nTest Accuracy for good using KNN:', test_accugood_whiteKNN)
print('\nTest Accuracy for medium using KNN:', test_accumedium_whiteKNN) 

#%%
###################
###white-wine LR###
###################
#multi-nominal logit
#Built model
#white_train_xtrans = sm.add_constant(white_train_x, prepend = False)

mnlogit = sm.MNLogit(white_train_y, white_train_x)
mnlogit_fit = mnlogit.fit()
print (mnlogit_fit.summary())

#Predict the train subset
train_pred = mnlogit_fit.predict(white_train_x)

#Real Training
train_pred = pd.DataFrame(np.asarray(train_pred).argmax(axis=1), columns = ['Pred'],                          index = white_train_x.index)
train_pred['Pred'][train_pred['Pred'] == 0] = 'bad'
train_pred['Pred'][train_pred['Pred'] == 1] = 'good'
train_pred['Pred'][train_pred['Pred'] == 2] = 'medium'

#Confusion Matrix & Accuracy
train_conf = pd.crosstab(white_train_y["rating"],train_pred['Pred'],rownames=['real'],colnames=['pred'])
print("\nTrain Confusion matrix：\n",train_conf)

train_accu_whiteLR= metrics.accuracy_score(white_train_y, train_pred)
train_accubad_whiteLR = train_conf.values[0,0]/(train_conf.values[0,0]+train_conf.values[0,1]+train_conf.values[0,2])
train_accugood_whiteLR = train_conf.values[1,1]/(train_conf.values[1,0]+train_conf.values[1,1]+train_conf.values[1,2])
train_accumedium_whiteLR = train_conf.values[2,2]/(train_conf.values[2,0]+train_conf.values[2,1]+train_conf.values[2,2])

print('\nTrain Accuracy using LR:',train_accu_whiteLR)
print('\nTrain Accuracy for bad using LR:', train_accubad_whiteLR)
print('\nTrain Accuracy for good using LR:', train_accugood_whiteLR)
print('\nTrain Accuracy for medium using LR:', train_accumedium_whiteLR) 

#%%
#Predict Testing
#white_test_xtrans = sm.add_constant(white_test_x, prepend = False)
test_pred = mnlogit_fit.predict(white_test_x)

#Real Testing
test_pred = pd.DataFrame(np.asarray(test_pred).argmax(axis=1), columns = ['Pred'],                          index = white_test_x.index)
test_pred['Pred'][test_pred['Pred'] == 0] = 'bad'
test_pred['Pred'][test_pred['Pred'] == 1] = 'good'
test_pred['Pred'][test_pred['Pred'] == 2] = 'medium'

#Confusion Matrix & Accuracy
test_conf = pd.crosstab(white_test_y["rating"],test_pred['Pred'],rownames=['real'],colnames=['pred'])
print("\nTest Confusion matrix：\n",test_conf)

test_accu_whiteLR= metrics.accuracy_score(white_test_y, test_pred)
test_accubad_whiteLR = test_conf.values[0,0]/(test_conf.values[0,0]+test_conf.values[0,1]+test_conf.values[0,2])
test_accugood_whiteLR = test_conf.values[1,1]/(test_conf.values[1,0]+test_conf.values[1,1]+test_conf.values[1,2])
test_accumedium_whiteLR = test_conf.values[2,2]/(test_conf.values[2,0]+test_conf.values[2,1]+test_conf.values[2,2])

print('\nTest Accuracy using LR:',test_accu_whiteLR)
print('\nTest Accuracy for bad using LR:', test_accubad_whiteLR)
print('\nTest Accuracy for good using LR:', test_accugood_whiteLR)
print('\nTest Accuracy for medium using LR:', test_accumedium_whiteLR)  

# In[135]:
####################
###Titanic_dum LR###
####################

#Built model
le_titan=preprocessing.LabelEncoder()
titan_train_ytrans=le_titan.fit_transform(titan_train_y_dum).astype(float)
titan_train_xtrans=sm.add_constant(titan_train_x_dum).astype(float)
sm_model = sm.Logit(titan_train_ytrans,titan_train_xtrans).fit(disp=0)
print(sm_model.summary())

#Predict the train subset
train_pred = sm_model.predict(titan_train_xtrans)
(train_pred >= 0.5).astype(int)

#Real Training
train_pred = pd.DataFrame((train_pred >= 0.5).astype(int), columns = ['Pred'],                          index = titan_train_x_dum.index)
train_pred['Pred'][train_pred['Pred'] == 0] = 'No'
train_pred['Pred'][train_pred['Pred'] == 1] = 'Yes'

#Confusion Matrix & Accuracy
train_conf = pd.crosstab(titan_train_y_dum,train_pred['Pred'],rownames=['real'],colnames=['pred'])
print("\nTrain Confusion matrix：\n",train_conf)

train_accu_titandumLR= metrics.accuracy_score(titan_train_y_dum, train_pred)
train_reca_titandumLR = metrics.recall_score(titan_train_y_dum, train_pred, pos_label='Yes')
train_prec_titandumLR = metrics.precision_score(titan_train_y_dum, train_pred, pos_label='Yes')
train_F_titandumLR = metrics.f1_score(titan_train_y_dum, train_pred, pos_label='Yes')
                                     
print('\nTrain Accuracy using LR:',train_accu_titandumLR)
print('\nTrain Recall using LR:', train_reca_titandumLR)
print('\nTrain Precision using LR:', train_prec_titandumLR)
print('\nTrain F-measure using LR:', train_F_titandumLR)

#%%
#Predict Testing
titan_test_xtrans=sm.add_constant(titan_test_x_dum).astype(float)
test_pred = sm_model.predict(sm.add_constant(titan_test_xtrans))

#Real Testing
test_pred = pd.DataFrame((test_pred >= 0.5).astype(int), columns = ['Pred'],                          index = titan_test_x_dum.index)                               
test_pred['Pred'][test_pred['Pred'] == 0] = 'No'
test_pred['Pred'][test_pred['Pred'] == 1] = 'Yes'

#Confusion Matrix & Accuracy
test_conf = pd.crosstab(titan_test_y_dum,test_pred['Pred'],rownames=['real'],colnames=['pred'])
print("\nTest Confusion matrix：\n",test_conf)

test_accu_titandumLR= metrics.accuracy_score(titan_test_y_dum, test_pred['Pred'])
test_reca_titandumLR = metrics.recall_score(titan_test_y_dum, test_pred, pos_label='Yes')
test_prec_titandumLR = metrics.precision_score(titan_test_y_dum, test_pred, pos_label='Yes')
test_F_titandumLR = metrics.f1_score(titan_test_y_dum, test_pred, pos_label='Yes')
                                                                          
print('\nTest Accuracy using LR:',test_accu_titandumLR)
print('\nTest Recall using LR:', test_reca_titandumLR)
print('\nTest Precision using LR:', test_prec_titandumLR)
print('\nTest F-measure using LR:', test_F_titandumLR)

#Predict one or two data (gender 0 is male, 1 is female)
titan_two = sm_model.predict([[1,34,15,1,0,1],[1,17,7,0,0,1]]) #same as 1053,893 data = No, No
print('\n\nPredict prob(2 data) = ', titan_two)

titan_two = pd.DataFrame((titan_two >= 0.5).astype(int), columns = ['Pred'])                                
titan_two['Pred'][titan_two['Pred'] == 0] = 'No'
titan_two['Pred'][titan_two['Pred'] == 1] = 'Yes'
print('\n\nPredict result(2 data) = ', titan_two.values, '\nReal = ', [titan_y[1052],titan_y[892]])

titan_comparegender = sm_model.predict([[1,20,50,0,0,0],[1,20,50,1,0,0]])
print('\nPredict Gender Probability:\n',titan_comparegender)#比較男女生存機率 男:0.64470829 女:0.94068643

titan_compareage = sm_model.predict([[1,1,10,0,0,1],[1,30,10,0,0,1]]) 
print('\nPredict Age Probability:\n',titan_compareage)#比較年紀生存機率 1歲:0.21889641 30歲:0.09774608

titan_compareclass = sm_model.predict([[1,20,50,1,0,0],[1,20,30,1,1,0],[1,20,10,1,0,1]]) 
print('\nPredict Class Probability:\n', titan_compareclass)#比較艙等生存機率 class1:0.94068643 class2:0.76598916 class3:0.56785842


# In[134]:
####################
###Titanic_dum NB###
####################

#Build classifier
nbc = GaussianNB()
nbc_titan=nbc.fit(titan_train_x_dum, titan_train_y_dum)

#Confusion matrix Get accuracy for train
train_pred = nbc_titan.predict(titan_train_x_dum)
train_conf = pd.crosstab(titan_train_y_dum,train_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (training):\n',train_conf)

train_accu_titandumNB= metrics.accuracy_score(titan_train_y_dum, train_pred)
train_reca_titandumNB = metrics.recall_score(titan_train_y_dum, train_pred, pos_label='Yes')
train_prec_titandumNB = metrics.precision_score(titan_train_y_dum, train_pred, pos_label='Yes')
train_F_titandumNB = metrics.f1_score(titan_train_y_dum, train_pred, pos_label='Yes')
                  
print('\nTrain Accuracy using NB:',train_accu_titandumNB)
print('\nTrain Recall using NB:', train_reca_titandumNB)
print('\nTrain Precision using NB:', train_prec_titandumNB)
print('\nTrain F-measure using NB:', train_F_titandumNB)

#Compare true and predict Y
test_pred = nbc_titan.predict(titan_test_x_dum)
test_conf = pd.crosstab(titan_test_y_dum,test_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (testing):\n',test_conf)

test_accu_titandumNB= metrics.accuracy_score(titan_test_y_dum, test_pred)
test_reca_titandumNB = metrics.recall_score(titan_test_y_dum, test_pred, pos_label='Yes')
test_prec_titandumNB = metrics.precision_score(titan_test_y_dum, test_pred, pos_label='Yes')
test_F_titandumNB = metrics.f1_score(titan_test_y_dum, test_pred, pos_label='Yes')
                                              
print('\nTest Accuracy using NB:',test_accu_titandumNB)
print('\nTest Recall using NB:', test_reca_titandumNB)
print('\nTest Precision using NB:', test_prec_titandumNB)
print('\nTest F-measure using NB:', test_F_titandumNB)

#Predict probability
titan_prob = nbc_titan.predict_proba(titan_test_x_dum)
titan_probdf = pd.DataFrame(titan_prob)
titan_tableprob = pd.DataFrame({'Real':titan_test_y_dum,'Pred':test_pred,
                'Pred prob 1':titan_probdf[0].values,
                'Pred prob 2':titan_probdf[1].values}, index = titan_test_y_dum.index)
titan_tableprob.columns = ['Real', 'Pred', 'Pb of No', 'Pb of Yes']
titan_tableprob = titan_tableprob[['Real', 'Pred', 'Pb of No', 'Pb of Yes']]
titan_tableprob

#Predict one or two data (gender 0 is male, 1 is female)
titan_two = nbc_titan.predict([[34,15,1,0,1],[17,7,0,0,1]]) #same as 1053,893 data = No, No
print('\n\nPredict result(2 data) = ', titan_two, '\nReal = ', [titan_y[1052],titan_y[892]])
titan_two_prob = nbc_titan.predict_proba([[34,15,1,0,1],[17,7,0,0,1]]) #same as 859,716 data = No, No
print('\nPredict Probability:\n',titan_two_prob[:,1])

titan_comparegender_prob = nbc_titan.predict_proba([[20,50,0,0,0],[20,50,1,0,0]])
print('\nPredict Gender Probability:\n',titan_comparegender_prob[:,1])#比較男女生存機率 男:0.21598547 女:0.82148839

titan_compareage_prob = nbc_titan.predict_proba([[1,50,0,0,0],[30,50,0,0,0]]) 
print('\nPredict Age Probability:\n',titan_compareage_prob[:,1])#比較年紀生存機率 1歲:0.27292994 30歲:0.20784336

titan_compareclass_prob = nbc_titan.predict_proba([[20,50,1,0,0],[20,30,1,1,0],[20,10,1,0,1]]) 
print('\nPredict Class Probability:\n', titan_compareclass_prob[:,1])#比較艙等生存機率 class1:0.82148839 class2:0.81725449 class3:0.42838239


# In[130]:

################
###Titanic LR###
################

#Built model
le_titan=preprocessing.LabelEncoder()
titan_train_ytrans=le_titan.fit_transform(titan_train_y).astype(float)
titan_train_xtrans=sm.add_constant(titan_train_x).astype(float)
sm_model = sm.Logit(titan_train_ytrans,titan_train_xtrans).fit(disp=0)
print(sm_model.summary())

#Predict the train subset
train_pred = sm_model.predict(titan_train_xtrans)
(train_pred >= 0.5).astype(int)

#Real Training
train_pred = pd.DataFrame((train_pred >= 0.5).astype(int), columns = ['Pred'],                          index = titan_train_x.index)
train_pred['Pred'][train_pred['Pred'] == 0] = 'No'
train_pred['Pred'][train_pred['Pred'] == 1] = 'Yes'
train_result = pd.concat([train_pred, titan_train_y], axis = 1)
print("\nTrain Result Compare：\n", train_result)

#Confusion Matrix & Accuracy
train_conf = pd.crosstab(titan_train_y,train_pred['Pred'],rownames=['real'],colnames=['pred'])
print("\nTrain Confusion matrix：\n",train_conf)

train_accu_titanLR= metrics.accuracy_score(titan_train_y, train_pred)
train_reca_titanLR = train_conf.values[1,1]/(train_conf.values[1,1]+train_conf.values[1,0])
train_prec_titanLR = train_conf.values[1,1]/(train_conf.values[1,1]+train_conf.values[0,1])
train_F_titanLR = (2*train_reca_titanLR*train_prec_titanLR)/(train_reca_titanLR+train_prec_titanLR)
                                               
print('\nTrain Accuracy using LR:',train_accu_titanLR)
print('\nTrain Recall using LR:', train_reca_titanLR)
print('\nTrain Precision using LR:', train_prec_titanLR)
print('\nTrain F-measure using LR:', train_F_titanLR)

#%%
#Predict Testing
titan_test_xtrans=sm.add_constant(titan_test_x).astype(float)
test_pred = sm_model.predict(sm.add_constant(titan_test_xtrans))

#Real Testing
test_pred = pd.DataFrame((test_pred >= 0.5).astype(int), columns = ['Pred'],                          index = titan_test_x.index)
                                
test_pred['Pred'][test_pred['Pred'] == 0] = 'No'
test_pred['Pred'][test_pred['Pred'] == 1] = 'Yes'

test_result = pd.concat([test_pred, titan_test_y], axis = 1)
print("\nTest Result Compare：\n", test_result)

#Confusion Matrix & Accuracy
test_conf = pd.crosstab(titan_test_y,test_pred['Pred'],rownames=['real'],colnames=['pred'])
print("\nTest Confusion matrix：\n",test_conf)

test_accu_titanLR= metrics.accuracy_score(titan_test_y, test_pred['Pred'])
test_reca_titanLR = test_conf.values[1,1]/(test_conf.values[1,1]+test_conf.values[1,0])
test_prec_titanLR = test_conf.values[1,1]/(test_conf.values[1,1]+test_conf.values[0,1])
test_F_titanLR = (2*test_reca_titanLR*test_prec_titanLR)/(test_reca_titanLR+test_prec_titanLR)
                                               
print('\nTest Accuracy using LR:',test_accu_titanLR)
print('\nTest Recall using LR:', test_reca_titanLR)
print('\nTest Precision using LR:', test_prec_titanLR)
print('\nTest F-measure using LR:', test_F_titanLR)

#Predict one or two data (gender 0 is male, 1 is female)
titan_two = sm_model.predict([[1,1,34,3,15],[1,0,17,3,7]]) #same as 1053,893 data = No, No
print('\n\nPredict prob(2 data) = ', titan_two)
titan_two = pd.DataFrame((titan_two >= 0.5).astype(int), columns = ['Pred'])                                
titan_two['Pred'][titan_two['Pred'] == 0] = 'No'
titan_two['Pred'][titan_two['Pred'] == 1] = 'Yes'
print('\n\nPredict result(2 data) = ', titan_two.values, '\nReal = ', [titan_y[1052],titan_y[892]])

titan_comparegender = sm_model.predict([[1,0,20,3,15],[1,1,20,3,15]])
print('\nPredict Gender Probability:\n',titan_comparegender)#比較男女生存機率 男:0.12631304 女:0.55332278

titan_compareage = sm_model.predict([[1,0,1,2,25],[1,0,30,2,25]]) 
print('\nPredict Age Probability:\n',titan_compareage)#比較年紀生存機率 1歲:0.20870743 30歲:0.09531559

titan_compareclass = sm_model.predict([[1,1,20,1,50],[1,1,20,2,20],[1,1,20,3,10]])
print('\nPredict Class Probability:\n', titan_compareclass)#比較艙等生存機率 class1:0.93029603 class2:0.80260809 class3:0.55332278

#%%
################
###Titanic NB###
################

#Build classifier
nbc = GaussianNB()
nbc_titan=nbc.fit(titan_train_x, titan_train_y)

#Confusion matrix Get accuracy for train
train_pred = nbc_titan.predict(titan_train_x)
train_conf = pd.crosstab(titan_train_y,train_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (training):\n',train_conf)

train_accu_titanNB= metrics.accuracy_score(titan_train_y, train_pred)
train_reca_titanNB = metrics.recall_score(titan_train_y, train_pred, pos_label='Yes')
train_prec_titanNB = metrics.precision_score(titan_train_y, train_pred, pos_label='Yes')
train_F_titanNB = metrics.f1_score(titan_train_y, train_pred, pos_label='Yes')
                                  
print('\nTrain Accuracy using NB:',train_accu_titanNB)
print('\nTrain Recall using NB:', train_reca_titanNB)
print('\nTrain Precision using NB:', train_prec_titanNB)
print('\nTrain F-measure using NB:', train_F_titanNB)

#%%
#Compare true and predict Y
test_pred = nbc_titan.predict(titan_test_x)
test_conf = pd.crosstab(titan_test_y,test_pred,rownames=['real'],colnames=['pred'])
print('\nConfusion Matrix (testing):\n',test_conf)

test_accu_titanNB= metrics.accuracy_score(titan_test_y, test_pred)
test_reca_titanNB = metrics.recall_score(titan_test_y, test_pred, pos_label='Yes')
test_prec_titanNB = metrics.precision_score(titan_test_y, test_pred, pos_label='Yes')
test_F_titanNB = metrics.f1_score(titan_test_y, test_pred, pos_label='Yes')            
                            
print('\nTest Accuracy using NB:',test_accu_titanNB)
print('\nTest Recall using NB:', test_reca_titanNB)
print('\nTest Precision using NB:', test_prec_titanNB)
print('\nTest F-measure using NB:', test_F_titanNB)

#Predict probability
titan_prob = nbc_titan.predict_proba(titan_test_x)
titan_probdf = pd.DataFrame(titan_prob)
titan_tableprob = pd.DataFrame({'Real':titan_test_y,'Pred':test_pred,
                'Pred prob 1':titan_probdf[0].values,
                'Pred prob 2':titan_probdf[1].values}, index = titan_test_y.index)
titan_tableprob.columns = ['Real', 'Pred', 'Pb of No', 'Pb of Yes']
titan_tableprob = titan_tableprob[['Real', 'Pred', 'Pb of No', 'Pb of Yes']]
titan_tableprob

#Predict one or two data (gender 0 is male, 1 is female)
titan_two = nbc_titan.predict([[1,34,3,15],[0,17,3,7]]) #same as 1053,893 data = No, No
print('\n\nPredict result(2 data) = ', titan_two, '\nReal = ', [titan_y[1052],titan_y[892]])

titan_two_prob = nbc_titan.predict_proba([[1,34,3,15],[0,17,3,7]]) #same as 1053,893 data = No, No
print('\nPredict Probability:\n',titan_two_prob[:,1])

titan_comparegender_prob = nbc_titan.predict_proba([[0,20,3,15.0],[1,20,3,15.0]])
print('\nPredict Gender Probability:\n',titan_comparegender_prob[:,1])#比較男女生存機率 男:0.06462161 女:0.53575841

titan_compareage_prob = nbc_titan.predict_proba([[0,1,3,15.0],[0,30,3,15.0]]) 
print('\nPredict Age Probability:\n',titan_compareage_prob[:,1])#比較年紀生存機率 1歲:0.0860385  30歲:0.06462161

titan_compareclass_prob = nbc_titan.predict_proba([[1,20,1,50.0],[1,20,2,25.0],[1,20,3,15.0]])
print('\nPredict Class Probability:\n', titan_compareclass_prob[:,1])#比較艙等生存機率 class1:0.91914821 class2:0.65303035 class3:0.43399278

