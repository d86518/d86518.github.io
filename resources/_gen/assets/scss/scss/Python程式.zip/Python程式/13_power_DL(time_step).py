import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
import seaborn as sns
import time, random
import  permetrics

from sklearn.preprocessing import MinMaxScaler
#from bayes_opt import BayesianOptimization
from pandas import DataFrame,concat
#from permetrics import RegressionMetric
#from permetrics.regression import Metrics
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import mean_squared_error as MSE
from sklearn.metrics import mean_absolute_error as MAE
from sklearn.metrics import mean_absolute_percentage_error as MAPE
from hyperopt import  hp,fmin, tpe, STATUS_OK, Trials
random.seed(516)
from sklearn.metrics import explained_variance_score, mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import  RandomizedSearchCV, train_test_split,TimeSeriesSplit,GridSearchCV
from sklearn.preprocessing import LabelBinarizer
from tensorflow.keras.regularizers import l2
from tensorflow.keras.initializers import RandomNormal
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, Dropout,BatchNormalization, LSTM ,GRU ,SimpleRNN
from tensorflow.keras.optimizers import Adam,SGD,RMSprop,Adagrad,Adadelta,Adamax,Nadam
from tensorflow.python.keras import backend as K
from tensorflow import keras 
from tensorflow.keras import optimizers
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,Dropout,InputLayer,Reshape
from tensorflow.keras.wrappers.scikit_learn import KerasRegressor
from tensorflow.keras.callbacks import EarlyStopping
from skopt import BayesSearchCV
from skopt.space import Real, Categorical, Integer
import joblib

#%%    
def buildTrain(train, pastDay, Y, futureDay):
    X_train, Y_train = [], []
    for i in range(train.shape[0]-futureDay-pastDay+1):
        Y_train.append(np.array(train.iloc[i+pastDay:i+pastDay+futureDay][Y]))
        train2 = train.drop([Y], axis=1)
        X_train.append(np.array(train2.iloc[i:i+pastDay]))
    return np.array(X_train), np.array(Y_train)

import matplotlib.dates as mdates
from datetime import datetime, timedelta

#%% Load data
power = pd.read_csv('electricity.csv')
power=power.drop(['Time','WEP','MEP'],axis=1)
df = power[['IPI','AverageTemp','ExportOrderAmount','ImportTotalValue_MachineryandEquipment','Humidity','SeasonIndex',
               'PM10','TotalDemand']]
print("資料特徵數(x+y)："+str(len(list(power.columns))))#+str(len(list(power.columns)))
print(power.columns)

x = df.iloc[0:289, 0:7]
y = df.iloc[0:289, 7]

train_x = df.iloc[0:264, 0:7]
train_y = df.iloc[0:264, 7]
test_x = df.iloc[264:288, 0:7]
test_y = df.iloc[264:288, 7].reset_index(drop=True)
print(train_x.shape, train_y.shape, test_x.shape, test_y.shape)

#%%
y = 'TotalDemand'
window_size = 3 # time step

X_scaler = MinMaxScaler()
train_xx = X_scaler.fit_transform(train_x)
test_xx = X_scaler.transform(test_x)

train_xx = pd.DataFrame(train_xx)
test_xx = pd.DataFrame(test_xx)
train_y = pd.DataFrame(train_y)
test_y = pd.DataFrame(test_y)

train = pd.concat([train_xx , train_y],axis=1, ignore_index=True)
test = pd.concat([test_xx , test_y],axis=1, ignore_index=True)
train = train.rename(columns={7:'TotalDemand'})
test = test.rename(columns={7:'TotalDemand'})

# window_size dataset(Many to one)
X_train, y_train = buildTrain(train, window_size, y, 1)
X_test, y_test = buildTrain(test, window_size, y, 1)
print(X_train.shape, y_train.shape, X_test.shape, y_test.shape)

#%%
DL_params ={
            "n_dropout":np.arange(0.2,0.4,0.1),
            "n_hidden":np.arange(2,4,1),
            "n_neurons":np.arange(30,60,10),
            "learning_rate":np.arange(0.05,0.2,0.05),
            "activation":['relu', 'softplus', 'elu'],#'softmax', 'tanh', 'sigmoid'
            "n_epochs":[150],
            "n_batch_size":np.arange(8,16,8),
            "select_optimizer":Categorical([optimizers.Adam, optimizers.RMSprop, optimizers.Adagrad])#,optimizers.experimental.Adagrad,optimizers.RMSprop
            }

#%%
model_types = ['SimpleRNN', 'GRU', 'LSTM']
best_models = {}
results = {}
predictions = {}

for model_type in model_types:
    print(f"Training {model_type} model...")
    # Choose the cell type based on the loop iteration
    if model_type == 'SimpleRNN':
        cell = SimpleRNN
    elif model_type == 'GRU':
        cell = GRU
    elif model_type == 'LSTM':
        cell = LSTM

    es = EarlyStopping(monitor='val_loss', mode='min', patience = 20, verbose=1)
    
    def bulid_model(n_dropout, n_hidden,n_neurons,learning_rate, activation, n_epochs, n_batch_size, select_optimizer):
            
        model = Sequential()
        for i in range(n_hidden):
            model.add(cell(units=n_neurons,input_shape=(X_train.shape[1], X_train.shape[2]),activation=activation,return_sequences=True))
            model.add(Dropout(n_dropout)) 
            
        model.add(cell(units=n_neurons,input_shape=(X_train.shape[1], X_train.shape[2]),activation=activation,return_sequences=False))    
        model.add(Dense(1,activation='linear'))
        
        optimizer = select_optimizer(lr=learning_rate)
        model.compile(loss='mean_squared_error',optimizer=optimizer)
        
        model.fit(X_train,y_train, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2, callbacks=[es])
        return model
    
    keras=KerasRegressor(bulid_model)

#RandomizedSearch
    #RS_cv=RandomizedSearchCV(keras,DL_params,n_iter=10,cv=3,random_state=516)
    #RS_cv.fit(X_train,y_train)
    #RandomizedSearchCV.set_params([keras,RS_params])
    #best_model = RS_cv.best_estimator_
    
#BayesSearch
    BS_cv=BayesSearchCV(keras,DL_params,n_iter=10,cv=3,random_state=516)
    BS_cv.fit(X_train,y_train)
    BayesSearchCV.set_params([keras,DL_params])
    best_model = BS_cv.best_estimator_
    
#GridSearch 
    # GS_cv=GridSearchCV(estimator=keras, param_grid=DL_params, n_jobs=-1, cv=3)
    # GS_cv.fit(X_train,y_train)
    # GridSearchCV.set_params([keras,DL_params])
    # best_model = GS_cv.best_estimator_
            
    best_models[model_type] = best_model
    y_train_pred = best_model.predict(X_train)
    y_test_pred = best_model.predict(X_test)
    
    train_rmse = np.sqrt(MSE(y_train, y_train_pred))
    train_mae = MAE(y_train, y_train_pred)
    train_mape = MAPE(y_train, y_train_pred)
    
    test_rmse = np.sqrt(MSE(y_test, y_test_pred))
    test_mae = MAE(y_test, y_test_pred)
    test_mape = MAPE(y_test, y_test_pred)
    
    results[model_type] = {'train_RMSE': train_rmse, 'train_MAE': train_mae, 'train_MAPE': train_mape,'test_RMSE': test_rmse, 'test_MAE': test_mae, 'test_MAPE': test_mape}
    predictions[model_type] = {'y_train_pred': y_train_pred.flatten(),'y_test_pred': y_test_pred.flatten()}
    print(f"{model_type} Train RMSE: {train_rmse}")
    print(f"{model_type} Train MAE: {train_mae}")
    print(f"{model_type} Train MAPE: {train_mape}%")
    print()

    print(f"{model_type} Test RMSE: {test_rmse}")
    print(f"{model_type} Test MAE: {test_mae}")
    print(f"{model_type} Test MAPE: {test_mape}%")
    print()
     
    # Print overall results
    print("Overall Results:")
for model_type, metrics in results.items():
    print(f"{model_type} Train RMSE: {metrics['train_RMSE']}")
    print(f"{model_type} Train MAE: {metrics['train_MAE']}")
    print(f"{model_type} Train MAPE: {metrics['train_MAPE']}%")
    print(f"{model_type} Test RMSE: {metrics['test_RMSE']}")
    print(f"{model_type} Test MAE: {metrics['test_MAE']}")
    print(f"{model_type} Test MAPE: {metrics['test_MAPE']}%")
    print()

#%% plot實際值與預測值
yy = np.concatenate((y_train, y_test))
#date_data =[datetime(2001, 4, 1)+ timedelta(days=i*30) for i in range(len(yy))]
date_data = pd.date_range('2001', periods = 282,freq = '1m')
plt.figure(figsize=(12, 8))
plt.plot(date_data, yy, label='Actual demand', linestyle='-', color='black')

for model_type, preds in predictions.items():
    y_preds = np.concatenate((preds['y_train_pred'], preds['y_test_pred']))
    plt.plot(date_data, y_preds, label=f'Predicted demand ({model_type})', linestyle='-')

plt.title('Comparison of Actual and Predicted')
plt.xlabel('Date', size=15)
plt.ylabel('Electricity Demand', size=15)
plt.legend()
plt.legend(loc = 'lower left')
plt.legend(fontsize=15)

# Set the major locator and formatter for the X-axis to show ticks at the beginning of each month
plt.gca().xaxis.set_major_locator(mdates.YearLocator())
plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
plt.show()
