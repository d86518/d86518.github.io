# -*- coding: utf-8 -*-
"""
Created on Tue Dec 26 14:21:24 2023

@author: user
"""

#%% Load packages
import pandas as pd
import numpy as np
import math
import matplotlib.pyplot as plt
import seaborn as sns
import time, random
import  permetrics

from sklearn.preprocessing import MinMaxScaler
#from bayes_opt import BayesianOptimization
#from permetrics import RegressionMetric
#from permetrics.regression import Metrics
from pandas import DataFrame,concat
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import mean_squared_error as MSE
from sklearn.metrics import mean_absolute_error as MAE
from sklearn.metrics import mean_absolute_percentage_error as MAPE

random.seed(516)
from sklearn.metrics import explained_variance_score, mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import  RandomizedSearchCV, train_test_split,TimeSeriesSplit,GridSearchCV
from sklearn.preprocessing import LabelBinarizer
from tensorflow.keras.regularizers import l2
from tensorflow.keras.initializers import RandomNormal
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Activation, Dropout,BatchNormalization, LSTM ,GRU ,SimpleRNN
from tensorflow.keras.optimizers import Adam,SGD,RMSprop,Adagrad,Adadelta,Adamax,Nadam
from tensorflow.python.keras import backend as K
from tensorflow import keras 
from tensorflow.keras import optimizers
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense,Dropout,InputLayer,Reshape
from tensorflow.keras.wrappers.scikit_learn import KerasRegressor
from tensorflow.keras.callbacks import EarlyStopping

#%% Load data
data=pd.read_csv('capesize.csv',delimiter=",")
data = pd.DataFrame(data)
print('The shape of our features is:', data.shape)
print(data.columns)
#print(data.isnull().any())
#data.head(12)

#%% Load features1Y
###1.5Y 0:136
###2Y 0:130
x_all, y_all = data.iloc[0:154,2:], data.iloc[0:154,1 ]
x_train, y_train = data.iloc[0:142,2:], data.iloc[0:142,1 ]
x_test, y_test = data.iloc[142:154,2: ], data.iloc[142:154,1]
print(x_all.shape,y_all.shape)
print(x_train.shape, y_train.shape, x_test.shape, y_test.shape)

#%% DT 

from sklearn.tree import DecisionTreeRegressor
from sklearn import tree

tree_param_grid = {'min_samples_split': list((8,10,12)),'max_features':list((0.6,0.8,1)),
                   'max_depth':np.linspace(3,8,6,dtype=int),
                   'min_samples_leaf':list((6,8,10))}
                   
grid = GridSearchCV(DecisionTreeRegressor(),param_grid=tree_param_grid, cv=3)
grid.fit(x_train, y_train)
grid.cv_results_, grid.best_params_, grid.best_score_

DTmodel =grid.best_estimator_
DTmodel.fit(x_train, y_train)
print(grid.best_params_)

DT=DecisionTreeRegressor(max_depth=grid.best_params_['max_depth'],
                         max_features=grid.best_params_['max_features'],
                         min_samples_leaf=grid.best_params_['min_samples_leaf'],
                         min_samples_split=grid.best_params_['min_samples_split'],
                         random_state=3)
DT.fit(x_train, y_train)

tree.plot_tree(DT)
print(tree.export_text(DT))

# In[]:DT變數重要性
feature =x_all.columns
importances = DT.feature_importances_
feat_imp_dict = dict(zip(feature, importances))
feat_imp = pd.DataFrame.from_dict(feat_imp_dict, orient='index')
feat_imp.rename(columns = {0:'FeatureImportance'}, inplace = True)
feat_imp.sort_values(by=['FeatureImportance'], ascending=False)

#%%
DT_train =DT.predict(x_train)
DT_test = DT.predict(x_test)
DT_pred=pd.concat([pd.DataFrame(DT_train),pd.DataFrame(DT_test)])

DT_RMSEr =np.sqrt(MSE(y_train, DT_train))
print('training RMSE:',DT_RMSEr)

DT_MAEr =MAE(y_train,DT_train)
print('training MAE:',DT_MAEr)

DT_MAPEr =MAPE(y_train,DT_train)
print('training MAPE:',DT_MAPEr)

DT_RMSEs =np.sqrt(MSE(y_test, DT_test))
print('testing RMSE:',DT_RMSEs)

DT_MAEs =MAE(y_test,DT_test)
print('testing MAE:',DT_MAEs)

DT_MAPEs =MAPE(y_test,DT_test)
print('testing MAPE:',DT_MAPEs)

perf_DT=pd.DataFrame()
perf_DT["DT_train"] = [DT_RMSEr,DT_MAEr,DT_MAPEr]
perf_DT["DT_test"] = [DT_RMSEs,DT_MAEs,DT_MAPEs]
perf_DT.index=["RMSE","MAE","MAPE"]
perf_DT

#%% Random Forest
#優化參數
from sklearn.ensemble import RandomForestRegressor
rf_param_grid = {'min_samples_split': list((8,10,12)),'n_estimators':list((10,50,150)),
                   'max_depth':np.linspace(3,8,6,dtype=int),'max_features':list((6,10,12)),
                   'min_samples_leaf':list((6,8,10))}
grid = GridSearchCV(RandomForestRegressor(),param_grid=rf_param_grid, cv=3)
grid.fit(x_train, y_train)
grid.cv_results_, grid.best_params_, grid.best_score_

#最佳參數
RF =grid.best_estimator_
RF.fit(x_train, y_train)
print(grid.best_params_)

# In[]:RF變數重要性
feature =x_all.columns
importances = RF.feature_importances_
feat_imp_dict = dict(zip(feature, importances))
feat_imp = pd.DataFrame.from_dict(feat_imp_dict, orient='index')
feat_imp.rename(columns = {0:'FeatureImportance'}, inplace = True)
feat_imp.sort_values(by=['FeatureImportance'], ascending=False)

# In[]: RF_performance
RF_train =RF.predict(x_train)
RF_test = RF.predict(x_test)
RF_pred=pd.concat([pd.DataFrame(RF_train),pd.DataFrame(RF_test)])

RF_RMSEr =np.sqrt(MSE(y_train, RF_train))
print('training RMSE:',RF_RMSEr)

RF_MAEr =MAE(y_train,RF_train)
print('training MAE:',RF_MAEr)

RF_MAPEr =MAPE(y_train,RF_train)
print('training MAPE:',RF_MAPEr)

RF_RMSEs =np.sqrt(MSE(y_test, RF_test))
print('testing RMSE:',RF_RMSEs)

RF_MAEs =MAE(y_test,RF_test)
print('testing MAE:',RF_MAEs)

RF_MAPEs =MAPE(y_test,RF_test)
print('testing MAPE:',RF_MAPEs)

perf_RF=pd.DataFrame()
perf_RF["RF_train"] =[RF_RMSEr,RF_MAEr,RF_MAPEr]
perf_RF["RF_test"] = [RF_RMSEs,RF_MAEs,RF_MAPEs]
perf_RF.index=["RMSE","MAE","MAPE"]
perf_RF

#%% feature selection for DNN & RNN
data_X=data[["BSI_t-1","BPI_t-1","BCI_t-1","PPI_US","PPI_CN","Australian thermal coal","IMF_base metal index"]]#1Y
x_train, y_train = data_X.iloc[0:142,], data.iloc[0:142,1 ]
x_test, y_test = data_X.iloc[142:154,], data.iloc[142:154,1]
print(x_train.shape, y_train.shape, x_test.shape, y_test.shape)

#%%DNN標準化
X_scaler = MinMaxScaler()
X_train=X_scaler.fit_transform(x_train)
X_test=X_scaler.transform(x_test)
print(X_train.shape, y_train.shape, X_test.shape, y_test.shape)

#%%DNN Bulid the model
es = EarlyStopping(monitor='val_loss', mode='min', patience = 20, verbose=1)
def build_model(first_hidden_neuron, n_dropout, n_hidden, n_neurons,
                learning_rate, activation, kernel_initializer,
                n_epochs, n_batch_size, select_optimizer):
    model = Sequential()
    model.add(Dense(first_hidden_neuron, input_dim=len(X_train[0]), activation=activation, kernel_initializer=kernel_initializer))
    for layer in range(n_hidden):
        model.add(Dense(n_neurons, activation=activation, kernel_initializer=kernel_initializer))
        model.add(Dropout(n_dropout))
        
    model.add(Dense(1, activation='linear'))
    
    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='mean_squared_error', optimizer=optimizer)
    
    model.fit(X_train, y_train, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2, callbacks=[es])
    return model

keras = KerasRegressor(build_model)  

#%% Randomized Search
# Parameters sets
params_DNN = {
        "n_dropout":[0.1,0.15,0.2],
        "n_hidden":[2,3],
        'first_hidden_neuron':[10,15],
        "n_neurons":[30,40,50],
        "learning_rate":[0.25,0.5,0.75],
        "activation":['relu', 'softplus','elu'],
        "n_epochs":[100,200],
        "n_batch_size":[6,8,10],
        "select_optimizer":[optimizers.Adam,optimizers.SGD,optimizers.RMSprop],
        "kernel_initializer": ['glorot_uniform', 'he_normal', 'lecun_normal']
        }
# Randomized Search
RS_cv=RandomizedSearchCV(keras,params_DNN,n_iter=10,cv=3,random_state=516)
RS_cv.fit(X_train,y_train)
print(RS_cv.best_params_)
DNN=RS_cv.best_estimator_

# In[]: DNN_performance
# Prediction
DNN_train = DNN.predict(X_train)
DNN_test = DNN.predict(X_test)
DNN_pred=pd.concat([pd.DataFrame(DNN_train),pd.DataFrame(DNN_test)])

#training
DNN_RMSEr =np.sqrt(MSE(y_train,DNN_train))
print('training RMSE:',DNN_RMSEr)

DNN_MAEr =MAE(y_train,DNN_train)
print('training MAE:',DNN_MAEr)

DNN_MAPEr =MAPE(y_train,DNN_train)
print('training MAPE:',DNN_MAPEr)

##testing
DNN_RMSEs =np.sqrt(MSE(y_test,DNN_test))
print('testing RMSE:',DNN_RMSEs)

DNN_MAEs =MAE(y_test,DNN_test)
print('testing MAE:',DNN_MAEs)

DNN_MAPEs =MAPE(y_test,DNN_test)
print('testing MAPE:',DNN_MAPEs)

perf_DNN = pd.DataFrame()
perf_DNN["DNN_train"] =[DNN_RMSEr,DNN_MAEr,DNN_MAPEr]
perf_DNN["DNN_test"] = [DNN_RMSEs,DNN_MAEs,DNN_MAPEs]
perf_DNN.index=["RMSE","MAE","MAPE"]
perf_DNN

#%%RNN標準化
X_scaler = MinMaxScaler()
X_train=X_scaler.fit_transform(x_train)
X_test=X_scaler.transform(x_test)             
y_train, y_test = y_train.values.reshape(-1, 1), y_test.values.reshape(-1, 1)

t_value=1
X_train = X_train.reshape((X_train.shape[0], t_value, int(X_train.shape[1]/t_value)))
X_test = X_test.reshape((X_test.shape[0], t_value, int(X_test.shape[1]/t_value)))
print(X_train.shape, y_train.shape, X_test.shape, y_test.shape)

#%%
cell=eval('SimpleRNN')
es = EarlyStopping(monitor='val_loss', mode='min', patience = 20, verbose=1)
def bulid_model(n_dropout, n_hidden,n_neurons,learning_rate, activation, n_epochs, n_batch_size, select_optimizer):
    
    model = Sequential()
    for layer in range(n_hidden-1):
        model.add(cell(units=n_neurons,input_shape=(X_train.shape[1], X_train.shape[2]),activation=activation,return_sequences=True))
        
    model.add(cell(units=n_neurons,input_shape=(X_train.shape[1], X_train.shape[2]),activation=activation,return_sequences=False))    
    model.add(Dropout(n_dropout))  
    model.add(Dense(1,activation='linear'))

    optimizer = select_optimizer(lr=learning_rate)
    model.compile(loss='mean_squared_error',optimizer=optimizer)
    
    model.fit(X_train,y_train, epochs=n_epochs, batch_size=n_batch_size, validation_split=0.2, callbacks=[es])
    return model

keras=KerasRegressor(bulid_model)

#%%RNN條參
from skopt.space import Real, Categorical, Integer
from skopt import BayesSearchCV
params = {
        "n_dropout":[0.2,0.3,0.4],
        "n_hidden":[2,3],
        "n_neurons":[30,60,90],
        "learning_rate": np.arange(0.1,0.3,0.05),
        "activation":['relu','softplus','elu'],
        "n_epochs":[100,200],
        "n_batch_size":[6,8,10],
        "select_optimizer":[optimizers.Adam,optimizers.RMSprop, optimizers.Adagrad]
        }

BS_cv=BayesSearchCV(keras,params,n_iter=10,cv=3,random_state=516) 
BS_cv.fit(X_train,y_train)
print(BS_cv.best_params_)
RNN = BS_cv.best_estimator_

# Randomized Search
#RS_cv=RandomizedSearchCV(keras,params,n_iter=10,cv=3,random_state=516)
#RS_cv.fit(X_train,y_train)
#print(RS_cv.best_params_)
#RNN = RS_cv.best_estimator_
#RNN.summary()
#%%
# Performance
RNN_train = RNN.predict(X_train)
RNN_test = RNN.predict(X_test)
RNN_pred=pd.concat([pd.DataFrame(RNN_train),pd.DataFrame(RNN_test)])

##### training #####
RNN_RMSEr=np.sqrt(MSE(y_train, RNN_train))
print('training RMSE:',RNN_RMSEr)

RNN_MAEr=MAE(y_train, RNN_train)
print('training MAE:',RNN_MAEr)

RNN_MAPEr=MAPE(y_train, RNN_train)
print('training MAPE:',RNN_MAPEr)

##### testing #####
RNN_RMSEs=np.sqrt(MSE(y_test, RNN_test))
print('training RMSE:',RNN_RMSEs)

RNN_MAEs=MAE(y_test, RNN_test)
print('training MAE:',RNN_MAEs)

RNN_MAPEs=MAPE(y_test, RNN_test)
print('training MAPE:',RNN_MAPEs)

perf_RNN = pd.DataFrame()
perf_RNN["RNN_train"] =[RNN_RMSEr,RNN_MAEr,RNN_MAPEr]
perf_RNN["RNN_test"] = [RNN_RMSEs,RNN_MAEs,RNN_MAPEs]
perf_RNN.index=["RMSE","MAE","MAPE"]
perf_RNN

#%%
perf_tr = pd.DataFrame({
    'Training':['RMSE','MAE','MAPE'],
    'DT':[round(x, 3) for x in(DT_RMSEr,DT_MAEr,DT_MAPEr)],
    'RF':[round(x, 3) for x in(RF_RMSEr,RF_MAEr,RF_MAPEr)],
    'DNN':[round(x, 3) for x in (DNN_RMSEr,DNN_MAEr,DNN_MAPEr)],
    'RNN':[round(x, 3) for x in (RNN_RMSEr,RNN_MAEr,RNN_MAPEr)]
    })

perf_ts = pd.DataFrame({
    'Testing':['RMSE','MAE','MAPE'],
    'DT':[round(x, 3) for x in(DT_RMSEs,DT_MAEs,DT_MAPEs)],
    'RF':[round(x, 3) for x in(RF_RMSEs,RF_MAEs,RF_MAPEs)],
    'DNN':[round(x, 3) for x in (DNN_RMSEs,DNN_MAEs,DNN_MAPEs)],
    'RNN':[round(x, 3) for x in (RNN_RMSEs,RNN_MAEs,RNN_MAPEs)]
    })

print(perf_tr)
print('\n',perf_ts)

#%%
# plot實際值與預測值
real=pd.concat([pd.DataFrame(y_train),pd.DataFrame(y_test)],axis=0)
real.index= pd.date_range('2011',periods = 154,freq = '1m')
DT_pred=pd.concat([pd.DataFrame(DT_train),pd.DataFrame(DT_test)],axis=0)
DT_pred=DT_pred.reset_index(drop=True)
DT_pred.index= pd.date_range('2011',periods = 154,freq = '1m')
RF_pred=pd.concat([pd.DataFrame(RF_train),pd.DataFrame(RF_test)],axis=0)
RF_pred=RF_pred.reset_index(drop=True)
RF_pred.index= pd.date_range('2011',periods = 154,freq = '1m')
DNN_pred=pd.concat([pd.DataFrame(np.nan_to_num(DNN_train).flatten()),pd.DataFrame(np.nan_to_num(DNN_test).flatten())],axis=0)
DNN_pred=DNN_pred.reset_index(drop=True)
DNN_pred.index= pd.date_range('2011',periods = 154,freq = '1m')
RNN_pred=pd.concat([pd.DataFrame(np.nan_to_num(RNN_train).flatten()),pd.DataFrame(np.nan_to_num(RNN_test).flatten())],axis=0)
RNN_pred=RNN_pred.reset_index(drop=True)
RNN_pred.index= pd.date_range('2011',periods = 154,freq = '1m')


plt.figure(figsize=(20,10))
plt.plot( real, color='black', label="Real",linewidth=1.5)
plt.plot( DT_pred, color='orange', label="DT_pred",linewidth=1.5)
plt.plot( RF_pred, color='blue', label="RF_pred",linewidth=1.5)
plt.plot( DNN_pred, color='red', label="DNN_pred",linewidth=1.5)
plt.plot( RNN_pred, color='green', label="RNN_pred",linewidth=1.5)

plt.legend(loc = 'lower left')
plt.legend(fontsize=15)
plt.xlabel('Date', size=15)
plt.ylabel('Capesize Revenue', size=15)

