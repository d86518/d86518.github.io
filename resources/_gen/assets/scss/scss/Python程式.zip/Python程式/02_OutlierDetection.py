# -*- coding: utf-8 -*-
"""
Created on Mon Sep  6 11:03:14 2021

@author: a0978
"""
import pandas as pd
import scipy as sp
import numpy as np
import matplotlib.pyplot as plt

#%%
# Data preparation
df = pd.read_csv('gender_outlier.csv')
df_male = df[df['Gender']=='male'].drop(['Gender'],axis=1)
df_female = df[df['Gender']=='female'].drop(['Gender'],axis=1)

#%%
# Histogram
plt.hist(df.Height,color='blue')
plt.axvline(df.Height.mean(), color='black', linestyle='dashed', linewidth=1)
plt.title('Histogram of Height');plt.xlabel('Height');plt.ylabel('Freq')
plt.show()

plt.hist(df.Weight,color='red')
plt.axvline(df.Weight.mean(), color='black', linestyle='dashed', linewidth=1)
plt.title('Histogram of Weight');plt.xlabel('Weight');plt.ylabel('Freq')
plt.show()

plt.hist(df.Waist,color='green')
plt.axvline(df.Waist.mean(), color='black', linestyle='dashed', linewidth=1)
plt.title('Histogram of Waist');plt.xlabel('Waist');plt.ylabel('Freq')
plt.show()

#%%
# Boxplot
box1 = plt.boxplot(df.Height)
plt.title('Boxplot of Height');plt.ylabel('Height')
plt.show()
outlier_height = [df[df.Height==x] for x in np.unique([item.get_ydata() for item in box1['fliers']][0])]
print(outlier_height)

box2 = plt.boxplot(df.Weight)
plt.title('Boxplot of Weight');plt.ylabel('Weight')
plt.show()
outlier_weight = [df[df.Weight==x] for x in np.unique([item.get_ydata() for item in box2['fliers']][0])]
print(outlier_weight)

box3 = plt.boxplot(df.Waist)
plt.title('Boxplot of Waist');plt.ylabel('Waist')
plt.show()
outlier_waist = [df[df.Waist==x] for x in np.unique([item.get_ydata() for item in box3['fliers']][0])]
print(outlier_waist)

outlier_waist = [df[df.Waist==x] for x in [item.get_ydata() for item in box3['fliers']][0]]
print(outlier_waist)

#%%
# Chi-square test
import numpy as np
from scipy.stats import chi2
#from scipy.spatial import distance

def Mahalanobis(data=None, cov=None):
    
    x_minus_mu = data - np.mean(data,axis=0)
    if not cov:
        cov = np.cov(data.values.T)
    inv_covmat = sp.linalg.inv(cov)
    left_term = np.dot(x_minus_mu, inv_covmat)
    mahal = np.dot(left_term, x_minus_mu.T)
    return mahal.diagonal()

Male_mdis = Mahalanobis(data=df_male)
Female_mdis = Mahalanobis(data=df_female)

# Cutoff (threshold) value from Chi-Sqaure Distribution for detecting outliers 
m_cutoff = chi2.ppf(0.95, df_male.shape[1])
f_cutoff = chi2.ppf(0.95, df_female.shape[1])

# Index of outliers
m_outlierIndexes = np.where(Male_mdis > m_cutoff )
f_outlierIndexes = np.where(Female_mdis > f_cutoff )

print('--- Male observations found as outliers -----')
print(df_male.iloc[m_outlierIndexes])

print('--- Female observations found as outliers -----')
print(df_female.iloc[f_outlierIndexes])

#%%
# Isolation forrest
from sklearn.ensemble import IsolationForest

# model buliding
iforest = IsolationForest(n_estimators=100,  #The number of base estimators(trees)
                          max_samples='auto', #The number of samples to train
                          contamination=0.05,  # the proportion of outliers in the dataset.
                          max_features=3, #The number of features to train
                          n_jobs=-1, 
                          random_state=1)

m_pred = iforest.fit_predict(df_male)
f_pred = iforest.fit_predict(df_female)

m_scores = iforest.decision_function(df_male)
f_scores = iforest.decision_function(df_female)

print('--- Male observations found as outliers using isolation forrest-----')
print(df_male[m_pred==-1])

print('--- Female observations found as outliers using isolation forrest -----')
print(df_female[f_pred==-1])
